var Xo=Object.defineProperty;var Wo=(r,t,e)=>t in r?Xo(r,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):r[t]=e;var a=(r,t,e)=>(Wo(r,typeof t!="symbol"?t+"":t,e),e);import{a as _,E as Me,g as Ho,m as $t,W as ze,b as oe,T as ho,C as Uo,S as qo,i as Go,c as Tt,d as fo,B as Ko,e as Vo,f as Qo,h as Ve,j as St,k as uo,l as Zo,n as Jo,s as po}from"./settings-5c354110.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))o(s);new MutationObserver(s=>{for(const i of s)if(i.type==="childList")for(const n of i.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&o(n)}).observe(document,{childList:!0,subtree:!0});function e(s){const i={};return s.integrity&&(i.integrity=s.integrity),s.referrerPolicy&&(i.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?i.credentials="include":s.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function o(s){if(s.ep)return;s.ep=!0;const i=e(s);fetch(s.href,i)}})();const er=(r="")=>{let t=0,e=!1;const o=l=>l.replace(/<!--.*?-->/gms,"").replace(/\r?\n\s*\r\n/gm," ").replace(/\r?\n\s*(\S)/gm," $1").replace(/\r?\n/g,""),s=()=>{e||(r=o(r),e=!0);const l={children:[]};let d=!1;for(;r[t];){if(r[t]==='"'&&(d=!d),r.charCodeAt(t)==="<".charCodeAt(0)&&!d){if(r.charCodeAt(t+1)==="/".charCodeAt(0))return l;i(l)}t++}return l},i=l=>{const d=r.slice(t).match(/(?:[^">]*|"[^"]*")*>/),c=d&&d[0]&&d[0].length+t-1,h=n(r.substring(t+1,c)),p={type:h.type,...h.attributes};if(r.charCodeAt(c-1)==="/".charCodeAt(0))l.children.push(p);else{t=c;const m=s();m.children.length&&(p.children=[...m.children]),l.children.push(p)}},n=l=>{let d;const c={type:(d=l.match(/^([A-Za-z0-9]+)(?![A-Za-z0-9=])/))&&d[0]},h=l.match(/[:*@\w.-]+="[^"]*"/g)||[];return h.length&&(c.attributes=h.reduce((p,m)=>{const f=/(.+)=["'](.+)["']/.exec(m);if(f)if(f[1].indexOf(".")>-1){const g=f[1].split(".");p[g[0]]=`{${g[1]}: ${f[2]}}`}else p[f[1]]=f[2];return p},{})),c};return s()};let S;function tr(r={children:[]}){const t={renderCode:["const elms = []"],effectsCode:[],context:{props:[],components:this.components}};return S=-1,xo.call(t,r),t.renderCode.push("return elms"),{render:new Function("parent","component","context",t.renderCode.join(`
`)),effects:t.effectsCode.map(e=>new Function("component","elms","context",e)),context:t.context}}const yt=function(r,t=!1,e={key:!1,component:"component.",forceEffect:!1}){const o=e.forceEffect?this.effectsCode:this.renderCode;t&&o.push(`parent = ${t}`),"key"in r&&(e.key=ge(r.key,e.component));const s=e.key?`elms[${S}][${e.key}]`:`elms[${S}]`;e.key&&o.push(`
      elms[${S}] = elms[${S}] || {}
    `),o.push(`
    if(!${s}) {
      ${s} = this.element({componentId: component.___id, parentId: parent && parent.nodeId || 'root'})
    }
    const elementConfig${S} = {}
  `);const i=r.children;delete r.children,Object.keys(r).forEach(n=>{n!=="type"&&(go(n)?this.effectsCode.push(`${s}.set('${n.substring(1)}', ${ge(r[n],e.component)})`):o.push(`elementConfig${S}['${n}'] = ${wt(r[n],n,e.component)}`))}),e.holder===!0&&o.push(`
    if(typeof cmp${S} !== 'undefined') {
      for(key in cmp${S}.config.props) {
        delete  elementConfig${S}[cmp${S}.config.props[key]]
      }
    }
    `),o.push(`
    if(!${s}.nodeId) {
      ${s}.populate(elementConfig${S})
    }
  `),i&&xo.call(this,{children:i},`elms[${S}]`)},mo=function(r,t=!1,e={key:!1,component:"component.",forceEffect:!1,holder:!1}){const o=e.forceEffect?this.effectsCode:this.renderCode;o.push(`
    const cmp${S} =
      (context.components && context.components['${r.type}']) ||
      component.___components['${r.type}']
  `),"key"in r&&(e.key=ge(r.key,e.component)),yt.call(this,r,t,{...e,holder:!0}),t=e.key?`elms[${S}][${e.key}]`:`elms[${S}]`,S++;const s=e.key?`elms[${S}][${e.key}]`:`elms[${S}]`;e.key&&o.push(`
      elms[${S}] = elms[${S}] || {}
    `),t&&o.push(`parent = ${t}`),o.push(`const props${S} = {}`),Object.keys(r).forEach(i=>{i!=="type"&&(go(i)?(this.effectsCode.push(`
          ${s}.___props['${i.substring(1)}'] = ${ge(r[i],e.component)}`),o.push(`props${S}['${i.substring(1)}'] = ${ge(r[i],e.component)}`)):o.push(`props${S}['${i}'] = ${wt(r[i],i,e.component)}`))}),o.push(`
    if(!${s}) {
      ${s} = (context.components && context.components['${r.type}'] || component.___components['${r.type}'] || (() => { console.log('component ${r.type} not found')})).call(null, {props: props${S}}, ${t}, component)
    }
  `)},or=function(r,t){const e=r[":for"];delete r[":for"];const s=/(.+)\s+in\s+(.+)/gi.exec(e),[i,n="index"]=s[1].replace("(","").replace(")","").split(/\s*,\s*/),l={renderCode:[],effectsCode:[],context:{props:[],components:this.components}};t&&l.renderCode.push(`parent = ${t}`),l.renderCode.push(`
    const collection = ${wt(s[2],":for")}
    const keys = []
    for(let __index = 0; __index < collection.length; __index++) {
      parent = ${t}
      const scope = Object.assign(component, {
        key: Math.random(),
        ${n}: __index,
        ${i}: collection[__index]
      })
    `),"key"in r?l.renderCode.push(`
      keys.push(${ge(r.key,"scope.")})
    `):l.renderCode.push(`
      keys.push(scope.key.toString())
    `),r.type!=="Element"?mo.call(l,r,!1,{key:"scope.key",component:"scope.",forceEffect:!1}):yt.call(l,r,t,{key:"scope.key",component:"scope.",forceEffect:!1}),l.renderCode=l.renderCode.concat(l.effectsCode),l.renderCode.push("}"),l.renderCode.push(`
    if(elms[${S}]) {
      Object.keys(elms[${S}]).forEach(key => {
        if(keys.indexOf(key) === -1) {
          elms[${S}][key].delete && elms[${S}][key].delete()
          elms[${S}][key].destroy && elms[${S}][key].destroy()
          delete elms[${S}][key]
        }
      })
    }
  `),this.effectsCode.push(l.renderCode.join(`
`))},xo=function(r,t=!1){r.children.forEach(e=>{S++,Object.keys(e).indexOf(":for")>-1?or.call(this,e,t):e.type!=="Element"?mo.call(this,e,t):yt.call(this,e,t)})},ge=(r,t="component.")=>{const e=/('.*?')+/gi,o=/\$/gi,s=r.matchAll(e),i=[];let n=0;for(const l of s)i.push(l[0]),r=r.replace(l[0],`[@@REPLACEMENT${n}@@]`),n++;return r=r.replace(o,t),i.forEach((l,d)=>{r=r.replace(`[@@REPLACEMENT${d}@@]`,l)}),r},wt=(r="",t=!1,e="component.")=>{let o;if(t!=="color"&&!isNaN(parseFloat(r)))o=parseFloat(r);else if(r.toLowerCase()==="true")o=!0;else if(r.toLowerCase()==="false")o=!1;else if(t.startsWith("@")&&r){const s=e.slice(0,-1);o=`${s}['${r.replace("$","")}'] && ${s}['${r.replace("$","")}'].bind(${s})`}else r.startsWith("$")?o=`${e}${r.replace("$","")}`:o=`"${r}"`;return o},go=r=>r.startsWith(":");class yo{constructor(t){a(this,"releaseCallback");this.releaseCallback=t}}class rr extends yo{constructor(e,o){super(e);a(this,"textureMap",new Map);a(this,"zeroReferenceTextureSet",new Set);a(this,"options");this.options={textureCleanupIntervalMs:o.textureCleanupIntervalMs??1e4,textureCleanupAgeThreadholdMs:o.textureCleanupAgeThreadholdMs??6e4},setInterval(()=>{const s=Date.now(),i=this.options.textureCleanupAgeThreadholdMs;for(const n of this.zeroReferenceTextureSet)s-n.lastUpdate>i&&(this.releaseCallback(n.id),this.textureMap.delete(n.id),this.zeroReferenceTextureSet.delete(n))},this.options.textureCleanupIntervalMs)}registerTexture(e){var s;const o=(s=e.options)==null?void 0:s.id;if(_(o,"Texture must have an id to be registered"),!this.textureMap.has(o)){const i={id:o,nodeRefCount:0,lastUpdate:Date.now()};this.textureMap.set(o,i),this.zeroReferenceTextureSet.add(i)}}incrementTextureRefCount(e){var i;const o=(i=e.options)==null?void 0:i.id;_(o,"Texture must have an id to be registered");let s=this.textureMap.get(o);s||(this.registerTexture(e),s=this.textureMap.get(o)),_(s,"Texture must have been registered"),e.txType==="SubTexture"&&this.incrementTextureRefCount(e.props.texture),s.nodeRefCount++,s.lastUpdate=Date.now(),this.zeroReferenceTextureSet.has(s)&&this.zeroReferenceTextureSet.delete(s)}decrementTextureRefCount(e){var i;const o=(i=e.options)==null?void 0:i.id;_(o,"Texture must have an id to be registered");const s=this.textureMap.get(o);_(s,"Texture must have been registered"),s.nodeRefCount--,s.lastUpdate=Date.now(),s.nodeRefCount===0&&this.zeroReferenceTextureSet.add(s),e.txType==="SubTexture"&&this.decrementTextureRefCount(e.props.texture)}}class sr extends yo{constructor(e){super(e);a(this,"registry");this.registry=new FinalizationRegistry(e)}registerTexture(e){var o,s;_((o=e.options)==null?void 0:o.id,"Texture must have an ID to be registered"),this.registry.register(e,(s=e.options)==null?void 0:s.id)}incrementTextureRefCount(){}decrementTextureRefCount(){}}class ir{constructor(t,e,o){a(this,"root",null);a(this,"driver");a(this,"canvas");a(this,"settings");a(this,"nodes",new Map);a(this,"nextTextureId",1);a(this,"textureTracker");const s={appWidth:t.appWidth||1920,appHeight:t.appHeight||1080,deviceLogicalPixelRatio:t.deviceLogicalPixelRatio||1,devicePhysicalPixelRatio:t.devicePhysicalPixelRatio||window.devicePixelRatio,clearColor:t.clearColor??0,coreExtensionModule:t.coreExtensionModule||null,experimental_FinalizationRegistryTextureUsageTracker:t.experimental_FinalizationRegistryTextureUsageTracker??!1,textureCleanupOptions:t.textureCleanupOptions||{}};this.settings=s;const{appWidth:i,appHeight:n,deviceLogicalPixelRatio:l,devicePhysicalPixelRatio:d}=s,c=x=>{this.driver.releaseTexture(x)},h=s.experimental_FinalizationRegistryTextureUsageTracker&&typeof FinalizationRegistry=="function";this.textureTracker=h?new sr(c):new rr(c,this.settings.textureCleanupOptions);const p=i*l,m=n*l;this.driver=o;const f=document.createElement("canvas");this.canvas=f,f.width=p*d,f.height=m*d,f.style.width=`${p}px`,f.style.height=`${m}px`;let g;if(typeof e=="string"?g=document.getElementById(e):g=e,!g)throw new Error("Could not find target element");o.onCreateNode=x=>{this.nodes.set(x.id,x)},o.onBeforeDestroyNode=x=>{this.nodes.delete(x.id)},g.appendChild(f)}async init(){await this.driver.init(this,this.settings,this.canvas),this.root=this.driver.getRootNode()}createNode(t){return this.driver.createNode(this.resolveNodeDefaults(t))}createTextNode(t){return this.driver.createTextNode({...this.resolveNodeDefaults(t),text:t.text??"",textRendererOverride:t.textRendererOverride??null,fontSize:t.fontSize??16,fontFamily:t.fontFamily??"sans-serif",fontStyle:t.fontStyle??"normal",fontWeight:t.fontWeight??"normal",fontStretch:t.fontStretch??"normal",textAlign:t.textAlign??"left",contain:t.contain??"none",scrollable:t.scrollable??!1,scrollY:t.scrollY??0,offsetY:t.offsetY??0,letterSpacing:t.letterSpacing??0,debug:t.debug??{}})}resolveNodeDefaults(t){const e=t.color??4294967295,o=t.colorTl??t.colorTop??t.colorLeft??e,s=t.colorTr??t.colorTop??t.colorRight??e,i=t.colorBl??t.colorBottom??t.colorLeft??e,n=t.colorBr??t.colorBottom??t.colorRight??e;return{x:t.x??0,y:t.y??0,width:t.width??0,height:t.height??0,alpha:t.alpha??1,clipping:t.clipping??!1,color:e,colorTop:t.colorTop??e,colorBottom:t.colorBottom??e,colorLeft:t.colorLeft??e,colorRight:t.colorRight??e,colorBl:i,colorBr:n,colorTl:o,colorTr:s,zIndex:t.zIndex??0,zIndexLocked:t.zIndexLocked??0,parent:t.parent??null,texture:t.texture??null,shader:t.shader??null,src:t.src??"",scale:t.scale??1,mount:t.mount??0,mountX:t.mountX??t.mount??0,mountY:t.mountY??t.mount??0,pivot:t.pivot??.5,pivotX:t.pivotX??t.pivot??.5,pivotY:t.pivotY??t.pivot??.5,rotation:t.rotation??0}}destroyNode(t){return this.driver.destroyNode(t)}createTexture(t,e,o){const s=this.nextTextureId++,i={descType:"texture",txType:t,props:e,options:{...o,id:s}};return this.textureTracker.registerTexture(i),i}createShader(t,e){return{descType:"shader",shType:t,props:e}}getNodeById(t){return this.nodes.get(t)||null}toggleFreeze(){throw new Error("Not implemented")}advanceFrame(){throw new Error("Not implemented")}rerender(){throw new Error("Not implemented")}}class nr extends Me{constructor(e,o,s){super();a(this,"node");a(this,"props");a(this,"settings");a(this,"propStartValues",{});a(this,"restoreValues",{});a(this,"progress",0);a(this,"timingFunction");this.node=e,this.props=o,this.settings=s,this.propStartValues={},Object.keys(o).forEach(i=>{this.propStartValues[i]=e[i]}),this.timingFunction=i=>i,s.easing&&typeof s.easing=="string"&&(this.timingFunction=Ho(s.easing))}reset(){this.progress=0,this.update(0)}restore(){this.reset(),Object.keys(this.props).forEach(e=>{this.node[e]=this.propStartValues[e]})}reverse(){this.progress=0,Object.keys(this.props).forEach(e=>{const o=this.node[e],s=this.propStartValues[e];this.props[e]=s,this.propStartValues[e]=o}),this.settings.stopMethod=!1}applyEasing(e,o,s){return(this.timingFunction(e)||e)*(s-o)+o}update(e){const{duration:o,loop:s,easing:i}=this.settings;if(!o){this.emit("finished",{});return}this.progress+=e/o,this.progress>1&&(this.progress=s?0:1,this.emit("finished",{})),Object.keys(this.props).forEach(n=>{const l=this.props[n],d=this.propStartValues[n],c=l;if(n.indexOf("color")!==-1){const h=i?this.timingFunction(this.progress)||this.progress:this.progress,p=$t(d,c,h);this.node[n]=i?p:$t(d,c,this.progress)}else this.node[n]=i?this.applyEasing(this.progress,d,c):d+(c-d)*this.progress})}}class ar{constructor(t,e){a(this,"manager");a(this,"animation");a(this,"stoppedPromise",null);a(this,"stoppedResolve",null);a(this,"state");this.manager=t,this.animation=e,this.state="stopped"}start(){return this.makeStoppedPromise(),this.animation.once("finished",this.finished.bind(this)),this.manager.activeAnimations.has(this.animation)||this.manager.registerAnimation(this.animation),this.state="running",this}stop(){return this.manager.unregisterAnimation(this.animation),this.stoppedResolve!==null&&(this.stoppedResolve(),this.stoppedResolve=null),this.animation.reset(),this.state="stopped",this}pause(){return this.manager.unregisterAnimation(this.animation),this.state="paused",this}restore(){return this.stoppedResolve=null,this.animation.restore(),this}waitUntilStopped(){this.makeStoppedPromise();const t=this.stoppedPromise;return _(t),t}makeStoppedPromise(){this.stoppedResolve===null&&(this.stoppedPromise=new Promise(t=>{this.stoppedResolve=t}))}finished(){_(this.stoppedResolve);const{loop:t,stopMethod:e}=this.animation.settings;if(e==="reverse"){this.animation.reverse(),this.start();return}this.stoppedResolve(),this.stoppedResolve=null,!t&&this.manager.unregisterAnimation(this.animation)}}class lr{constructor(){a(this,"alpha",1);a(this,"px",0);a(this,"py",0);a(this,"ta",1);a(this,"tb",0);a(this,"tc",0);a(this,"td",1)}isIdentity(){return this.alpha===1&&this.px===0&&this.py===0&&this.isIdentityMatrix()}isIdentityMatrix(){return this.ta===1&&this.tb===0&&this.tc===0&&this.td===1}isSquare(){return this.tb===0&&this.tc===0}}class bt extends Me{constructor(e,o){super();a(this,"stage");a(this,"children",[]);a(this,"props");a(this,"recalculationType",6);a(this,"hasUpdates",!0);a(this,"worldContext",new lr);a(this,"localPx",0);a(this,"localPy",0);a(this,"isComplex",!1);a(this,"onTextureLoaded",(e,o)=>{this.emit("txLoaded",o)});a(this,"onTextureFailed",(e,o)=>{this.emit("txFailed",o)});this.stage=e,this.props={...o,parent:null,ta:o.ta??1,tb:o.tb??0,tc:o.tc??0,td:o.td??1,worldX:o.worldX??0,worldY:o.worldY??0},this.parent=o.parent,this.updateLocalTransform()}loadTexture(e,o,s=null){this.props.texture&&this.unloadTexture();const{txManager:i}=this.stage,n=i.loadTexture(e,o,s);this.props.texture=n,this.props.textureOptions=s,queueMicrotask(()=>{n.state==="loaded"?this.onTextureLoaded(n,n.dimensions):n.state==="failed"&&this.onTextureFailed(n,n.error),n.on("loaded",this.onTextureLoaded),n.on("failed",this.onTextureFailed)})}unloadTexture(){this.props.texture&&(this.props.texture.off("loaded",this.onTextureLoaded),this.props.texture.off("failed",this.onTextureFailed)),this.props.texture=null,this.props.textureOptions=null}loadShader(e,o){const s=this.stage.renderer.getShaderManager();_(s);const{shader:i,props:n}=s.loadShader(e,o);this.props.shader=i,this.props.shaderProps=n}setHasUpdates(){if(!this.props.alpha)return;this.hasUpdates=!0;let e=this==null?void 0:this.props.parent;for(;e;)e.hasUpdates=!0,e=e==null?void 0:e.props.parent}setRecalculationType(e){this.recalculationType|=e,this.setHasUpdates()}updateLocalTransform(){if(this.props.rotation!==0&&this.props.rotation%(Math.PI*2)){const e=Math.sin(this.props.rotation),o=Math.cos(this.props.rotation);this.setLocalTransform(o*this.props.scale,-e*this.props.scale,e*this.props.scale,o*this.props.scale)}else this.setLocalTransform(this.props.scale,0,0,this.props.scale);this.updateLocalTranslate()}setLocalTransform(e,o,s,i){this.setRecalculationType(4),this.props.ta=e,this.props.tb=o,this.props.tc=s,this.props.td=i,this.isComplex=o!==0||s!==0||e<0||i<0}updateLocalTranslate(){this.setRecalculationType(2);const e=this.props.pivotX*this.props.width,o=this.props.pivotY*this.props.height;let s=this.props.x-(e*this.props.ta+o*this.props.tb)+e,i=this.props.y-(e*this.props.tc+o*this.props.td)+o;s-=this.props.mountX*this.props.width,i-=this.props.mountY*this.props.height,this.localPx=s,this.localPy=i}update(e){var i;const o=(i=this.props.parent)==null?void 0:i.worldContext,s=this.worldContext;s.px=((o==null?void 0:o.px)||0)+this.localPx*((o==null?void 0:o.ta)||1),s.py=((o==null?void 0:o.py)||0)+this.localPy*((o==null?void 0:o.td)||1),(o==null?void 0:o.tb)!==0&&(s.px+=this.localPy*((o==null?void 0:o.tb)||0)),(o==null?void 0:o.tc)!==0&&(s.py+=this.localPx*((o==null?void 0:o.tc)||0)),s.ta=this.props.ta*((o==null?void 0:o.ta)||1),s.tb=this.props.td*((o==null?void 0:o.tb)||0),s.tc=this.props.ta*((o==null?void 0:o.tc)||0),s.td=this.props.td*((o==null?void 0:o.td)||1),this.isComplex&&(s.ta+=this.props.tc*((o==null?void 0:o.tb)||0),s.tb+=this.props.tb*((o==null?void 0:o.ta)||1),s.tc+=this.props.tc*((o==null?void 0:o.td)||1),s.td+=this.props.tb*((o==null?void 0:o.tc)||0)),this.worldX=s.px,this.worldY=s.py,this.children.length&&this.children.forEach(n=>{n.update(e)}),this.hasUpdates=!1,this.recalculationType=0}renderQuads(e,o){const{width:s,height:i,colorTl:n,colorTr:l,colorBl:d,colorBr:c,texture:h,textureOptions:p,shader:m,shaderProps:f,scale:g}=this.props,{zIndex:x,alpha:w,worldScale:u}=this;e.addRenderable({width:s,height:i,colorTl:n,colorTr:l,colorBl:d,colorBr:c,texture:h,textureOptions:p,zIndex:x,shader:m,shaderProps:f,alpha:w,scale:g,clippingRect:o,wpx:this.worldContext.px,wpy:this.worldContext.py,worldScale:u,ta:this.worldContext.ta,tb:this.worldContext.tb,tc:this.worldContext.tc,td:this.worldContext.td})}get id(){return this.props.id}get x(){return this.props.x}set x(e){this.props.x!==e&&(this.props.x=e,this.updateLocalTranslate())}get worldX(){return this.props.worldX||0}set worldX(e){this.props.worldX=e}get worldY(){return this.props.worldY||0}set worldY(e){this.props.worldY=e}get absX(){var e,o;return this.props.x+(((e=this.props.parent)==null?void 0:e.absX)||((o=this.props.parent)==null?void 0:o.worldContext.px)||0)}get absY(){var e;return this.props.y+(((e=this.props.parent)==null?void 0:e.absY)??0)}get y(){return this.props.y}set y(e){this.props.y!==e&&(this.props.y=e,this.updateLocalTranslate())}get width(){return this.props.width}set width(e){this.props.width!==e&&(this.props.width=e,this.updateLocalTransform())}get height(){return this.props.height}set height(e){this.props.height!==e&&(this.props.height=e,this.updateLocalTransform())}get scale(){return this.props.scale}set scale(e){this.props.scale!==e&&(this.props.scale=e,this.updateLocalTransform())}get worldScale(){var e;return this.props.scale*(((e=this.props.parent)==null?void 0:e.worldScale)??1)||this.props.scale}get mount(){return this.props.mount}set mount(e){this.props.mountX=e,this.props.mountY=e,this.props.mount=e,this.updateLocalTranslate()}get mountX(){return this.props.mountX}set mountX(e){this.props.mountX=e,this.updateLocalTranslate()}get mountY(){return this.props.mountY}set mountY(e){this.props.mountY=e,this.updateLocalTranslate()}get pivot(){return this.props.pivot}set pivot(e){(this.props.pivotX!==e||this.props.pivotY!==e)&&(this.props.pivotX=e,this.props.pivotY=e,this.updateLocalTranslate())}get pivotX(){return this.props.pivotX}set pivotX(e){this.props.pivotX=e,this.updateLocalTranslate()}get pivotY(){return this.props.pivotY}set pivotY(e){this.props.pivotY=e,this.updateLocalTranslate()}get rotation(){return this.props.rotation}set rotation(e){this.props.rotation!==e&&(this.props.rotation=e,this.updateLocalTransform())}get alpha(){const e=this.props,o=e.parent;return o?e.alpha*o.alpha:1}set alpha(e){this.props.alpha=e}get clipping(){return this.props.clipping}set clipping(e){this.props.clipping=e}get color(){return this.props.color}set color(e){(this.props.colorTl!==e||this.props.colorTr!==e||this.props.colorBl!==e||this.props.colorBr!==e)&&(this.colorTl=e,this.colorTr=e,this.colorBl=e,this.colorBr=e),this.props.color=e}get colorTop(){return this.props.colorTop}set colorTop(e){(this.props.colorTl!==e||this.props.colorTr!==e)&&(this.colorTl=e,this.colorTr=e),this.props.colorTop=e}get colorBottom(){return this.props.colorBottom}set colorBottom(e){(this.props.colorBl!==e||this.props.colorBr!==e)&&(this.colorBl=e,this.colorBr=e),this.props.colorBottom=e}get colorLeft(){return this.props.colorLeft}set colorLeft(e){(this.props.colorTl!==e||this.props.colorBl!==e)&&(this.colorTl=e,this.colorBl=e),this.props.colorLeft=e}get colorRight(){return this.props.colorRight}set colorRight(e){(this.props.colorTr!==e||this.props.colorBr!==e)&&(this.colorTr=e,this.colorBr=e),this.props.colorRight=e}get colorTl(){return this.props.colorTl}set colorTl(e){this.props.colorTl=e}get colorTr(){return this.props.colorTr}set colorTr(e){this.props.colorTr=e}get colorBl(){return this.props.colorBl}set colorBl(e){this.props.colorBl=e}get colorBr(){return this.props.colorBr}set colorBr(e){this.props.colorBr=e}get zIndexLocked(){return this.props.zIndexLocked||0}set zIndexLocked(e){this.props.zIndexLocked=e}get zIndex(){var i,n;const e=this.props,o=e.zIndex||0,s=((i=e.parent)==null?void 0:i.zIndex)||0;return(n=e.parent)!=null&&n.zIndexLocked?o<s?o:s:o}set zIndex(e){this.props.zIndex=e}get parent(){return this.props.parent}set parent(e){const o=this.props.parent;if(o!==e){if(this.props.parent=e,o){const s=o.children.indexOf(this);_(s!==-1,"CoreNode.parent: Node not found in old parent's children!"),o.children.splice(s,1)}e&&e.children.push(this),this.updateLocalTransform()}}}let cr=1;function wo(){return cr++}class it extends Me{constructor(e,o,s,i){super();a(this,"rendererMain");a(this,"stage");a(this,"id");a(this,"coreNode");a(this,"_children",[]);a(this,"_src","");a(this,"_parent",null);a(this,"_texture",null);a(this,"_shader",null);a(this,"onTextureLoaded",(e,o)=>{this.emit("txLoaded",o)});a(this,"onTextureFailed",(e,o)=>{this.emit("txFailed",o)});this.rendererMain=o,this.stage=s,this.id=(i==null?void 0:i.id)??wo(),this.coreNode=i||new bt(this.stage,{id:this.id,x:e.x,y:e.y,width:e.width,height:e.height,alpha:e.alpha,clipping:e.clipping,color:e.color,colorTop:e.colorTop,colorBottom:e.colorBottom,colorLeft:e.colorLeft,colorRight:e.colorRight,colorTl:e.colorTl,colorTr:e.colorTr,colorBl:e.colorBl,colorBr:e.colorBr,zIndex:e.zIndex,zIndexLocked:e.zIndexLocked,scale:e.scale,mountX:e.mountX,mountY:e.mountY,mount:e.mount,pivot:e.pivot,pivotX:e.pivotX,pivotY:e.pivotY,rotation:e.rotation,parent:null,shader:null,shaderProps:null,texture:null,textureOptions:null}),this.coreNode.on("txLoaded",this.onTextureLoaded),this.coreNode.on("txFailed",this.onTextureFailed),this.parent=e.parent,this.shader=e.shader,this.texture=e.texture,this.src=e.src}get x(){return this.coreNode.x}set x(e){this.coreNode.x=e}get y(){return this.coreNode.y}set y(e){this.coreNode.y=e}get worldX(){return this.coreNode.worldX}get worldY(){return this.coreNode.worldY}get width(){return this.coreNode.width}set width(e){this.coreNode.width=e}get height(){return this.coreNode.height}set height(e){this.coreNode.height=e}get alpha(){return this.coreNode.alpha}set alpha(e){this.coreNode.alpha=e}get clipping(){return this.coreNode.clipping}set clipping(e){this.coreNode.clipping=e}get color(){return this.coreNode.color}set color(e){this.coreNode.color=e}get colorTop(){return this.coreNode.colorTop}set colorTop(e){this.coreNode.colorTop=e}get colorBottom(){return this.coreNode.colorBottom}set colorBottom(e){this.coreNode.colorBottom=e}get colorLeft(){return this.coreNode.colorLeft}set colorLeft(e){this.coreNode.colorLeft=e}get colorRight(){return this.coreNode.colorRight}set colorRight(e){this.coreNode.colorRight=e}get colorTl(){return this.coreNode.colorTl}set colorTl(e){this.coreNode.colorTl=e}get colorTr(){return this.coreNode.colorTr}set colorTr(e){this.coreNode.colorTr=e}get colorBl(){return this.coreNode.colorBl}set colorBl(e){this.coreNode.colorBl=e}get colorBr(){return this.coreNode.colorBr}set colorBr(e){this.coreNode.colorBr=e}get scale(){return this.coreNode.scale}set scale(e){this.coreNode.scale=e}get mount(){return this.coreNode.mount}set mount(e){this.coreNode.mount=e}get mountX(){return this.coreNode.mountX}set mountX(e){this.coreNode.mountX=e}get mountY(){return this.coreNode.mountY}set mountY(e){this.coreNode.mountY=e}get pivot(){return this.coreNode.pivot}set pivot(e){this.coreNode.pivot=e}get pivotX(){return this.coreNode.pivotX}set pivotX(e){this.coreNode.pivotX=e}get pivotY(){return this.coreNode.pivotY}set pivotY(e){this.coreNode.pivotY=e}get rotation(){return this.coreNode.rotation}set rotation(e){this.coreNode.rotation=e}get parent(){return this._parent}set parent(e){const o=this._parent;if(this._parent=e,this.coreNode.parent=(e==null?void 0:e.coreNode)??null,o){const s=o.children.indexOf(this);_(s!==-1,"MainOnlyNode.parent: Node not found in old parent's children!"),o.children.splice(s,1)}e&&e.children.push(this)}get children(){return this._children}get zIndex(){return this.coreNode.zIndex}set zIndex(e){this.coreNode.zIndex=e}get zIndexLocked(){return this.coreNode.zIndexLocked}set zIndexLocked(e){this.coreNode.zIndexLocked=e}get src(){return this._src}set src(e){if(this._src!==e){if(this._src=e,!e){this.texture=null;return}this.texture=this.rendererMain.createTexture("ImageTexture",{src:e})}}get texture(){return this._texture}set texture(e){this._texture!==e&&(this._texture&&this.rendererMain.textureTracker.decrementTextureRefCount(this._texture),e&&this.rendererMain.textureTracker.incrementTextureRefCount(e),this._texture=e,e?this.coreNode.loadTexture(e.txType,e.props,e.options):this.coreNode.unloadTexture())}get shader(){return this._shader}set shader(e){this._shader!==e&&(this._shader=e,e&&this.coreNode.loadShader(e.shType,e.props))}destroy(){this.emit("beforeDestroy",{}),this.parent=null,this.texture=null,this.emit("afterDestroy",{}),this.removeAllListeners()}flush(){}animate(e,o){const s=new nr(this.coreNode,e,o);return new ar(this.stage.animationManager,s)}}class hr{constructor(t){a(this,"root");this.root=t}getNodeByType(t){return[]}getNodeById(t){return null}update(t){this.root.update(t)}}const fr=r=>{const t=()=>{r.drawFrame(),requestAnimationFrame(t)};requestAnimationFrame(t)},dr=()=>performance?performance.now():Date.now();class bo extends ze{constructor(t){super({renderer:t,attributes:["a_position","a_textureCoordinate","a_color"],uniforms:[{name:"u_resolution",uniform:"uniform2fv"},{name:"u_pixelRatio",uniform:"uniform1f"},{name:"u_texture",uniform:"uniform2fv"}]})}bindTextures(t){const{gl:e}=this;e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,t[0].ctxTexture)}}a(bo,"shaderSources",{vertex:`
      # ifdef GL_FRAGMENT_PRESICISON_HIGH
      precision highp float;
      # else
      precision mediump float;
      # endif

      attribute vec2 a_position;
      attribute vec2 a_textureCoordinate;
      attribute vec4 a_color;

      uniform vec2 u_resolution;
      uniform float u_pixelRatio;


      varying vec4 v_color;
      varying vec2 v_textureCoordinate;

      void main() {
        vec2 normalized = a_position * u_pixelRatio / u_resolution;
        vec2 zero_two = normalized * 2.0;
        vec2 clip_space = zero_two - 1.0;

        // pass to fragment
        v_color = a_color;
        v_textureCoordinate = a_textureCoordinate;

        // flip y
        gl_Position = vec4(clip_space * vec2(1.0, -1.0), 0, 1);
      }
    `,fragment:`
      # ifdef GL_FRAGMENT_PRESICISON_HIGH
      precision highp float;
      # else
      precision mediump float;
      # endif

      uniform vec2 u_resolution;
      uniform sampler2D u_texture;

      varying vec4 v_color;
      varying vec2 v_textureCoordinate;

      void main() {
          vec4 color = texture2D(u_texture, v_textureCoordinate);
          gl_FragColor = vec4(v_color) * texture2D(u_texture, v_textureCoordinate);
      }
    `});class _o extends ze{constructor(e){super({renderer:e,attributes:["a_position","a_textureCoordinate","a_color","a_textureIndex"],uniforms:[{name:"u_resolution",uniform:"uniform2fv"},{name:"u_pixelRatio",uniform:"uniform1f"},{name:"u_textures[0]",uniform:"uniform1iv"}]});a(this,"supportsIndexedTextures",!0)}bindTextures(e){const{renderer:o,gl:s}=this;if(e.length>o.system.parameters.MAX_VERTEX_TEXTURE_IMAGE_UNITS)throw new Error(`DefaultShaderBatched: Cannot bind more than ${o.system.parameters.MAX_VERTEX_TEXTURE_IMAGE_UNITS} textures`);e.forEach((n,l)=>{s.activeTexture(s.TEXTURE0+l),s.bindTexture(s.TEXTURE_2D,n.ctxTexture)});const i=Array.from(Array(e.length).keys());this.setUniform("u_textures[0]",i)}}a(_o,"shaderSources",{vertex:`
      # ifdef GL_FRAGMENT_PRESICISON_HIGH
      precision highp float;
      # else
      precision mediump float;
      # endif

      attribute vec2 a_textureCoordinate;
      attribute vec2 a_position;
      attribute vec4 a_color;
      attribute float a_textureIndex;
      attribute float a_depth;

      uniform vec2 u_resolution;
      uniform float u_pixelRatio;

      varying vec4 v_color;
      varying vec2 v_textureCoordinate;
      varying float v_textureIndex;

      void main(){
        vec2 normalized = a_position * u_pixelRatio / u_resolution;
        vec2 zero_two = normalized * 2.0;
        vec2 clip_space = zero_two - 1.0;

        // pass to fragment
        v_color = a_color;
        v_textureCoordinate = a_textureCoordinate;
        v_textureIndex = a_textureIndex;

        // flip y
        gl_Position = vec4(clip_space * vec2(1.0, -1.0), 0, 1);
      }
    `,fragment:e=>`
      #define txUnits ${e}
      # ifdef GL_FRAGMENT_PRESICISON_HIGH
      precision highp float;
      # else
      precision mediump float;
      # endif

      uniform vec2 u_resolution;
      uniform sampler2D u_image;
      uniform sampler2D u_textures[txUnits];

      varying vec4 v_color;
      varying vec2 v_textureCoordinate;
      varying float v_textureIndex;

      vec4 sampleFromTexture(sampler2D textures[${e}], int idx, vec2 uv) {
        ${Array.from(Array(e).keys()).map(o=>`
          ${o!==0?"else ":""}if (idx == ${o}) {
            return texture2D(textures[${o}], uv);
          }
        `).join("")}
        return texture2D(textures[0], uv);
      }

      void main(){
        gl_FragColor = vec4(v_color) * sampleFromTexture(u_textures, int(v_textureIndex), v_textureCoordinate);
      }
    `});class j{constructor(t){a(this,"priority",1);a(this,"name","");a(this,"ref");a(this,"target");a(this,"passParameters","");a(this,"declaredUniforms","");a(this,"uniformInfo",{});const{ref:e,target:o,props:s={}}=t;this.ref=e,this.target=o;const i={},n=[];let l="";const d=this.constructor.uniforms||{};for(const c in d){const h=d[c],p=h.type,m=`${e}_${c}`;let f="";h.size&&(f=`[${h.size(s)}]`),n.push(m),l+=`uniform ${p} ${m}${f};`,i[c]={name:m,uniform:d[c].method}}this.passParameters=n.join(","),this.declaredUniforms=l,this.uniformInfo=i}static getEffectKey(t){return""}static getMethodParameters(t,e){const o=[];for(const s in t){const i=t[s];let n="";i.size&&(n=`[${i.size(e)}]`),o.push(`${i.type} ${s}${n}`)}return o.join(",")}static resolveDefaults(t){return{}}static makeEffectKey(t){return!1}}a(j,"uniforms",{}),a(j,"methods"),a(j,"onShaderMask"),a(j,"onColorize"),a(j,"onEffectMask");class fe extends j{constructor(){super(...arguments);a(this,"name","radius")}static getEffectKey(){return"radius"}static resolveDefaults(e){return{radius:e.radius??10}}}a(fe,"z$__type__Props"),a(fe,"uniforms",{radius:{value:0,method:"uniform4fv",type:"vec4",validator:e=>{let o=e;return Array.isArray(o)?o.length===2?o=[o[0],o[1],o[0],o[1]]:o.length===3?o=[o[0],o[1],o[2],o[0]]:o.length!==4&&(o=[o[0],o[0],o[0],o[0]]):typeof o=="number"&&(o=[o,o,o,o]),o}}}),a(fe,"methods",{fillMask:`
      float function(float dist) {
        return clamp(-dist, 0.0, 1.0);
      }
    `,boxDist:`
      float function(vec2 p, vec2 size, float radius) {
        size -= vec2(radius);
        vec2 d = abs(p) - size;
        return min(max(d.x, d.y), 0.0) + length(max(d, 0.0)) - radius;
      }
    `}),a(fe,"onShaderMask",`
  vec2 halfDimensions = u_dimensions * 0.5;
  float r = radius[0] * step(v_textureCoordinate.x, 0.5) * step(v_textureCoordinate.y, 0.5);
  r = r + radius[1] * step(0.5, v_textureCoordinate.x) * step(v_textureCoordinate.y, 0.5);
  r = r + radius[2] * step(0.5, v_textureCoordinate.x) * step(0.5, v_textureCoordinate.y);
  r = r + radius[3] * step(v_textureCoordinate.x, 0.5) * step(0.5, v_textureCoordinate.y);
  return $boxDist(v_textureCoordinate.xy * u_dimensions - halfDimensions, halfDimensions, r);
  `),a(fe,"onEffectMask",`
  return mix(vec4(0.0), maskColor, $fillMask(shaderMask));
  `);class $e extends j{constructor(){super(...arguments);a(this,"name","border")}static getEffectKey(){return"border"}static resolveDefaults(e){return{width:e.width??10,color:e.color??4294967295}}}a($e,"z$__type__Props"),a($e,"uniforms",{width:{value:0,method:"uniform1f",type:"float"},color:{value:4294967295,validator:e=>oe(e),method:"uniform4fv",type:"vec4"}}),a($e,"onEffectMask",`
  float mask = clamp(shaderMask + width, 0.0, 1.0) - clamp(shaderMask, 0.0, 1.0);
  return mix(shaderColor, maskColor, mask);
  `),a($e,"onColorize",`
    return color;
  `);class de extends j{constructor(){super(...arguments);a(this,"name","linearGradient")}static getEffectKey(e){return`linearGradient${e.colors.length}`}static resolveDefaults(e){const o=e.colors??[4278190080,4294967295];let s=e.stops;if(!s){s=[];const i=o.length-1;for(let n=0;n<o.length;n++)s.push(n*(1/i))}return{colors:o,stops:s,angle:e.angle??0}}}a(de,"z$__type__Props"),a(de,"uniforms",{angle:{value:0,method:"uniform1f",type:"float"},colors:{value:4294967295,validator:e=>e.map(s=>oe(s)).reduce((s,i)=>s.concat(i),[]),size:e=>e.colors.length,method:"uniform4fv",type:"vec4"},stops:{value:[],validator:(e,o)=>{const s=o.colors??[];let i=e;const n=e;if(i.length===0||i&&i.length!==s.length){for(let l=0;l<s.length;l++)i[l]?(n[l]=i[l],i[l-1]===void 0&&n[l-2]!==void 0&&(n[l-1]=n[l-2]+(i[l]-n[l-2])/2)):n[l]=l*(1/(s.length-1));i=n}return n},size:e=>e.colors.length,method:"uniform1fv",type:"float"}}),a(de,"methods",{fromLinear:`
      vec4 function(vec4 linearRGB) {
        vec4 higher = vec4(1.055)*pow(linearRGB, vec4(1.0/2.4)) - vec4(0.055);
        vec4 lower = linearRGB * vec4(12.92);
        return mix(higher, lower, 1.0);
      }
    `,toLinear:`
      vec4 function(vec4 sRGB) {
        vec4 higher = pow((sRGB + vec4(0.055))/vec4(1.055), vec4(2.4));
        vec4 lower = sRGB/vec4(12.92);
        return mix(higher, lower, 1.0);
      }
    `,degToRad:`
      float function(float d) {
        return d * (PI / 180.0);
      }
    `,calcPoint:`
      vec2 function(float d, float angle) {
        return d * vec2(cos(angle), sin(angle)) + (u_dimensions * 0.5);
      }
    `}),a(de,"ColorLoop",e=>{let o="";for(let s=2;s<e;s++)o+=`colorOut = mix(colorOut, colors[${s}], clamp((dist - stops[${s-1}]) / (stops[${s}] - stops[${s-1}]), 0.0, 1.0));`;return o}),a(de,"onColorize",e=>`
      float d = angle - 90.0;
      float a = $degToRad(d);
      float lineDist = abs(u_dimensions.x * cos(a)) + abs(u_dimensions.y * sin(a));

      vec2 f = $calcPoint(lineDist * 0.5, a);
      vec2 t = $calcPoint(lineDist * 0.5, $degToRad(d + 180.0));
      vec2 gradVec = t - f;
      float dist = dot(v_textureCoordinate.xy * u_dimensions - f, gradVec) / dot(gradVec, gradVec);

      float stopCalc = (dist - stops[0]) / (stops[1] - stops[0]);
      vec4 colorOut = $fromLinear(mix($toLinear(colors[0]), $toLinear(colors[1]), stopCalc));
      for(int i = 1; i < ${e.colors.length||1}-1; i++) {
        stopCalc = (dist - stops[i]) / (stops[i + 1] - stops[i]);
        colorOut = mix(colorOut, colors[i + 1], clamp(stopCalc, 0.0, 1.0));
      }
      return mix(maskColor, colorOut, clamp(colorOut.a, 0.0, 1.0));
    `);class vo extends j{constructor(){super(...arguments);a(this,"name","grayscale")}static getEffectKey(){return"grayscale"}}a(vo,"onColorize",`
    vec3 color = pow(maskColor.rgb, vec3(2.0));
    float gray = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float gammaGray = sqrt(gray);
    return vec4(gammaGray, gammaGray, gammaGray, 1.0);
  `);class ue extends j{constructor(){super(...arguments);a(this,"name","borderRight")}static getEffectKey(){return"borderRight"}static resolveDefaults(e){return{width:e.width??10,color:e.color??4294967295}}}a(ue,"z$__type__Props"),a(ue,"uniforms",{width:{value:0,method:"uniform1f",type:"float"},color:{value:4294967295,validator:e=>oe(e),method:"uniform4fv",type:"vec4"}}),a(ue,"methods",{fillMask:`
      float function(float dist) {
        return clamp(-dist, 0.0, 1.0);
      }
    `,rectDist:`
      float function(vec2 p, vec2 size) {
        vec2 d = abs(p) - size;
        return min(max(d.x, d.y), 0.0) + length(max(d, 0.0));
      }
    `}),a(ue,"onEffectMask",`
  vec2 pos = vec2(u_dimensions.x - width * 0.5, 0.0);
  float mask = $rectDist(v_textureCoordinate.xy * u_dimensions - pos, vec2(width*0.5, u_dimensions.y));
  return mix(shaderColor, maskColor, $fillMask(mask));
  `),a(ue,"onColorize",`
    return color;
  `);class pe extends j{constructor(){super(...arguments);a(this,"name","borderTop")}static getEffectKey(){return"borderTop"}static resolveDefaults(e){return{width:e.width??10,color:e.color??4294967295}}}a(pe,"z$__type__Props"),a(pe,"uniforms",{width:{value:0,method:"uniform1f",type:"float"},color:{value:4294967295,validator:e=>oe(e),method:"uniform4fv",type:"vec4"}}),a(pe,"methods",{fillMask:`
      float function(float dist) {
        return clamp(-dist, 0.0, 1.0);
      }
    `,rectDist:`
      float function(vec2 p, vec2 size) {
        vec2 d = abs(p) - size;
        return min(max(d.x, d.y), 0.0) + length(max(d, 0.0));
      }
    `}),a(pe,"onEffectMask",`
  vec2 pos = vec2(0.0, width * 0.5);
  float mask = $rectDist(v_textureCoordinate.xy * u_dimensions - pos, vec2(u_dimensions.x, width*0.5));
  return mix(shaderColor, maskColor, $fillMask(mask));
  `),a(pe,"onColorize",`
    return color;
  `);class me extends j{constructor(){super(...arguments);a(this,"name","borderBottom")}static getEffectKey(){return"borderBottom"}static resolveDefaults(e){return{width:e.width??10,color:e.color??4294967295}}}a(me,"z$__type__Props"),a(me,"uniforms",{width:{value:0,method:"uniform1f",type:"float"},color:{value:4294967295,validator:e=>oe(e),method:"uniform4fv",type:"vec4"}}),a(me,"methods",{fillMask:`
      float function(float dist) {
        return clamp(-dist, 0.0, 1.0);
      }
    `,rectDist:`
      float function(vec2 p, vec2 size) {
        vec2 d = abs(p) - size;
        return min(max(d.x, d.y), 0.0) + length(max(d, 0.0));
      }
    `}),a(me,"onEffectMask",`
  vec2 pos = vec2(0.0, u_dimensions.y - width * 0.5);
  float mask = $rectDist(v_textureCoordinate.xy * u_dimensions - pos, vec2(u_dimensions.x, width*0.5));
  return mix(shaderColor, maskColor, $fillMask(mask));
  `),a(me,"onColorize",`
    return color;
  `);class xe extends j{constructor(){super(...arguments);a(this,"name","borderLeft")}static getEffectKey(){return"borderLeft"}static resolveDefaults(e){return{width:e.width??10,color:e.color??4294967295}}}a(xe,"z$__type__Props"),a(xe,"uniforms",{width:{value:0,method:"uniform1f",type:"float"},color:{value:4294967295,validator:e=>oe(e),method:"uniform4fv",type:"vec4"}}),a(xe,"methods",{fillMask:`
      float function(float dist) {
        return clamp(-dist, 0.0, 1.0);
      }
    `,rectDist:`
      float function(vec2 p, vec2 size) {
        vec2 d = abs(p) - size;
        return min(max(d.x, d.y), 0.0) + length(max(d, 0.0));
      }
    `}),a(xe,"onEffectMask",`
  vec2 pos = vec2(width * 0.5, 0.0);
  float mask = $rectDist(v_textureCoordinate.xy * u_dimensions - pos, vec2(width*0.5, u_dimensions.y));
  return mix(shaderColor, maskColor, $fillMask(mask));
  `),a(xe,"onColorize",`
    return color;
  `);class Te extends j{constructor(){super(...arguments);a(this,"name","glitch")}static getEffectKey(e){return"glitch"}static resolveDefaults(e){return{amplitude:e.amplitude??.2,narrowness:e.narrowness??4,blockiness:e.blockiness??2,minimizer:e.minimizer??8,time:e.time??Date.now()}}}a(Te,"z$__type__Props"),a(Te,"uniforms",{amplitude:{value:0,method:"uniform1f",type:"float"},narrowness:{value:0,method:"uniform1f",type:"float"},blockiness:{value:0,method:"uniform1f",type:"float"},minimizer:{value:0,method:"uniform1f",type:"float"},time:{value:0,method:"uniform1f",validator:e=>(Date.now()-e)%1e3,type:"float"}}),a(Te,"methods",{rand:`
      float function(vec2 p, float time) {
        float t = floor(time * 20.) / 10.;
        return fract(sin(dot(p, vec2(t * 12.9898, t * 78.233))) * 43758.5453);
      }
    `,noise:`
      float function(vec2 uv, float blockiness, float time) {
        vec2 lv = fract(uv);
        vec2 id = floor(uv);

        float n1 = rand(id, time);
        float n2 = rand(id+vec2(1,0), time);
        float n3 = rand(id+vec2(0,1), time);
        float n4 = rand(id+vec2(1,1), time);
        vec2 u = smoothstep(0.0, 1.0 + blockiness, lv);
        return mix(mix(n1, n2, u.x), mix(n3, n4, u.x), u.y);
      }
    `,fbm:`
      float function(vec2 uv, int count, float blockiness, float complexity, float time) {
        float val = 0.0;
        float amp = 0.5;
        const int MAX_ITERATIONS = 10;

        for(int i = 0; i < MAX_ITERATIONS; i++) {
          if(i >= count) {break;}
          val += amp * noise(uv, blockiness, time);
          amp *= 0.5;
          uv *= complexity;
        }
        return val;
      }
    `}),a(Te,"onColorize",`
    vec2 uv = v_textureCoordinate.xy;
    float aspect = u_dimensions.x / u_dimensions.y;
    vec2 a = vec2(uv.x * aspect , uv.y);
    vec2 uv2 = vec2(a.x / u_dimensions.x, exp(a.y));

    float shift = amplitude * pow($fbm(uv2, 4, blockiness, narrowness, time), minimizer);
    float colR = texture2D(u_texture, vec2(uv.x + shift, uv.y)).r * (1. - shift);
    float colG = texture2D(u_texture, vec2(uv.x - shift, uv.y)).g * (1. - shift);
    float colB = texture2D(u_texture, vec2(uv.x - shift, uv.y)).b * (1. - shift);

    vec3 f = vec3(colR, colG, colB);
    return vec4(f, texture2D(u_texture, vec2(uv.x - shift, uv.y)).a);
  `);class We extends j{constructor(){super(...arguments);a(this,"name","fadeOut")}static getEffectKey(){return"fadeOut"}static resolveDefaults(e){return{fade:e.fade??10}}}a(We,"z$__type__Props"),a(We,"uniforms",{fade:{value:0,method:"uniform4fv",type:"vec4",validator:e=>{let o=e;return Array.isArray(o)?o.length===2?o=[o[0],o[1],o[0],o[1]]:o.length===3?o=[o[0],o[1],o[2],o[0]]:o.length!==4&&(o=[o[0],o[0],o[0],o[0]]):typeof o=="number"&&(o=[o,o,o,o]),o}}}),a(We,"onColorize",`
  vec2 point = v_textureCoordinate.xy * u_dimensions.xy;
  vec2 pos1;
  vec2 pos2;
  vec2 d;
  float c;
  vec4 result = maskColor;


  if(fade[0] > 0.0) {
    pos1 = vec2(point.x, point.y);
    pos2 = vec2(point.x, point.y + fade[0]);
    d = pos2 - pos1;
    c = dot(pos1, d) / dot(d, d);
    result = mix(vec4(0.0), result, smoothstep(0.0, 1.0, clamp(c, 0.0, 1.0)));
  }

  if(fade[1] > 0.0) {
    pos1 = vec2(point.x - u_dimensions.x - fade[1], v_textureCoordinate.y);
    pos2 = vec2(point.x - u_dimensions.x, v_textureCoordinate.y);
    d = pos1 - pos2;
    c = dot(pos2, d) / dot(d, d);
    result = mix(vec4(0.0), result, smoothstep(0.0, 1.0, clamp(c, 0.0, 1.0)));
  }

  if(fade[2] > 0.0) {
    pos1 = vec2(v_textureCoordinate.x, point.y - u_dimensions.y - fade[2]);
    pos2 = vec2(v_textureCoordinate.x, point.y - u_dimensions.y);
    d = pos1 - pos2;
    c = dot(pos2, d) / dot(d, d);
    result = mix(vec4(0.0), result, smoothstep(0.0, 1.0, clamp(c, 0.0, 1.0)));
  }

  if(fade[3] > 0.0) {
    pos1 = vec2(point.x, point.y);
    pos2 = vec2(point.x + fade[3], point.y);
    d = pos2 - pos1;
    c = dot(pos1, d) / dot(d, d);
    result = mix(vec4(0.0), result, smoothstep(0.0, 1.0, clamp(c, 0.0, 1.0)));
  }

  return result;
  `);class He extends j{constructor(){super(...arguments);a(this,"name","radialGradient")}static getEffectKey(e){return`radialGradient${e.colors.length}`}static resolveDefaults(e){const o=e.colors??[4278190080,4294967295];let s=e.stops;if(!s){s=[];const i=o.length-1;for(let n=0;n<o.length;n++)s.push(n*(1/i))}return{colors:o,stops:s,width:e.width??0,height:e.height??e.width??0,pivot:e.pivot??[.5,.5]}}}a(He,"z$__type__Props"),a(He,"uniforms",{width:{value:0,method:"uniform1f",type:"float"},height:{value:0,method:"uniform1f",type:"float"},pivot:{value:[.5,.5],method:"uniform2fv",type:"vec2"},colors:{value:4294967295,validator:e=>e.map(s=>oe(s)).reduce((s,i)=>s.concat(i),[]),size:e=>e.colors.length,method:"uniform4fv",type:"vec4"},stops:{value:[],validator:(e,o)=>{const s=o.colors??[];let i=e;const n=e;if(i.length===0||i&&i.length!==s.length){for(let l=0;l<s.length;l++)i[l]?(n[l]=i[l],i[l-1]===void 0&&n[l-2]!==void 0&&(n[l-1]=n[l-2]+(i[l]-n[l-2])/2)):n[l]=l*(1/(s.length-1));i=n}return n},size:e=>e.colors.length,method:"uniform1fv",type:"float"}}),a(He,"onColorize",e=>`
      vec2 point = v_textureCoordinate.xy * u_dimensions;
      vec2 projection = vec2(pivot.x * u_dimensions.x, pivot.y * u_dimensions.y);

      float dist = length((point - projection) / vec2(width, height));

      float stopCalc = (dist - stops[0]) / (stops[1] - stops[0]);
      vec4 colorOut = mix(colors[0], colors[1], stopCalc);
      for(int i = 1; i < ${e.colors.length||1}-1; i++) {
        stopCalc = (dist - stops[i]) / (stops[i + 1] - stops[i]);
        colorOut = mix(colorOut, colors[i + 1], clamp(stopCalc, 0.0, 1.0));
      }
      return mix(maskColor, colorOut, clamp(colorOut.a, 0.0, 1.0));
    `);const ne={radius:fe,border:$e,borderBottom:me,borderLeft:xe,borderRight:ue,borderTop:pe,fadeOut:We,linearGradient:de,radialGradient:He,grayscale:vo,glitch:Te},ee=class ee extends ze{constructor(e,o){const s=ee.createShader(o);super({renderer:e,attributes:["a_position","a_textureCoordinate","a_color"],uniforms:[{name:"u_resolution",uniform:"uniform2fv"},{name:"u_pixelRatio",uniform:"uniform1f"},{name:"u_texture",uniform:"uniform2fv"},{name:"u_dimensions",uniform:"uniform2fv"},{name:"u_alpha",uniform:"uniform1f"},...s.uniforms],shaderSources:{vertex:s.vertex,fragment:s.fragment}});a(this,"effects",[]);this.effects=s.effects}bindTextures(e){const{gl:o}=this;o.activeTexture(o.TEXTURE0),o.bindTexture(o.TEXTURE_2D,e[0].ctxTexture)}bindProps(e){var o;(o=e.effects)==null||o.forEach((s,i)=>{const n=this.effects[i],l=ne[n.name],d=s.props??{},c=n.uniformInfo;Object.keys(d).forEach(h=>{const p=l.uniforms[h],m=c[h];let f=p.validator?p.validator(d[h],d):d[h];Array.isArray(f)&&(f=new Float32Array(f)),this.setUniform(m.name,f)})})}static createShader(e){const o={},s={};let i="";const n=[],l=[],d=e.effects.map(f=>{const g=ne[f.type],x=g.getEffectKey(f.props||{});o[x]=o[x]?++o[x]:1;const w=o[x];w===1&&l.push({key:x,type:f.type,props:f.props});const u=new g({ref:`${x}${w===1?"":w}`,target:x,props:f.props});return i+=u.declaredUniforms,n.push(...Object.values(u.uniformInfo)),u});let c="";l==null||l.forEach(f=>{const g=ne[f.type],x=g.resolveDefaults(f.props??{}),w=[];for(const L in g.methods){let F=L;const y=g.methods[L];s[L]&&s[L]!==y&&(F=ee.resolveMethodDuplicate(L,y,s)),s[F]=y.replace("function",F),w.push({m:L,cm:F})}let u=g.onShaderMask instanceof Function?g.onShaderMask(x):g.onShaderMask,C=g.onColorize instanceof Function?g.onColorize(x):g.onColorize,T=g.onEffectMask instanceof Function?g.onEffectMask(x):g.onEffectMask;w.forEach(L=>{const{m:F,cm:y}=L,k=new RegExp(`\\$${F}`,"g");u&&(u=u.replace(k,y)),C&&(C=C.replace(k,y)),T&&(T=T.replace(k,y))});const v=g.getMethodParameters(g.uniforms,x),M=v.length>0?`, ${v}`:"";u&&(c+=`
        float fx_${f.key}_onShaderMask(float shaderMask ${M}) {
          ${u}
        }
        `),C&&(c+=`
          vec4 fx_${f.key}_onColorize(float shaderMask, vec4 maskColor, vec4 shaderColor${M}) {
            ${C}
          }
        `),T&&(c+=`
          vec4 fx_${f.key}_onEffectMask(float shaderMask, vec4 maskColor, vec4 shaderColor${M}) {
            ${T}
          }
        `)});let h="";for(const f in s)h+=s[f];let p="mix(shaderColor, maskColor, clamp(-(lng_DefaultMask), 0.0, 1.0))",m=`

    `;for(let f=0;f<d.length;f++){const g=d[f],x=g.passParameters.length>0?`, ${g.passParameters}`:"",w=ne[g.name];w.onShaderMask&&(m+=`
        shaderMask = fx_${g.target}_onShaderMask(shaderMask ${x});
        `),w.onColorize&&(m+=`
        maskColor = fx_${g.target}_onColorize(shaderMask, maskColor, shaderColor${x});
        `),w.onEffectMask&&(p=`fx_${g.target}_onEffectMask(shaderMask, maskColor, shaderColor${x})`);const u=d[f+1];(u===void 0||ne[u.name].onEffectMask)&&(m+=`
          shaderColor = ${p};
        `)}return{effects:d,uniforms:n,fragment:ee.fragment(i,h,c,m),vertex:ee.vertex()}}static resolveMethodDuplicate(e,o,s,i=0){const n=e+(i>0?i:"");return s[n]&&s[n]!==o?this.resolveMethodDuplicate(e,o,s,++i):n}static resolveDefaults(e){return{effects:(e.effects??[]).map(o=>({type:o.type,props:ne[o.type].resolveDefaults(o.props||{})})),$dimensions:{width:0,height:0},$alpha:0}}static makeCacheKey(e){var s;let o="";return(s=e.effects)==null||s.forEach(i=>{const l=ne[i.type].getEffectKey(i.props||{});o+=`,${l}`}),`DynamicShader${o}`}};a(ee,"z$__type__Props"),a(ee,"vertex",()=>`
    # ifdef GL_FRAGMENT_PRESICISON_HIGH
    precision highp float;
    # else
    precision mediump float;
    # endif

    attribute vec2 a_textureCoordinate;
    attribute vec2 a_position;
    attribute vec4 a_color;
    attribute float a_textureIndex;

    uniform vec2 u_resolution;
    uniform float u_pixelRatio;

    varying vec4 v_color;
    varying vec2 v_textureCoordinate;
    varying float v_textureIndex;

    void main(){
      vec2 normalized = a_position * u_pixelRatio / u_resolution;
      vec2 zero_two = normalized * 2.0;
      vec2 clip_space = zero_two - 1.0;

      // pass to fragment
      v_color = a_color;
      v_textureCoordinate = a_textureCoordinate;
      v_textureIndex = a_textureIndex;

      // flip y
      gl_Position = vec4(clip_space * vec2(1.0, -1.0), 0, 1);
    }
  `),a(ee,"fragment",(e,o,s,i)=>`
    # ifdef GL_FRAGMENT_PRESICISON_HIGH
    precision highp float;
    # else
    precision mediump float;
    # endif

    #define PI 3.14159265359

    uniform vec2 u_resolution;
    uniform vec2 u_dimensions;
    uniform float u_alpha;
    uniform float u_radius;
    uniform sampler2D u_texture;
    uniform float u_pixelRatio;

    ${e}

    varying vec4 v_color;
    varying vec2 v_textureCoordinate;

    ${o}

    ${s}

    void main() {
      vec2 p = v_textureCoordinate.xy * u_dimensions - u_dimensions * 0.5;
      vec2 d = abs(p) - (u_dimensions) * 0.5;
      float lng_DefaultMask = min(max(d.x, d.y), 0.0) + length(max(d, 0.0));

      vec4 shaderColor = vec4(0.0);
      float shaderMask = lng_DefaultMask;

      vec4 maskColor = texture2D(u_texture, v_textureCoordinate) * v_color;

      shaderColor = mix(shaderColor, maskColor, clamp(-(lng_DefaultMask + 0.5), 0.0, 1.0));

      ${i}

      gl_FragColor = shaderColor * u_alpha;
    }
  `);let nt=ee;class at extends ze{constructor(t){super({renderer:t,attributes:["a_position","a_textureCoordinate","a_color"],uniforms:[{name:"u_resolution",uniform:"uniform2fv"},{name:"u_pixelRatio",uniform:"uniform1f"},{name:"u_texture",uniform:"uniform2f"},{name:"u_dimensions",uniform:"uniform2fv"},{name:"u_radius",uniform:"uniform1f"}]})}static resolveDefaults(t){return{radius:t.radius||10,$dimensions:{width:0,height:0}}}bindTextures(t){const{gl:e}=this;e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,t[0].ctxTexture)}bindProps(t){this.setUniform("u_radius",t.radius)}canBatchShaderProps(t,e){return t.radius===e.radius&&t.$dimensions.width===e.$dimensions.width&&t.$dimensions.height===e.$dimensions.height}}a(at,"z$__type__Props"),a(at,"shaderSources",{vertex:`
      # ifdef GL_FRAGMENT_PRESICISON_HIGH
      precision highp float;
      # else
      precision mediump float;
      # endif

      attribute vec2 a_position;
      attribute vec2 a_textureCoordinate;
      attribute vec4 a_color;
      attribute float a_textureIndex;
      attribute float a_depth;

      uniform vec2 u_resolution;
      uniform float u_pixelRatio;

      varying vec4 v_color;
      varying vec2 v_textureCoordinate;

      void main() {
        vec2 normalized = a_position * u_pixelRatio / u_resolution;
        vec2 zero_two = normalized * 2.0;
        vec2 clip_space = zero_two - 1.0;

        // pass to fragment
        v_color = a_color;
        v_textureCoordinate = a_textureCoordinate;

        // flip y
        gl_Position = vec4(clip_space * vec2(1.0, -1.0), 0, 1);
      }
    `,fragment:`
      # ifdef GL_FRAGMENT_PRESICISON_HIGH
      precision highp float;
      # else
      precision mediump float;
      # endif

      uniform vec2 u_resolution;
      uniform vec2 u_dimensions;
      uniform float u_radius;
      uniform sampler2D u_texture;

      varying vec4 v_color;
      varying vec2 v_textureCoordinate;

      float boxDist(vec2 p, vec2 size, float radius){
        size -= vec2(radius);
        vec2 d = abs(p) - size;
        return min(max(d.x, d.y), 0.0) + length(max(d, 0.0)) - radius;
      }

      float fillMask(float dist) {
        return clamp(-dist, 0.0, 1.0);
      }

      void main() {
        vec4 color = texture2D(u_texture, v_textureCoordinate) * v_color;
        vec2 halfDimensions = u_dimensions * 0.5;

        float d = boxDist(v_textureCoordinate.xy * u_dimensions - halfDimensions, halfDimensions + 0.5, u_radius);
        gl_FragColor = mix(vec4(0.0), color, fillMask(d));
      }
    `});const Ke=class Ke extends ze{constructor(t){super({renderer:t,attributes:["a_position","a_textureCoordinate"],uniforms:[{name:"u_resolution",uniform:"uniform2fv"},{name:"u_pixelRatio",uniform:"uniform1f"},{name:"u_texture",uniform:"uniform2f"},{name:"u_offset",uniform:"uniform2fv"},{name:"u_color",uniform:"uniform4fv"},{name:"u_size",uniform:"uniform1f"},{name:"u_distanceRange",uniform:"uniform1f"},{name:"u_debug",uniform:"uniform1i"}]})}bindTextures(t){const{gl:e}=this;e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,t[0].ctxTexture)}bindProps(t){const e=Ke.resolveDefaults(t);for(const o in e)if(o==="offset")this.setUniform("u_offset",e[o]);else if(o==="color"){const s=oe(e.color);this.setUniform("u_color",s)}else o==="size"?this.setUniform("u_size",e[o]):o==="distanceRange"?this.setUniform("u_distanceRange",e[o]):o==="debug"&&this.setUniform("u_debug",e[o]?1:0)}static resolveDefaults(t={}){return{offset:t.offset??[0,0],color:t.color??4294967295,size:t.size??16,distanceRange:t.distanceRange??1,debug:t.debug??!1}}};a(Ke,"shaderSources",{vertex:`
      // an attribute is an input (in) to a vertex shader.
      // It will receive data from a buffer
      attribute vec2 a_position;
      attribute vec2 a_textureCoordinate;

      uniform vec2 u_offset;
      uniform vec2 u_resolution;
      uniform float u_pixelRatio;
      uniform float u_size;

      varying vec2 v_texcoord;

      void main() {
        gl_Position = vec4(((a_position * u_size + u_offset) * u_pixelRatio / u_resolution * 2.0 - 1.0) * vec2(1, -1), 0, 1);
        v_texcoord = a_textureCoordinate;
      }
    `,fragment:`
      precision highp float;

      uniform vec4 u_color;
      uniform sampler2D u_texture;
      uniform float u_distanceRange;
      uniform float u_pixelRatio;
      uniform int u_debug;

      varying vec2 v_texcoord;

      float median(float r, float g, float b) {
          return max(min(r, g), min(max(r, g), b));
      }

      void main() {
          vec3 sample = texture2D(u_texture, v_texcoord).rgb;
          if (u_debug == 1) {
            gl_FragColor = vec4(sample.r, sample.g, sample.b, 1.0);
            return;
          }
          float scaledDistRange = u_distanceRange * u_pixelRatio;
          float sigDist = scaledDistRange * (median(sample.r, sample.g, sample.b) - 0.5);
          float opacity = clamp(sigDist + 0.5, 0.0, 1.0) * u_color.a;

          // Build the final color.
          // IMPORTANT: We must premultiply the color by the alpha value before returning it.
          gl_FragColor = vec4(u_color.r * opacity, u_color.g * opacity, u_color.b * opacity, opacity);
      }
    `});let lt=Ke;class ur{constructor(){a(this,"shCache",new Map);a(this,"shConstructors",{});a(this,"attachedShader",null);a(this,"renderer");this.registerShaderType("DefaultShader",bo),this.registerShaderType("DefaultShaderBatched",_o),this.registerShaderType("RoundedRectangle",at),this.registerShaderType("DynamicShader",nt),this.registerShaderType("SdfShader",lt)}registerShaderType(t,e){this.shConstructors[t]=e}loadShader(t,e){if(!this.renderer)throw new Error("Renderer is not been defined");const o=this.shConstructors[t];if(!o)throw new Error(`Shader type "${t}" is not registered`);const s=o.resolveDefaults(e),i=o.makeCacheKey(s)||o.name;if(i&&this.shCache.has(i))return{shader:this.shCache.get(i),props:s};const n=new o(this.renderer,e);return i&&this.shCache.set(i,n),{shader:n,props:s}}useShader(t){this.attachedShader!==t&&(this.attachedShader&&this.attachedShader.detach(),t.attach(),this.attachedShader=t)}}class pr{constructor(){a(this,"activeAnimations",new Set)}registerAnimation(t){this.activeAnimations.add(t)}unregisterAnimation(t){this.activeAnimations.delete(t)}update(t){this.activeAnimations.forEach(e=>{e.update(t)})}}const ke=class ke extends ho{constructor(e,o){super(e);a(this,"props");this.props=ke.resolveDefaults(o)}async getTextureData(){const{src:e,premultiplyAlpha:o}=this.props;if(!e)return{data:null};if(e instanceof ImageData)return{data:e,premultiplyAlpha:o};const i=await(await fetch(e)).blob();return{data:await createImageBitmap(i,{premultiplyAlpha:o?"premultiply":"none",colorSpaceConversion:"none",imageOrientation:"none"})}}static makeCacheKey(e){const o=ke.resolveDefaults(e);return o.src instanceof ImageData?!1:`ImageTexture,${o.src},${o.premultiplyAlpha}`}static resolveDefaults(e){return{src:e.src??"",premultiplyAlpha:e.premultiplyAlpha??!0}}};a(ke,"z$__type__Props");let ct=ke;const Ie=class Ie extends ho{constructor(e,o){super(e);a(this,"props");this.props=Ie.resolveDefaults(o)}async getTextureData(){const{width:e,height:o}=this.props,s=e*o*4,i=new Uint8ClampedArray(s);for(let n=0;n<s;n+=4){const l=Math.floor(Math.random()*256);i[n]=l,i[n+1]=l,i[n+2]=l,i[n+3]=255}return{data:new ImageData(i,e,o)}}static makeCacheKey(e){const o=Ie.resolveDefaults(e);return`NoiseTexture,${o.width},${o.height},${o.cacheId}`}static resolveDefaults(e){return{width:e.width??128,height:e.height??128,cacheId:e.cacheId??0}}};a(Ie,"z$__type__Props");let ht=Ie;class mr{constructor(){a(this,"usedMemory",0);a(this,"txConstructors",{});a(this,"textureKeyCache",new Map);a(this,"textureIdCache",new Map);a(this,"ctxTextureCache",new WeakMap);a(this,"textureRefCountMap",new WeakMap);a(this,"renderer");this.registerTextureType("ImageTexture",ct),this.registerTextureType("ColorTexture",Uo),this.registerTextureType("NoiseTexture",ht),this.registerTextureType("SubTexture",qo)}registerTextureType(t,e){this.txConstructors[t]=e}loadTexture(t,e,o=null){const s=this.txConstructors[t];if(!s)throw new Error(`Texture type "${t}" is not registered`);let i;if((o==null?void 0:o.id)!==void 0&&this.textureIdCache.has(o.id)&&(i=this.textureIdCache.get(o.id)),!i){const n=o==null?void 0:o.id,l=(o==null?void 0:o.cacheKey)??s.makeCacheKey(e);l&&this.textureKeyCache.has(l)?i=this.textureKeyCache.get(l):i=new s(this,e),n&&this.addTextureIdToCache(n,l,i)}return o!=null&&o.preload&&this.getCtxTexture(i).load(),i}addTextureIdToCache(t,e,o){const{textureIdCache:s,textureRefCountMap:i}=this;s.set(t,o),i.has(o)?i.get(o).count++:(i.set(o,{cacheKey:e,count:1}),e&&this.textureKeyCache.set(e,o))}removeTextureIdFromCache(t){const{textureIdCache:e,textureRefCountMap:o}=this,s=e.get(t);if(s&&(e.delete(t),o.has(s))){const i=o.get(s);_(i),i.count--,i.count===0&&(o.delete(s),i.cacheKey&&this.textureKeyCache.delete(i.cacheKey))}}getDebugInfo(){return{keyCacheSize:this.textureKeyCache.size,idCacheSize:this.textureIdCache.size}}getCtxTexture(t){if(this.ctxTextureCache.has(t))return this.ctxTextureCache.get(t);const e=this.renderer.createCtxTexture(t);return this.ctxTextureCache.set(t,e),e}}class Eo{constructor(t){a(this,"textRenderers");this.textRenderers=t}addFontFace(t){for(const e in this.textRenderers){const o=this.textRenderers[e];o&&o.isFontFaceSupported(t)&&o.addFontFace(t)}}static resolveFontFace(t,e){const o=[];return t.reduce((i,n)=>{if(i)return i;const l=n[e.fontFamily];if(!l)return;const d=new Set(l);for(const c of d)(c.descriptors.stretch!==e.fontStretch||c.descriptors.style!==e.fontStyle||c.descriptors.weight!==e.fontWeight)&&d.delete(c);return d.values().next().value},void 0)||o[0]}}const xr={x:(r,t)=>{r.props.x=t},y:(r,t)=>{r.props.y=t},width:(r,t)=>{r.props.width=t},height:(r,t)=>{r.props.height=t},color:(r,t)=>{r.props.color=t},alpha:(r,t)=>{r.props.alpha=t},zIndex:(r,t)=>{r.props.zIndex=t},fontFamily:(r,t)=>{r.props.fontFamily=t},fontWeight:(r,t)=>{r.props.fontWeight=t},fontStyle:(r,t)=>{r.props.fontStyle=t},fontStretch:(r,t)=>{r.props.fontStretch=t},fontSize:(r,t)=>{r.props.fontSize=t},text:(r,t)=>{r.props.text=t},textAlign:(r,t)=>{r.props.textAlign=t},contain:(r,t)=>{r.props.contain=t},offsetY:(r,t)=>{r.props.offsetY=t},scrollable:(r,t)=>{r.props.scrollable=t},scrollY:(r,t)=>{r.props.scrollY=t},letterSpacing:(r,t)=>{r.props.letterSpacing=t},debug:(r,t)=>{r.props.debug=t}};class $o{constructor(t){a(this,"stage");a(this,"set");this.stage=t,this.set=Object.freeze({...xr,...this.getPropertySetters()})}setStatus(t,e,o){t.status!==e&&(t.status=e,t.emitter.emit(e,o))}}const gr=24;function yr(r,t,e,o,s,i,n){let l=0;s&&(l=Math.min(Math.max(Math.floor(s.y1/r),0),i.length));const d=0,c=t/e+l*o;if(!(n&&c>=n/e))return{x:d,y:c,lineIndex:l}}class Ue{constructor(t,e=0){a(this,"iterator");a(this,"peekBuffer",[]);a(this,"_lastIndex");this.iterator=t,this.iterator=t,this._lastIndex=e-1,this.peekBuffer=[]}next(){const t=this.peekBuffer.length>0?this.peekBuffer.pop():this.iterator.next();return t.done?this._lastIndex=-1:this._lastIndex++,t}peek(){if(this.peekBuffer.length>0)return this.peekBuffer[0];const t=this.iterator.next();return this.peekBuffer.push(t),t}get lastIndex(){return this._lastIndex}}function*qe(r,t=0){let e=t;for(;e<r.length;){const o=r.codePointAt(e);if(o===void 0)throw new Error("Invalid Unicode code point");yield o,e+=o<=65535?1:2}}function wr(r,t,e){const o=e.shapeText(t,new Ue(qe(r,0),0));let s=0;for(const i of o)i.mapped&&(s+=i.xAdvance);return s}function br(r,t,e,o,s,i,n,l,d,c,h,p,m,f,g,x){_(f,"Font face must be loaded"),_(f.loaded,"Font face must be loaded"),_(f.data,"Font face must be loaded"),_(f.shaper,"Font face must be loaded");const w=f.data.info.size,u=l/w,C=i/u,T=d/u,v=p[r],M=(v==null?void 0:v.codepointIndex)||0,L=(v==null?void 0:v.maxX)||0,F=(v==null?void 0:v.maxY)||0;let y=L,k=F,z=t,P=e,$=0;const I={codepointIndex:-1,bufferOffset:-1,xStart:-1},D=f.shaper,B={letterSpacing:T};let U=D.shapeText(B,new Ue(qe(o,M),M)),X,re=-1;const we=[],_t="...",Do=n/u,Bo=wr(_t,B,D);let Oe=!0;for(;Oe;){const ie=h!=="both"||x||P+w+w<=Do,Z=ie?C:C-Bo;let Y=0;for(;(X=U.next())&&!X.done;){const N=X.value;if(r===p.length)p.push({codepointIndex:N.cluster,maxY:k,maxX:y});else if(r>p.length)throw new Error("Unexpected lineCache length");if(N.codepoint===32||N.codepoint===10?I.codepointIndex!==-1&&(I.codepointIndex=-1,Y=z):I.codepointIndex===-1&&(I.codepointIndex=N.cluster,I.bufferOffset=$,I.xStart=Y),N.mapped){const be=z+N.xOffset+N.width;if(h!=="none"&&be>=Z&&I.codepointIndex!==-1&&I.codepointIndex<N.cluster&&I.xStart>0)if(ie){U=D.shapeText(B,new Ue(qe(o,I.codepointIndex),I.codepointIndex)),$=I.bufferOffset;break}else U=D.shapeText(B,new Ue(qe(_t,0),0)),z=I.xStart,$=I.bufferOffset;else{const K=z+N.xOffset,_e=P+N.yOffset,jo=m?P+w>=m.y1/u:!0,Yo=m?P<=m.y2/u:!0;if(jo&&Yo){re===-1&&(re=$);const Le=f.getAtlasEntry(N.glyphId),Fe=Le.x/f.data.common.scaleW,Ne=Le.y/f.data.common.scaleH,vt=Le.width/f.data.common.scaleW,Et=Le.height/f.data.common.scaleH;c[$++]=K,c[$++]=_e,c[$++]=Fe,c[$++]=Ne,c[$++]=K+N.width,c[$++]=_e,c[$++]=Fe+vt,c[$++]=Ne,c[$++]=K,c[$++]=_e+N.height,c[$++]=Fe,c[$++]=Ne+Et,c[$++]=K+N.width,c[$++]=_e+N.height,c[$++]=Fe+vt,c[$++]=Ne+Et}k=Math.max(k,_e+N.height),z+=N.xAdvance,y=Math.max(y,z)}}else if(N.codepoint===10)break}re!==-1&&(we.push({bufferStart:re,bufferEnd:$}),re=-1),z=0,P+=w,r++,I.codepointIndex=-1,Y=0,(!g&&h==="both"&&m&&P>m.y2/u||X&&X.done||h==="both"&&!x&&!ie)&&(Oe=!1)}if(s==="center"){const ie=h==="none"?y:C;for(let Z=0;Z<we.length;Z++){const Y=we[Z],N=c[Y.bufferEnd-4]-c[Y.bufferStart],be=(ie-N)/2;for(let K=Y.bufferStart;K<Y.bufferEnd;K+=4)c[K]+=be}}else if(s==="right"){const ie=h==="none"?y:C;for(let Z=0;Z<we.length;Z++){const Y=we[Z],N=Y.bufferEnd===Y.bufferStart?0:c[Y.bufferEnd-4]-c[Y.bufferStart],be=ie-N;for(let K=Y.bufferStart;K<Y.bufferEnd;K+=4)c[K]+=be}}return _(X),{bufferNumFloats:$,bufferNumQuads:$/16,layoutNumCharacters:X.done?o.length-M:X.value.cluster-M+1,fullyProcessed:!!X.done,maxX:y,maxY:k}}function _r(r,t,e,o,s,i){const n=o*s,l=i.x1-r,d=i.y1-t;return Go(i)?{x1:l,y1:d+e-n,x2:l+(i.x2-i.x1),y2:d+e+(i.y2-i.y1)+n}:{x1:0,y1:0,x2:0,y2:0}}class vr extends $o{constructor(e){super(e);a(this,"ssdfFontFamilies",{});a(this,"msdfFontFamilies",{});a(this,"sdfShader");this.sdfShader=this.stage.shManager.loadShader("SdfShader").shader}getPropertySetters(){return{fontFamily:(e,o)=>{e.props.fontFamily=o,e.trFontFace=void 0,this.invalidateCache(e)},fontWeight:(e,o)=>{e.props.fontWeight=o,e.trFontFace=void 0,this.invalidateCache(e)},fontStyle:(e,o)=>{e.props.fontStyle=o,e.trFontFace=void 0,this.invalidateCache(e)},fontStretch:(e,o)=>{e.props.fontStretch=o,e.trFontFace=void 0,this.invalidateCache(e)},fontSize:(e,o)=>{e.props.fontSize=o,this.invalidateCache(e)},text:(e,o)=>{e.props.text=o,this.invalidateCache(e)},textAlign:(e,o)=>{e.props.textAlign=o,this.invalidateCache(e)},color:(e,o)=>{e.props.color=o},alpha:(e,o)=>{e.props.alpha=o},x:(e,o)=>{e.props.x=o},y:(e,o)=>{e.props.y=o},contain:(e,o)=>{e.props.contain=o,this.invalidateCache(e)},width:(e,o)=>{e.props.width=o,this.invalidateCache(e)},height:(e,o)=>{e.props.height=o,this.invalidateCache(e)},offsetY:(e,o)=>{e.props.offsetY=o,this.invalidateCache(e)},scrollable:(e,o)=>{e.props.scrollable=o,this.invalidateCache(e)},scrollY:(e,o)=>{e.props.scrollY=o},letterSpacing:(e,o)=>{e.props.letterSpacing=o,this.invalidateCache(e)},debug:(e,o)=>{e.props.debug=o}}}canRenderFont(e){const{fontFamily:o}=e;return o in this.ssdfFontFamilies||o in this.msdfFontFamilies||o==="$$SDF_FAILURE_TEST$$"}isFontFaceSupported(e){return e instanceof Tt}addFontFace(e){_(e instanceof Tt);const o=e.fontFamily,s=e.type==="ssdf"?this.ssdfFontFamilies:e.type==="msdf"?this.msdfFontFamilies:void 0;if(!s){console.warn(`Invalid font face type: ${e.type}`);return}let i=s[o];i||(i=new Set,s[o]=i),i.add(e)}createState(e){return{props:e,status:"initialState",emitter:new Me,lineCache:[],forceFullLayoutCalc:!1,renderWindow:void 0,bufferNumFloats:0,bufferNumQuads:0,vertexBuffer:void 0,webGlBuffers:null,bufferUploaded:!1,textH:void 0,textW:void 0,distanceRange:0,trFontFace:void 0,debugData:{updateCount:0,layoutCount:0,lastLayoutNumCharacters:0,layoutSum:0,drawSum:0,drawCount:0,bufferSize:0}}}updateState(e){performance.now();let{trFontFace:o}=e;const{textH:s,lineCache:i,debugData:n,forceFullLayoutCalc:l}=e;if(n.updateCount++,e.status==="initialState"&&this.setStatus(e,"loading"),!o&&(o=this.resolveFontFace(e.props),e.trFontFace=o,!o)){const D=`SdfTextRenderer: Could not resolve font face for family: '${e.props.fontFamily}'`;console.error(D),this.setStatus(e,"failed",new Error(D));return}if(!o.loaded){o.on("loaded",function D(){e.emitter.emit("fontLoaded",{}),o==null||o.off("fontLoaded",D)});return}_(o.data,"Font face data should be loaded");const{text:d,fontSize:c,x:h,y:p,contain:m,width:f,height:g,scrollable:x}=e.props,w=m==="both"&&x?e.props.scrollY:0;let{renderWindow:u}=e;const C=o.data.info.size,T=c/C;e.distanceRange=T*o.data.distanceField.distanceRange;const v=d.length*gr;let M=e.vertexBuffer;(!M||M.length<v)&&(M=new Float32Array(v*2));const L={x1:0,y1:0,x2:this.stage.options.appWidth,y2:this.stage.options.appHeight},F={x1:h,y1:p,x2:m!=="none"?h+f:1/0,y2:m==="both"?p+g:1/0},y=fo(L,F);if(!l&&u){if(h+u.x1<=y.x1&&h+u.x2>=y.x2&&p-w+u.y1<=y.y1&&p-w+u.y2>=y.y2)return;e.renderWindow=u=void 0}const{offsetY:k,textAlign:z}=e.props;if(!u){const D=y.y2-y.y1,B=Math.ceil(D/C);u=_r(h,p,w,C,B,y)}const P=yr(c,k,T,C,u,i,s);if(!P){this.setStatus(e,"loaded");return}const{letterSpacing:$}=e.props,I=br(P.lineIndex,P.x,P.y,d,z,f,g,c,$,M,m,i,u,o,l,x);e.bufferUploaded=!1,e.bufferNumFloats=I.bufferNumFloats,e.bufferNumQuads=I.bufferNumQuads,e.vertexBuffer=M,e.renderWindow=u,n.lastLayoutNumCharacters=I.layoutNumCharacters,n.bufferSize=M.byteLength,I.fullyProcessed&&(e.textW=I.maxX*T,e.textH=I.maxY*T),this.setStatus(e,"loaded")}renderQuads(e,o){var D,B;if(!e.vertexBuffer)return;performance.now();const{renderer:s}=this.stage;this.stage.options;const{fontSize:i,color:n,alpha:l,x:d,y:c,contain:h,width:p,height:m,scrollable:f,zIndex:g,debug:x}=e.props,w=h==="both"&&f?e.props.scrollY:0,{textW:u=0,textH:C=0,distanceRange:T,vertexBuffer:v,bufferNumFloats:M,bufferUploaded:L,renderWindow:F,debugData:y,trFontFace:k}=e;let{webGlBuffers:z}=e;if(!z){const U=s.gl,X=4*Float32Array.BYTES_PER_ELEMENT,re=U.createBuffer();_(re),e.webGlBuffers=new Ko([{buffer:re,attributes:{a_position:{name:"a_position",size:2,type:U.FLOAT,normalized:!1,stride:X,offset:0},a_textureCoordinate:{name:"a_textureCoordinate",size:2,type:U.FLOAT,normalized:!1,stride:X,offset:2*Float32Array.BYTES_PER_ELEMENT}}}]),e.bufferUploaded=!1,_(e.webGlBuffers),z=e.webGlBuffers}if(!L){const U=s.gl,X=(z==null?void 0:z.getBuffer("a_textureCoordinate"))??null;U.bindBuffer(U.ARRAY_BUFFER,X),U.bufferData(U.ARRAY_BUFFER,v,U.STATIC_DRAW),e.bufferUploaded=!0}_(k);const P=new Vo(s.gl,s.options,z,this.sdfShader,{color:Qo(n,l),size:i/(((D=k.data)==null?void 0:D.info.size)||0),offset:[d,c-w],distanceRange:T,debug:x.sdfShaderDebug},l,o,{height:C,width:u},0,g),$=(B=e.trFontFace)==null?void 0:B.texture;_($);const I=this.stage.txManager.getCtxTexture($);P.addTexture(I),P.length=e.bufferNumFloats,P.numQuads=e.bufferNumQuads,s.addRenderable(P)}resolveFontFace(e){return Eo.resolveFontFace([this.msdfFontFamilies,this.ssdfFontFamilies],e)}invalidateCache(e){e.renderWindow=void 0,e.textH=void 0,e.textW=void 0,e.lineCache=[],this.setStatus(e,"loading")}}const Ct=2048;class Er{constructor(t,e){a(this,"_canvas");a(this,"_context");a(this,"_settings");a(this,"renderInfo");this._canvas=t,this._context=e,this._settings=this.mergeDefaults({})}set settings(t){this._settings=this.mergeDefaults(t)}get settings(){return this._settings}getPrecision(){return this._settings.precision}setFontProperties(){this._context.font=this._getFontSetting(),this._context.textBaseline=this._settings.textBaseline}_getFontSetting(){const t=[this._settings.fontFace],e=[];for(let o=0,s=t.length;o<s;o++)t[o]==="serif"||t[o]==="sans-serif"?e.push(t[o]):e.push(`"${t[o]}"`);return`${this._settings.fontStyle} ${this._settings.fontSize*this.getPrecision()}px ${e.join(",")}`}_load(){if(document.fonts){const t=this._getFontSetting();try{if(!document.fonts.check(t,this._settings.text))return document.fonts.load(t,this._settings.text).catch(e=>{console.warn("[Lightning] Font load error",e,t)}).then(()=>{document.fonts.check(t,this._settings.text)||console.warn("[Lightning] Font not found",t)})}catch{console.warn("[Lightning] Can't check font loading for "+t)}}}calculateRenderInfo(){const t={},e=this.getPrecision(),o=this._settings.paddingLeft*e,s=this._settings.paddingRight*e,i=this._settings.fontSize*e;let n=this._settings.offsetY===null?null:this._settings.offsetY*e,l=(this._settings.lineHeight||i)*e;const d=this._settings.w*e,c=this._settings.h*e;let h=this._settings.wordWrapWidth*e;const p=this._settings.cutSx*e,m=this._settings.cutEx*e,f=this._settings.cutSy*e,g=this._settings.cutEy*e,x=(this._settings.letterSpacing||0)*e,w=this._settings.textIndent*e;this.setFontProperties();let u=d||2048/this.getPrecision(),C=u-o;if(C<10&&(u+=10-C,C=10),h||(h=C),this._settings.textOverflow&&!this._settings.wordWrap){let y;switch(this._settings.textOverflow){case"clip":y="";break;case"ellipsis":y=this._settings.maxLinesSuffix;break;default:y=this._settings.textOverflow}this._settings.text=this.wrapWord(this._settings.text,h-w,y)}let T;if(this._settings.wordWrap)T=this.wrapText(this._settings.text,h,x,w);else{T={l:this._settings.text.split(/(?:\r\n|\r|\n)/),n:[]};const y=T.l.length;for(let k=0;k<y-1;k++)T.n.push(k)}let v=T.l;if(this._settings.maxLines&&v.length>this._settings.maxLines){const y=v.slice(0,this._settings.maxLines);let k=null;if(this._settings.maxLinesSuffix){const D=this._settings.maxLinesSuffix?this.measureText(this._settings.maxLinesSuffix):0,B=this.wrapText(y[y.length-1],h-D,x,w);y[y.length-1]=`${B.l[0]}${this._settings.maxLinesSuffix}`,k=[B.l.length>1?B.l[1]:""]}else k=[""];let z;const P=v.length;let $=0;const I=T.n.length;for(z=this._settings.maxLines;z<P;z++)k[$]+=`${k[$]?" ":""}${v[z]}`,z+1<I&&T.n[z+1]&&$++;t.remainingText=k.join(`
`),t.moreTextLines=!0,v=y}else t.moreTextLines=!1,t.remainingText="";let M=0;const L=[];for(let y=0;y<v.length;y++){const k=this.measureText(v[y],x)+(y===0?w:0);L.push(k),M=Math.max(M,k)}t.lineWidths=L,d||(u=M+o+s,C=M),l=l||i;let F;if(c)F=c;else{const y=this._settings.textBaseline!="bottom"?.5*i:0;F=l*(v.length-1)+y+Math.max(l,i)+(n||0)}return n===null&&(n=i),t.w=u,t.h=F,t.lines=v,t.precision=e,u||(u=1),F||(F=1),(p||m)&&(u=Math.min(u,m-p)),(f||g)&&(F=Math.min(F,g-f)),t.width=u,t.innerWidth=C,t.height=F,t.fontSize=i,t.cutSx=p,t.cutSy=f,t.cutEx=m,t.cutEy=g,t.lineHeight=l,t.lineWidths=L,t.offsetY=n,t.paddingLeft=o,t.paddingRight=s,t.letterSpacing=x,t.textIndent=w,t}draw(t,e){const o=this.getPrecision(),s=(e==null?void 0:e.lines)||t.lines,i=(e==null?void 0:e.lineWidths)||t.lineWidths,n=e?e.lines.length*t.lineHeight:t.height;this._canvas.width=Math.min(Math.ceil(t.width+this._settings.textRenderIssueMargin),Ct),this._canvas.height=Math.min(Math.ceil(n),Ct),this.setFontProperties(),t.fontSize>=128&&(this._context.globalAlpha=.01,this._context.fillRect(0,0,.01,.01),this._context.globalAlpha=1),(t.cutSx||t.cutSy)&&this._context.translate(-t.cutSx,-t.cutSy);let l,d;const c=[];for(let p=0,m=s.length;p<m;p++)l=p===0?t.textIndent:0,d=p*t.lineHeight+t.offsetY,this._settings.verticalAlign=="middle"?d+=(t.lineHeight-t.fontSize)/2:this._settings.verticalAlign=="bottom"&&(d+=t.lineHeight-t.fontSize),this._settings.textAlign==="right"?l+=t.innerWidth-i[p]:this._settings.textAlign==="center"&&(l+=(t.innerWidth-i[p])/2),l+=t.paddingLeft,c.push({text:s[p],x:l,y:d,w:i[p]});if(this._settings.highlight){const p=this._settings.highlightColor,m=this._settings.highlightHeight*o||t.fontSize*1.5,f=this._settings.highlightOffset*o,g=this._settings.highlightPaddingLeft!==null?this._settings.highlightPaddingLeft*o:t.paddingLeft,x=this._settings.highlightPaddingRight!==null?this._settings.highlightPaddingRight*o:t.paddingRight;this._context.fillStyle=Ve(p);for(let w=0;w<c.length;w++){const u=c[w];this._context.fillRect(u.x-g,u.y-t.offsetY+f,u.w+x+g,m)}}let h=null;this._settings.shadow&&(h=[this._context.shadowColor,this._context.shadowOffsetX,this._context.shadowOffsetY,this._context.shadowBlur],this._context.shadowColor=Ve(this._settings.shadowColor),this._context.shadowOffsetX=this._settings.shadowOffsetX*o,this._context.shadowOffsetY=this._settings.shadowOffsetY*o,this._context.shadowBlur=this._settings.shadowBlur*o),this._context.fillStyle=Ve(this._settings.textColor);for(let p=0,m=c.length;p<m;p++){const f=c[p];if(t.letterSpacing===0)this._context.fillText(f.text,f.x,f.y);else{const g=f.text.split("");let x=f.x;for(let w=0,u=g.length;w<u;w++)this._context.fillText(g[w],x,f.y),x+=this.measureText(g[w],t.letterSpacing)}}h&&(this._context.shadowColor=h[0],this._context.shadowOffsetX=h[1],this._context.shadowOffsetY=h[2],this._context.shadowBlur=h[3]),(t.cutSx||t.cutSy)&&this._context.translate(t.cutSx,t.cutSy),this.renderInfo=t}wrapWord(t,e,o){const s=this._context.measureText(o).width,i=t.length,n=this._context.measureText(t).width;if(n<=e)return t;let l=Math.floor(e*i/n),d=this._context.measureText(t.substring(0,l)).width+s;if(d>e)for(;l>0&&(d=this._context.measureText(t.substring(0,l)).width+s,d>e);)l-=1;else for(;l<i;)if(d=this._context.measureText(t.substring(0,l)).width+s,d<e)l+=1;else{l-=1;break}return t.substring(0,l)+(e>=s?o:"")}wrapText(t,e,o,s=0){const i=t.split(/\r?\n/g);let n=[];const l=[];for(let d=0;d<i.length;d++){const c=[];let h="",p=e-s;const m=i[d].split(" ");for(let f=0;f<m.length;f++){const g=this.measureText(m[f],o),x=g+this.measureText(" ",o);f===0||x>p?(f>0&&(c.push(h),h=""),h+=m[f],p=e-g-(f===0?s:0)):(p-=x,h+=` ${m[f]}`)}c.push(h),h="",n=n.concat(c),d<i.length-1&&l.push(n.length)}return{l:n,n:l}}measureText(t,e=0){return e?t.split("").reduce((o,s)=>o+this._context.measureText(s).width+e,0):this._context.measureText(t).width}mergeDefaults(t){return{text:"",w:0,h:0,fontStyle:"normal",fontSize:40,fontFace:null,wordWrap:!0,wordWrapWidth:0,wordBreak:!1,textOverflow:"",lineHeight:null,textBaseline:"alphabetic",textAlign:"left",verticalAlign:"top",offsetY:null,maxLines:0,maxLinesSuffix:"..",textColor:[1,1,1,1],paddingLeft:0,paddingRight:0,shadow:!1,shadowColor:[0,0,0,1],shadowOffsetX:0,shadowOffsetY:0,shadowBlur:5,highlight:!1,highlightHeight:0,highlightColor:[0,0,0,1],highlightOffset:0,highlightPaddingLeft:0,highlightPaddingRight:0,letterSpacing:0,textIndent:0,cutSx:0,cutEx:0,cutSy:0,cutEy:0,advancedRenderer:!1,fontBaselineRatio:0,precision:1,textRenderIssueMargin:0,...t}}}var co;const kt=((co=self.document)==null?void 0:co.fonts)||self.fonts;function $r(r){const{fontFamily:t,fontStyle:e,fontWeight:o,fontStretch:s,fontSize:i}=r;return[e,o,s,`${i}px`,t].join(" ")}class Tr extends $o{constructor(e){super(e);a(this,"canvas");a(this,"context");typeof OffscreenCanvas<"u"?this.canvas=new OffscreenCanvas(0,0):this.canvas=document.createElement("canvas");let o=this.canvas.getContext("2d");o||(this.canvas=document.createElement("canvas"),o=this.canvas.getContext("2d")),_(o),this.context=o}getPropertySetters(){return{fontFamily:(e,o)=>{e.props.fontFamily=o,e.fontInfo=void 0,this.markForReload(e)},fontWeight:(e,o)=>{e.props.fontWeight=o,e.fontInfo=void 0,this.markForReload(e)},fontStyle:(e,o)=>{e.props.fontStyle=o,e.fontInfo=void 0,this.markForReload(e)},fontStretch:(e,o)=>{e.props.fontStretch=o,e.fontInfo=void 0,this.markForReload(e)},fontSize:(e,o)=>{e.props.fontSize=o,e.fontInfo=void 0,this.markForReload(e)},text:(e,o)=>{e.props.text=o,this.markForReload(e)},textAlign:(e,o)=>{e.props.textAlign=o,this.markForReload(e)},color:(e,o)=>{e.props.color=o,this.markForReload(e)},x:(e,o)=>{e.props.x=o},y:(e,o)=>{e.props.y=o},contain:(e,o)=>{e.props.contain=o,this.markForReload(e)},width:(e,o)=>{e.props.width=o,this.markForReload(e)},height:(e,o)=>{e.props.height=o,this.markForReload(e)},offsetY:(e,o)=>{e.props.offsetY=o,this.markForReload(e)},scrollY:(e,o)=>{e.props.scrollY=o},letterSpacing:(e,o)=>{e.props.letterSpacing=o,this.markForReload(e)}}}canRenderFont(e){return!0}isFontFaceSupported(e){return e instanceof St}addFontFace(e){_(e instanceof St),kt.add(e.fontFace)}createState(e){return{props:e,status:"initialState",emitter:new Me,canvasPages:void 0,lightning2TextRenderer:new Er(this.canvas,this.context),renderWindow:void 0,renderInfo:void 0,forceFullLayoutCalc:!1,textW:0,textH:0,fontInfo:void 0,fontFaceLoadedHandler:void 0,debugData:{updateCount:0,layoutCount:0,drawCount:0,lastLayoutNumCharacters:0,layoutSum:0,drawSum:0,bufferSize:0}}}updateState(e){if(e.status==="initialState"&&this.setStatus(e,"loading"),!e.fontInfo){const u=$r(e.props);if(e.fontInfo={cssString:u,loaded:!1},!e.fontInfo.loaded){kt.load(u).then(this.onFontLoaded.bind(this,e,u)).catch(this.onFontLoadError.bind(this,e,u));return}}if(!e.fontInfo.loaded)return;if(!e.renderInfo){e.lightning2TextRenderer.settings={text:e.props.text,textAlign:e.props.textAlign,fontFace:e.props.fontFamily,fontSize:e.props.fontSize,fontStyle:[e.props.fontStretch,e.props.fontStyle,e.props.fontWeight].join(" "),textColor:oe(e.props.color),offsetY:e.props.fontSize+e.props.offsetY,wordWrap:e.props.contain!=="none",wordWrapWidth:e.props.contain==="none"?void 0:e.props.width,letterSpacing:e.props.letterSpacing};const u=performance.now();e.renderInfo=e.lightning2TextRenderer.calculateRenderInfo(),console.log("Render info calculated in",performance.now()-u,"ms"),e.textH=e.renderInfo.lineHeight*e.renderInfo.lines.length,e.textW=e.renderInfo.width,e.renderWindow=void 0}const{x:o,y:s,width:i,height:n,scrollY:l,contain:d}=e.props;let{renderWindow:c,canvasPages:h}=e;const p={x1:0,y1:0,x2:this.stage.options.appWidth,y2:this.stage.options.appHeight},m={x1:o,y1:s,x2:d!=="none"?o+i:1/0,y2:d==="both"?s+n:1/0},f=fo(p,m),g=f.y2-f.y1,x=Math.ceil(g/e.renderInfo.lineHeight);if(c&&h){const u=o+c.x1,C=s-l+c.y1,T=o+c.x2,v=s-l+c.y2;if(u<=f.x1&&T>=f.x2&&C<=f.y1&&v>=f.y2)return;v<f.y2?(c.y1+=x*e.renderInfo.lineHeight,c.y2+=x*e.renderInfo.lineHeight,h.push(h.shift()),h[2].lineNumStart=h[1].lineNumStart+x,h[2].lineNumEnd=h[2].lineNumStart+x,h[2].valid=!1):C>f.y1&&(c.y1-=x*e.renderInfo.lineHeight,c.y2-=x*e.renderInfo.lineHeight,h.unshift(h.pop()),h[0].lineNumStart=h[1].lineNumStart-x,h[0].lineNumEnd=h[0].lineNumStart+x,h[0].valid=!1)}else{const u=e.renderInfo.lineHeight*x,T=Math.ceil(l/u)*x,v=T-x,M=T+x;h=[{texture:h==null?void 0:h[0].texture,lineNumStart:v,lineNumEnd:v+x,valid:!1},{texture:h==null?void 0:h[1].texture,lineNumStart:T,lineNumEnd:T+x,valid:!1},{texture:h==null?void 0:h[2].texture,lineNumStart:M,lineNumEnd:M+x,valid:!1}],e.canvasPages=h;const L=Math.ceil(l/u)*u;c={x1:0,y1:L-u,x2:i,y2:L+u*2}}e.renderWindow=c;const w=performance.now();for(const u of h)if(!u.valid){if(u.lineNumStart<0){u.texture=this.stage.txManager.loadTexture("ImageTexture",{src:""}),u.valid=!0;continue}e.lightning2TextRenderer.draw(e.renderInfo,{lines:e.renderInfo.lines.slice(u.lineNumStart,u.lineNumEnd),lineWidths:e.renderInfo.lineWidths.slice(u.lineNumStart,u.lineNumEnd)}),this.canvas.width===0||this.canvas.height===0||(u.texture=this.stage.txManager.loadTexture("ImageTexture",{src:this.context.getImageData(0,0,this.canvas.width,this.canvas.height)},{preload:!0})),u.valid=!0}console.log("pageDrawTime",performance.now()-w,"ms"),this.setStatus(e,"loaded")}renderQuads(e,o){var v,M,L,F,y,k,z,P,$,I,D,B;const{stage:s}=this,{canvasPages:i,textW:n=0,textH:l=0,renderWindow:d}=e;if(!i||!d)return;const{x:c,y:h,scrollY:p,contain:m,width:f,height:g}=e.props,x={x:c,y:h,width:m!=="none"?f:n,height:m==="both"?g:l};uo({x:0,y:0,width:s.options.appWidth,height:s.options.appHeight},x),_(i,"canvasPages is not defined"),_(d,"renderWindow is not defined");const u=(d.y2-d.y1)/3,{zIndex:C,alpha:T}=e.props;i[0].valid&&this.stage.renderer.addRenderable({alpha:T,clippingRect:o,colorBl:4294967295,colorBr:4294967295,colorTl:4294967295,colorTr:4294967295,width:((M=(v=i[0].texture)==null?void 0:v.dimensions)==null?void 0:M.width)||0,height:((F=(L=i[0].texture)==null?void 0:L.dimensions)==null?void 0:F.height)||0,texture:i[0].texture,textureOptions:{},shader:null,shaderProps:null,zIndex:C,worldScale:1,scale:1,wpx:c,wpy:h-p+d.y1,ta:1,tb:0,tc:0,td:1}),i[1].valid&&this.stage.renderer.addRenderable({alpha:T,clippingRect:o,colorBl:4294967295,colorBr:4294967295,colorTl:4294967295,colorTr:4294967295,width:((k=(y=i[1].texture)==null?void 0:y.dimensions)==null?void 0:k.width)||0,height:((P=(z=i[1].texture)==null?void 0:z.dimensions)==null?void 0:P.height)||0,texture:i[1].texture,textureOptions:{},shader:null,shaderProps:null,zIndex:C,worldScale:1,scale:1,wpx:c,wpy:h-p+d.y1+u,ta:1,tb:0,tc:0,td:1}),i[2].valid&&this.stage.renderer.addRenderable({alpha:T,clippingRect:o,colorBl:4294967295,colorBr:4294967295,colorTl:4294967295,colorTr:4294967295,width:((I=($=i[2].texture)==null?void 0:$.dimensions)==null?void 0:I.width)||0,height:((B=(D=i[2].texture)==null?void 0:D.dimensions)==null?void 0:B.height)||0,texture:i[2].texture,textureOptions:{},shader:null,shaderProps:null,zIndex:C,worldScale:1,scale:1,wpx:c,wpy:h-p+d.y1+u+u,ta:1,tb:0,tc:0,td:1})}markForReload(e){e.renderInfo=void 0,this.setStatus(e,"loading")}onFontLoaded(e,o){var s;o!==((s=e.fontInfo)==null?void 0:s.cssString)||!e.fontInfo||(e.fontInfo.loaded=!0,this.updateState(e))}onFontLoadError(e,o,s){var i;o!==((i=e.fontInfo)==null?void 0:i.cssString)||!e.fontInfo||(e.fontInfo.loaded=!0,console.error(`CanvasTextRenderer: Error loading font '${e.fontInfo.cssString}'`,s),this.updateState(e))}}const Sr=2e6;class Cr{constructor(t){a(this,"options");a(this,"animationManager");a(this,"txManager");a(this,"fontManager");a(this,"textRenderers");a(this,"shManager");a(this,"renderer");a(this,"scene");a(this,"deltaTime",0);a(this,"lastFrameTime",0);a(this,"currentFrameTime",0);this.options=t;const{canvas:e,clearColor:o,rootId:s,debug:i,appWidth:n,appHeight:l}=t;this.txManager=new mr,this.shManager=new ur,this.animationManager=new pr,i!=null&&i.monitorTextureCache&&setInterval(()=>{_(this.txManager);const c=this.txManager.getDebugInfo();console.log("Texture ID Cache Size: ",c.idCacheSize),console.log("Texture Key Cache Size: ",c.keyCacheSize)},1e3),this.renderer=new Zo({stage:this,canvas:e,pixelRatio:t.devicePhysicalPixelRatio*t.deviceLogicalPixelRatio,clearColor:o??4278190080,bufferMemory:Sr,txManager:this.txManager,shManager:this.shManager}),this.txManager.renderer=this.renderer,this.textRenderers={canvas:new Tr(this),sdf:new vr(this)},this.fontManager=new Eo(this.textRenderers);const d=new bt(this,{id:s,x:0,y:0,width:n,height:l,alpha:1,clipping:!1,color:0,colorTop:0,colorBottom:0,colorLeft:0,colorRight:0,colorTl:0,colorTr:0,colorBl:0,colorBr:0,zIndex:0,zIndexLocked:0,scale:1,mountX:0,mountY:0,mount:0,pivot:.5,pivotX:.5,pivotY:.5,rotation:0,parent:null,texture:null,textureOptions:null,shader:null,shaderProps:null});this.scene=new hr(d),fr(this)}drawFrame(){var s,i;const{renderer:t,scene:e,animationManager:o}=this;e!=null&&e.root&&(this.lastFrameTime=this.currentFrameTime,this.currentFrameTime=dr(),this.deltaTime=this.lastFrameTime?this.currentFrameTime-this.lastFrameTime:100/6,o.update(this.deltaTime),t==null||t.reset(),(s=e==null?void 0:e.root)!=null&&s.hasUpdates&&((i=e==null?void 0:e.root)==null||i.update(this.deltaTime)),this.addQuads(e.root),t==null||t.sortRenderables(),t==null||t.render())}addQuads(t,e=null){_(this.renderer);let o=t.clipping?{x:t.worldContext.px,y:t.worldContext.py,width:t.width,height:t.height}:null;e&&o?o=uo(e,o):e&&(o=e),t.renderQuads(this.renderer,o),t.children.forEach(s=>{s.alpha!==0&&this.addQuads(s,o)})}resolveTextRenderer(t,e=null){let o=e,s=!1;if(o){const n=this.textRenderers[o];n?n.canRenderFont(t)||(console.warn(`Cannot use override text renderer '${o}' for font`,t),o=null,s=!0):(console.warn(`Text renderer override '${o}' not found.`),o=null,s=!0)}if(!o){for(const[n,l]of Object.entries(this.textRenderers))if(n!=="canvas"&&l.canRenderFont(t)){o=n;break}o||(o="canvas")}s&&console.warn(`Falling back to text renderer ${String(o)}`);const i=this.textRenderers[o];return _(i,"resolvedTextRenderer undefined"),i}get root(){var t;return((t=this.scene)==null?void 0:t.root)||null}}class kr extends bt{constructor(e,o){super(e,o);a(this,"textRenderer");a(this,"trState");a(this,"updateScheduled");a(this,"_textRendererOverride",null);a(this,"onTextLoaded",()=>{this.emit("textLoaded",{width:this.trState.textW,height:this.trState.textH})});a(this,"onTextFailed",(e,o)=>{this.emit("textFailed",o)});this.updateScheduled=!1,this._textRendererOverride=o.textRendererOverride;const{resolvedTextRenderer:s,textRendererState:i}=this.resolveTextRendererAndState({x:this.absX,y:this.absY,width:o.width,height:o.height,textAlign:o.textAlign,color:o.color,alpha:o.alpha,zIndex:o.zIndex,contain:o.contain,scrollable:o.scrollable,scrollY:o.scrollY,offsetY:o.offsetY,letterSpacing:o.letterSpacing,debug:o.debug,fontFamily:o.fontFamily,fontSize:o.fontSize,fontStretch:o.fontStretch,fontStyle:o.fontStyle,fontWeight:o.fontWeight,text:o.text},void 0);this.textRenderer=s,this.trState=i}get width(){return this.trState.props.width}set width(e){this.textRenderer.set.width(this.trState,e),this.updateText()}get height(){return this.trState.props.height}set height(e){this.textRenderer.set.height(this.trState,e),this.updateText()}get alpha(){return this.trState.props.alpha}set alpha(e){this.textRenderer.set.alpha(this.trState,e),this.updateText()}get color(){return this.trState.props.color}set color(e){this.textRenderer.set.color(this.trState,e),this.updateText()}get text(){return this.trState.props.text}set text(e){this.textRenderer.set.text(this.trState,e),this.updateText()}get textRendererOverride(){return this._textRendererOverride}set textRendererOverride(e){this._textRendererOverride=e;const{resolvedTextRenderer:o,textRendererState:s}=this.resolveTextRendererAndState(this.trState.props,this.trState);this.textRenderer=o,this.trState=s}get fontSize(){return this.trState.props.fontSize}set fontSize(e){this.textRenderer.set.fontSize(this.trState,e),this.updateText()}get fontFamily(){return this.trState.props.fontFamily}set fontFamily(e){this.textRenderer.set.fontFamily(this.trState,e),this.updateText()}get fontStretch(){return this.trState.props.fontStretch}set fontStretch(e){this.textRenderer.set.fontStretch(this.trState,e),this.updateText()}get fontStyle(){return this.trState.props.fontStyle}set fontStyle(e){this.textRenderer.set.fontStyle(this.trState,e),this.updateText()}get fontWeight(){return this.trState.props.fontWeight}set fontWeight(e){this.textRenderer.set.fontWeight(this.trState,e),this.updateText()}get textAlign(){return this.trState.props.textAlign}set textAlign(e){this.textRenderer.set.textAlign(this.trState,e),this.updateText()}get contain(){return this.trState.props.contain}set contain(e){this.textRenderer.set.contain(this.trState,e),this.updateText()}get scrollable(){return this.trState.props.scrollable}set scrollable(e){this.textRenderer.set.scrollable(this.trState,e),this.updateText()}get scrollY(){return this.trState.props.scrollY}set scrollY(e){this.textRenderer.set.scrollY(this.trState,e),this.updateText()}get offsetY(){return this.trState.props.offsetY}set offsetY(e){this.textRenderer.set.offsetY(this.trState,e),this.updateText()}get letterSpacing(){return this.trState.props.letterSpacing}set letterSpacing(e){this.textRenderer.set.letterSpacing(this.trState,e),this.updateText()}get debug(){return this.trState.props.debug}set debug(e){this.textRenderer.set.debug(this.trState,e),this.updateText()}update(e){super.update(e),this.textRenderer.set.x(this.trState,this.worldContext.px),this.textRenderer.set.y(this.trState,this.worldContext.py),this.trState.status==="loading"&&this.updateText()}updateText(){this.updateScheduled||(this.updateScheduled=!0,queueMicrotask(()=>{this.updateScheduled=!1,this.textRenderer.updateState(this.trState)}))}renderQuads(e,o){this.textRenderer.renderQuads(this.trState,o)}resolveTextRendererAndState(e,o){const s=this.stage.resolveTextRenderer(e,this._textRendererOverride),i=s.createState(e);return o&&["loading","loaded","failed"].forEach(l=>{o.emitter.off(l)}),i.emitter.on("loading",()=>{i.emitter.once("fontLoaded",()=>{this.updateText()}),i.emitter.once("loaded",()=>{i.emitter.off("fontLoaded")})}),i.emitter.on("loaded",this.onTextLoaded),i.emitter.on("failed",this.onTextFailed),this.updateText(),{resolvedTextRenderer:s,textRendererState:i}}}class Ir extends it{constructor(e,o,s){super(e,o,s,new kr(s,{id:wo(),x:e.x,y:e.y,width:e.width,height:e.height,alpha:e.alpha,clipping:e.clipping,color:e.color,colorTop:e.colorTop,colorBottom:e.colorBottom,colorLeft:e.colorLeft,colorRight:e.colorRight,colorTl:e.colorTl,colorTr:e.colorTr,colorBl:e.colorBl,colorBr:e.colorBr,zIndex:e.zIndex,zIndexLocked:e.zIndexLocked,scale:e.scale,mountX:e.mountX,mountY:e.mountY,mount:e.mount,pivot:e.pivot,pivotX:e.pivotX,pivotY:e.pivotY,rotation:e.rotation,text:e.text,fontSize:e.fontSize,fontFamily:e.fontFamily,fontWeight:e.fontWeight,fontStretch:e.fontStretch,fontStyle:e.fontStyle,contain:e.contain,scrollable:e.scrollable,letterSpacing:e.letterSpacing,textAlign:e.textAlign,scrollY:e.scrollY,offsetY:e.offsetY,textRendererOverride:e.textRendererOverride,debug:e.debug,parent:null,texture:null,textureOptions:null,shader:null,shaderProps:null}));a(this,"onTextLoaded",(e,o)=>{this.emit("textLoaded",o)});a(this,"onTextFailed",(e,o)=>{this.emit("textFailed",o)});this.coreNode.on("textLoaded",this.onTextLoaded),this.coreNode.on("textFailed",this.onTextFailed)}get text(){return this.coreNode.text}set text(e){this.coreNode.text=e}get textRendererOverride(){return this.coreNode.textRendererOverride}set textRendererOverride(e){this.coreNode.textRendererOverride=e}get fontSize(){return this.coreNode.fontSize}set fontSize(e){this.coreNode.fontSize=e}get fontFamily(){return this.coreNode.fontFamily}set fontFamily(e){this.coreNode.fontFamily=e}get fontWeight(){return this.coreNode.fontWeight}set fontWeight(e){this.coreNode.fontWeight=e}get fontStretch(){return this.coreNode.fontStretch}set fontStretch(e){this.coreNode.fontStretch=e}get fontStyle(){return this.coreNode.fontStyle}set fontStyle(e){this.coreNode.fontStyle=e}get textAlign(){return this.coreNode.textAlign}set textAlign(e){this.coreNode.textAlign=e}get contain(){return this.coreNode.contain}set contain(e){this.coreNode.contain=e}get scrollable(){return this.coreNode.scrollable}set scrollable(e){this.coreNode.scrollable=e}get scrollY(){return this.coreNode.scrollY}set scrollY(e){this.coreNode.scrollY=e}get offsetY(){return this.coreNode.offsetY}set offsetY(e){this.coreNode.offsetY=e}get letterSpacing(){return this.coreNode.letterSpacing}set letterSpacing(e){this.coreNode.letterSpacing=e}get debug(){return this.coreNode.debug}set debug(e){this.coreNode.debug=e}}const Rr="modulepreload",Mr=function(r){return"/"+r},It={},zr=function(t,e,o){if(!e||e.length===0)return t();const s=document.getElementsByTagName("link");return Promise.all(e.map(i=>{if(i=Mr(i),i in It)return;It[i]=!0;const n=i.endsWith(".css"),l=n?'[rel="stylesheet"]':"";if(!!o)for(let h=s.length-1;h>=0;h--){const p=s[h];if(p.href===i&&(!n||p.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${i}"]${l}`))return;const c=document.createElement("link");if(c.rel=n?"stylesheet":Rr,n||(c.as="script",c.crossOrigin=""),c.href=i,document.head.appendChild(c),n)return new Promise((h,p)=>{c.addEventListener("load",h),c.addEventListener("error",()=>p(new Error(`Unable to preload CSS for ${i}`)))})})).then(()=>t()).catch(i=>{const n=new Event("vite:preloadError",{cancelable:!0});if(n.payload=i,window.dispatchEvent(n),!n.defaultPrevented)throw i})};function Or(r){return r.prototype instanceof Jo}async function Lr(r,t){let e;try{console.log("Loading core extension",r),e=await zr(()=>import(r),[])}catch(s){console.error(`The core extension module at '${r}' could not be loaded.`),console.error(s);return}if(!e.default){console.error(`The core extension module at '${r}' does not have a default export.`);return}const o=e.default;if(Or(o)){const s=new o;try{await s.run(t)}catch(i){console.error(`The core extension at '${r}' threw an error.`),console.error(i)}}else console.error(`The core extension at '${r}' does not extend CoreExtension.`)}class Fr{constructor(){a(this,"root",null);a(this,"stage",null);a(this,"rendererMain",null)}async init(t,e,o){this.stage=new Cr({rootId:1,appWidth:e.appWidth,appHeight:e.appHeight,deviceLogicalPixelRatio:e.deviceLogicalPixelRatio,devicePhysicalPixelRatio:e.devicePhysicalPixelRatio,clearColor:e.clearColor,canvas:o,debug:{monitorTextureCache:!1}}),this.rendererMain=t,_(this.stage.root);const s=new it(t.resolveNodeDefaults({}),this.rendererMain,this.stage,this.stage.root);this.root=s,s.once("beforeDestroy",this.onBeforeDestroyNode.bind(this,s)),this.onCreateNode(s),e.coreExtensionModule&&await Lr(e.coreExtensionModule,this.stage)}createNode(t){_(this.rendererMain),_(this.stage);const e=new it(t,this.rendererMain,this.stage);return e.once("beforeDestroy",this.onBeforeDestroyNode.bind(this,e)),this.onCreateNode(e),e}createTextNode(t){_(this.rendererMain),_(this.stage);const e=new Ir(t,this.rendererMain,this.stage);return e.once("beforeDestroy",this.onBeforeDestroyNode.bind(this,e)),this.onCreateNode(e),e}destroyNode(t){t.destroy()}releaseTexture(t){const{stage:e}=this;_(e),e.txManager.removeTextureIdFromCache(t)}getRootNode(){return _(this.root),this.root}onCreateNode(t){throw new Error("Method not implemented.")}onBeforeDestroyNode(t){throw new Error("Method not implemented.")}}const V=self;function ft(r,t){if(!r)throw new Error(t||"Assertion failed")}class To{constructor(t,e){a(this,"threadx");a(this,"sharedObjectStruct");a(this,"mutations");a(this,"waitPromise",null);a(this,"mutationsQueued",!1);a(this,"_id");a(this,"_typeId");a(this,"initialized",!1);a(this,"destroying",!1);a(this,"curProps");a(this,"eventListeners",{});this.curProps=e,this.threadx=Re.instance,this.sharedObjectStruct=t,this._id=t.id,this._typeId=t.typeId;const o=this.constructor;if(!Object.prototype.hasOwnProperty.call(o,"staticInitialized")||!o.staticInitialized){o.staticInitialized=!0;const s=Object.getPrototypeOf(this);Object.keys(e).forEach(i=>{Object.defineProperty(s,i,{get:function(){return this.curProps[i]},set:function(n){this.curProps[i]=n,this.mutations[i]=!0,this.queueMutations()}})})}this.mutations={},this._executeMutations(),this.initialized=!0}static extractBuffer(t){if(t.destroying||!t.sharedObjectStruct)throw new Error("SharedObject.extractBuffer(): SharedObject is or was being destroyed.");return t.sharedObjectStruct.buffer}get typeId(){return this._typeId}get id(){return this._id}processDirtyProperties(){if(!this.sharedObjectStruct)throw new Error("SharedObject was destroyed");const{sharedObjectStruct:t,mutations:e,curProps:o}=this;t.constructor.propDefs.forEach((s,i)=>{if(t.isDirty(i)){const n=s.name;delete e[n];const l=o[n];o[n]=t[n],this.initialized&&this.onPropertyChange(n,t[n],l)}}),t.resetDirty()}onPropertyChange(t,e,o){}queueMutations(){this.mutationsQueued||(this.mutationsQueued=!0,queueMicrotask(()=>{this.mutationsQueued=!1,this.sharedObjectStruct&&this.mutationMicrotask().catch(console.error)}))}async mutationMicrotask(){if(!this.sharedObjectStruct)throw new Error("SharedObject was destroyed");await this.sharedObjectStruct.lockAsync(async()=>{this._executeMutations()}),this.destroying&&this.finishDestroy()}flush(){if(this.destroying||!this.sharedObjectStruct)throw new Error("SharedObject was destroyed");this.sharedObjectStruct.lock(()=>{this._executeMutations()})}onDestroy(){}destroy(){const t=this.sharedObjectStruct;this.destroying||!t||(this.emit("beforeDestroy",{},{localOnly:!0}),this.destroying=!0,this.onDestroy(),this.queueMutations())}finishDestroy(){const t=this.sharedObjectStruct;!this.destroying||!t||(this.threadx.forgetObjects([this],{silent:!0}).catch(console.error),this.sharedObjectStruct=null,t.notify(),this.emit("afterDestroy",{},{localOnly:!0}),this.eventListeners={})}get isDestroyed(){return this.sharedObjectStruct===null}_executeMutations(){if(!this.sharedObjectStruct)return;this.sharedObjectStruct.notifyValue!==this.threadx.workerId&&this.sharedObjectStruct.isDirty()&&this.processDirtyProperties();const{mutations:t}=this;this.mutations={};for(const s in t)if(Object.prototype.hasOwnProperty.call(t,s)){const i=this.curProps[s];this.sharedObjectStruct[s],this.sharedObjectStruct[s]=i}this.waitPromise&&(this.waitPromise=null);let e=this.sharedObjectStruct.notifyValue;this.sharedObjectStruct.isDirty()&&(this.sharedObjectStruct.notify(this.threadx.workerId),e=this.threadx.workerId);const o=this.sharedObjectStruct.waitAsync(e).then(async s=>{this.waitPromise===o&&this.sharedObjectStruct&&(ft(s==="ok"),this.waitPromise=null,await this.mutationMicrotask())});this.waitPromise=o}on(t,e){let o=this.eventListeners[t];o||(o=[]),o.push(e),this.eventListeners[t]=o}off(t,e){const o=this.eventListeners[t];if(!o)return;const s=o.indexOf(e);s>=0&&o.splice(s,1)}once(t,e){const o=(s,i)=>{this.off(t,o),e(s,i)};this.on(t,o)}emit(t,e,o={}){const s=this.eventListeners[t];o.localOnly||Re.instance.__sharedObjectEmit(this,t,e),s&&[...s].forEach(i=>{i(this,e)})}}a(To,"staticInitialized",!1);function So(r){return r>=65&&r<=90||r>=48&&r<=57}function Co(r){let t=0;if(r.length===0)throw new Error("genTypeId: Type ID string must be at least 1 character");if(r.length>4)throw new Error("genTypeId: Type ID string must be 4 characters or less");for(let e=0;e<r.length;e++){let o=r.charCodeAt(e);if(o!==o)o=0;else if(!So(o))throw new Error(`genTypeId: Invalid character '${r[e]}' (char code: ${o}) in type ID string. A-Z and 0-9 only.`);t|=o<<e*8}return t}function Ge(r){const t=[];for(let e=0;e<4;e++){const o=r&255;if(So(o))t.push(String.fromCharCode(o));else if(o!==0||e===0)return"????";r>>>=8}return t.join("")}function ce(r,t){return typeof t=="object"&&t!==null&&"threadXMessageType"in t&&t.threadXMessageType===r}function Nr(r){return typeof r.DedicatedWorkerGlobalScope=="function"}class Re{constructor(t){a(this,"workerId");a(this,"workerName");a(this,"sharedObjectFactory");a(this,"onSharedObjectCreated");a(this,"onBeforeObjectForgotten");a(this,"onUserMessage");a(this,"sharedObjects",new Map);a(this,"sharedObjectData",new WeakMap);a(this,"workers",new Map);a(this,"workerReadyPromises",new Map);a(this,"pendingAsyncMsgs",new Map);a(this,"nextAsyncMsgId",0);a(this,"nextUniqueId",0);a(this,"suppressSharedObjectEmit",!1);this.workerId=t.workerId,this.workerName=t.workerName,this.nextUniqueId=t.workerId*1e13+1,this.sharedObjectFactory=t.sharedObjectFactory,this.onSharedObjectCreated=t.onObjectShared,this.onBeforeObjectForgotten=t.onBeforeObjectForgotten,this.onUserMessage=t.onMessage;const e=V;Nr(e)&&(this.registerWorker("parent",e),this.sendMessage("parent",{threadXMessageType:"ready"}))}static init(t){if(V.THREADX)throw new Error("ThreadX.init(): ThreadX already initialized.");const e=new Re(t);return V.THREADX=e,e}static destroy(){if(!V.THREADX){console.warn("ThreadX.destroy(): ThreadX is not initialized.");return}delete V.THREADX}static get workerId(){if(!V.THREADX)throw new Error("ThreadX not initialized");return V.THREADX.workerId}static get workerName(){if(!V.THREADX)throw new Error("ThreadX not initialized");return V.THREADX.workerName}static get instance(){if(!V.THREADX)throw new Error("ThreadX not initialized");return V.THREADX}registerWorker(t,e){this.workers.set(t,e);let o,s;t==="parent"?(s=Promise.resolve(),o=()=>{}):s=new Promise(i=>{o=i}),this.workerReadyPromises.set(t,{promise:s,resolve:o}),this.listenForWorkerMessages(t,e)}closeWorker(t){if(!this.workers.has(t))throw new Error(`Worker ${t} not registered.`);this.closeWorkerAsync(t).catch(console.error)}async closeWorkerAsync(t,e=5e3){var i;const o=this.workers.get(t);if(!o)throw new Error(`Worker ${t} not registered.`);const s=await Promise.race([new Promise(n=>{setTimeout(()=>{n(!1)},e)}),this.sendMessageAsync(t,{threadXMessageType:"close"})]);return this.workers.delete(t),this.workerReadyPromises.delete(t),s?"graceful":(console.warn(`threadX.closeWorkerAsync(): Worker "${t}" did not respond to "close" message within ${e}ms. Forcing termination.`),(i=o.terminate)==null||i.call(o),"forced")}listenForWorkerMessages(t,e){e.addEventListener("message",o=>{const{data:s}=o,i=s.__asyncMsgId;this.onMessage(t,s).then(n=>{i!==void 0&&e.postMessage({threadXMessageType:"response",asyncMsgId:i,data:n})}).catch(n=>{i!==void 0&&e.postMessage({threadXMessageType:"response",asyncMsgId:i,error:!0,data:n})})})}async shareObjects(t,e){for(const o of e)this.sharedObjects.get(o.id)?console.warn(`ThreadX.shareObject(): SharedObject ${o.id} (TypeID: ${Ge(o.typeId)}) is already shared.`):(this.sharedObjects.set(o.id,o),this.sharedObjectData.set(o,{workerName:t,shareConfirmed:!1,emitQueue:null}));await this.sendMessageAsync(t,{threadXMessageType:"shareObjects",buffers:e.map(o=>To.extractBuffer(o))});for(const o of e){const s=this.sharedObjectData.get(o);if(s){s.shareConfirmed=!0;const{emitQueue:i}=s;if(i){for(const n of i)this.__sharedObjectEmit(o,n[0],n[1]);s.emitQueue=null}}}}async forgetObjects(t,e={}){const o=new Map;for(const i of t)if(!this.sharedObjects.has(i.id))e.silent||console.warn(`ThreadX.forgetObject(): SharedObject ${i.id} (TypeID: ${Ge(i.typeId)}) is not shared.`);else{const n=this.sharedObjectData.get(i);ft(n);let l=o.get(n.workerName);l||(l=[],o.set(n.workerName,l)),l.push(i),this.sharedObjects.delete(i.id),this.sharedObjectData.delete(i)}const s=[];for(const[i,n]of o)s.push(this.sendMessageAsync(i,{threadXMessageType:"forgetObjects",objectIds:n.map(l=>l.id)}));await Promise.all(s)}sendMessage(t,e,o){if(!this.workers.get(t))throw new Error(`ThreadX.sendMessage(): Worker '${t}' not registered.`);this.sendMessageAsync(t,e,o,{skipResponseWait:!0}).catch(console.error)}async sendMessageAsync(t,e,o,s={}){const i=this.workers.get(t);if(!i)throw new Error(`ThreadX.execMessage(): Worker '${t}' not registered.`);if(await this.workerReadyPromises.get(t).promise,s.skipResponseWait){i.postMessage(e,o);return}const n=this.nextAsyncMsgId++,l=new Promise((d,c)=>{this.pendingAsyncMsgs.set(n,{resolve:d,reject:c})});return e.__asyncMsgId=n,i.postMessage(e,o),l}async onMessage(t,e){var o;if(ce("shareObjects",e))e.buffers.forEach(s=>{var n,l;const i=(n=this.sharedObjectFactory)==null?void 0:n.call(this,s);if(!i)throw new Error("ThreadX.onMesasge(): Failed to create shared object.");this.sharedObjects.set(i.id,i),this.sharedObjectData.set(i,{workerName:t,shareConfirmed:!0,emitQueue:null}),(l=this.onSharedObjectCreated)==null||l.call(this,i)});else if(ce("forgetObjects",e))e.objectIds.forEach(s=>{var n;const i=this.sharedObjects.get(s);i&&((n=this.onBeforeObjectForgotten)==null||n.call(this,i),this.sharedObjects.delete(s),i.destroy())});else if(ce("sharedObjectEmit",e)){const s=this.sharedObjects.get(e.sharedObjectId);if(!s)return;this.suppressSharedObjectEmit=!0,s.emit(e.eventName,e.data),this.suppressSharedObjectEmit=!1}else if(ce("response",e)){const s=this.pendingAsyncMsgs.get(e.asyncMsgId);if(!s)throw new Error(`ThreadX.onMessage(): Received response for unknown request (ID: ${e.asyncMsgId})`);this.pendingAsyncMsgs.delete(e.asyncMsgId),e.error?s.reject(e.data):s.resolve(e.data)}else{if(ce("close",e))return V.close(),!0;if(ce("ready",e))return(o=this.workerReadyPromises.get(t))==null||o.resolve(),!0;if(this.onUserMessage)return await this.onUserMessage(e)}}getSharedObjectById(t){return this.sharedObjects.get(t)||null}generateUniqueId(){return this.nextUniqueId++}__sharedObjectEmit(t,e,o){if(this.suppressSharedObjectEmit)return;const s=this.sharedObjectData.get(t);if(!s)return;if(!s.shareConfirmed){s.emitQueue||(s.emitQueue=[]),s.emitQueue.push([e,o]);return}const i=this.workers.get(s.workerName);ft(i,"Worker not found"),i.postMessage({threadXMessageType:"sharedObjectEmit",sharedObjectId:t.id,eventName:e,data:o})}}const ve=0,he=1,Q=2,ae=6,Rt=2,Pe=255;function Ae(r,t,e){return r===t}function De(r,t){return r===t}function b(r,t){return function(e,o,s){const i=e.constructor;(!Object.prototype.hasOwnProperty.call(i,"staticInitialized")||!i.staticInitialized)&&i.initStatic();let n=i.size,l=0,d=0;r==="string"?(n+=n%2,l=n/2,d=(Pe+1)*2):r==="int32"||r==="boolean"?(n+=n%4,l=n/4,d=4):r==="number"&&(n+=n%8,l=n/8,d=8);const c=i.propDefs,h=c.length,p={propNum:h,name:o,type:r,byteOffset:n,offset:l,byteSize:d};c.push(p),i.size=n+d,s.get=function(){let m;if(r==="string"){const f=this.uint16array[l];if(!f)return"";if(f>Pe)throw new Error(`get SharedObject.${o}: Text length is too long. Length: ${f}`);m=String.fromCharCode(...this.uint16array.slice(l+1,l+1+f))}else r==="int32"?m=this.int32array[l]:r==="boolean"?m=!!this.int32array[l]:r==="number"&&(m=this.float64array[l]);return t!=null&&t.bufferToProp&&(m=t.bufferToProp(m)),m},s.set=function(m){if(t!=null&&t.propToBuffer&&(m=t.propToBuffer(m)),Ae("string",r)){if(!De(m,this[o])){this.setDirty(h);let f=m.length;f>Pe&&(console.error(`set SharedObject.${o}: Text length is too long. Truncating...`,f),f=Pe),this.uint16array[l]=f;const g=l+1,x=g+f;let w=0;for(let u=g;u<x;u++)this.uint16array[u]=m.charCodeAt(w++)}}else Ae("int32",r)?De(m,this[o])||(this.setDirty(h),this.int32array[l]=m):Ae("boolean",r)?De(m,this[o])||(this.setDirty(h),this.int32array[l]=m?1:0):Ae("number",r)&&(De(m,this[o])||(this.setDirty(h),this.float64array[l]=m))}}}const se=class se{constructor(t){a(this,"buffer");a(this,"lockId",Math.floor(Math.random()*4294967295));a(this,"uint16array");a(this,"int32array");a(this,"float64array");const e=this.constructor;(!Object.prototype.hasOwnProperty.call(e,"staticInitialized")||!e.staticInitialized)&&e.initStatic();const o=!t;t||(t=new SharedArrayBuffer(Math.ceil(e.size/8)*8)),this.buffer=t,this.uint16array=new Uint16Array(t),this.int32array=new Int32Array(t),this.float64array=new Float64Array(t);const s=e.typeId;if(o)this.int32array[ve]=s,this.float64array[Rt]=Re.instance.generateUniqueId();else if(this.int32array[ve]!==s)throw new Error(`BufferStruct: TypeId mismatch. Expected '${e.typeIdStr}', got '${Ge(this.int32array[ve])}'`)}static extractTypeId(t){return t.byteLength<se.size||t.byteLength%8!==0?0:new Int32Array(t)[ve]||0}static initStatic(){const t=Ge(this.typeId);if(t==="????")throw new Error("BufferStruct.typeId must be set to a valid 32-bit integer");this.typeIdStr=t,this.propDefs=[...this.propDefs],this.staticInitialized=!0}setDirty(t){const e=Math.floor(t/32),o=t-e*32;this.int32array[ae+e]=this.int32array[ae+e]|1<<o}resetDirty(){this.int32array[he]=0,this.int32array[ae]=0,this.int32array[ae+1]=0}isDirty(t){if(t!==void 0){const e=Math.floor(t/32),o=t-e*32;return!!(this.int32array[ae+e]&1<<o)}return!!(this.int32array[ae]||this.int32array[ae+1])}get typeId(){return this.int32array[ve]}get id(){return this.float64array[Rt]}get notifyValue(){return Atomics.load(this.int32array,he)}get isLocked(){return Atomics.load(this.int32array,Q)!==0}lock(t){let e=Atomics.compareExchange(this.int32array,Q,0,this.lockId);for(;e!==0;){try{Atomics.wait(this.int32array,Q,e)}catch(s){if(!(s instanceof TypeError&&s.message==="Atomics.wait cannot be called in this context"))throw s}e=Atomics.compareExchange(this.int32array,Q,0,this.lockId)}let o;try{o=t()}finally{Atomics.store(this.int32array,Q,0),Atomics.notify(this.int32array,Q)}return o}async lockAsync(t){let e=Atomics.compareExchange(this.int32array,Q,0,this.lockId);for(;e!==0;)await Atomics.waitAsync(this.int32array,Q,e).value,e=Atomics.compareExchange(this.int32array,Q,0,this.lockId);let o;try{o=await t()}finally{Atomics.store(this.int32array,Q,0),Atomics.notify(this.int32array,Q)}return o}notify(t){return t!==void 0&&Atomics.store(this.int32array,he,t),Atomics.notify(this.int32array,he)}wait(t,e=1/0){return Atomics.wait(this.int32array,he,t,e)}async waitAsync(t,e=1/0){return Atomics.waitAsync(this.int32array,he,t,e).value}};a(se,"staticInitialized",!1),a(se,"typeId",0),a(se,"typeIdStr",""),a(se,"size",8*4),a(se,"propDefs",[]);let dt=se;var O=globalThis&&globalThis.__decorate||function(r,t,e,o){var s=arguments.length,i=s<3?t:o===null?o=Object.getOwnPropertyDescriptor(t,e):o,n;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(r,t,e,o);else for(var l=r.length-1;l>=0;l--)(n=r[l])&&(i=(s<3?n(i):s>3?n(t,e,i):n(t,e))||i);return s>3&&i&&Object.defineProperty(t,e,i),i};class R extends dt{get x(){return 0}set x(t){}get y(){return 0}set y(t){}get width(){return 0}set width(t){}get height(){return 0}set height(t){}get alpha(){return 1}set alpha(t){}get clipping(){return!1}set clipping(t){}get color(){return 0}set color(t){}get colorTop(){return 0}set colorTop(t){}get colorBottom(){return 0}set colorBottom(t){}get colorLeft(){return 0}set colorLeft(t){}get colorRight(){return 0}set colorRight(t){}get colorTl(){return 0}set colorTl(t){}get colorTr(){return 0}set colorTr(t){}get colorBl(){return 0}set colorBl(t){}get colorBr(){return 0}set colorBr(t){}get scale(){return 1}set scale(t){}get mount(){return 0}set mount(t){}get mountX(){return 0}set mountX(t){}get mountY(){return 0}set mountY(t){}get pivot(){return .5}set pivot(t){}get pivotX(){return .5}set pivotX(t){}get pivotY(){return .5}set pivotY(t){}get rotation(){return 0}set rotation(t){}get parentId(){return 0}set parentId(t){}get zIndex(){return 0}set zIndex(t){}get zIndexLocked(){return 0}set zIndexLocked(t){}}a(R,"typeId",Co("NODE"));O([b("number")],R.prototype,"x",null);O([b("number")],R.prototype,"y",null);O([b("number")],R.prototype,"width",null);O([b("number")],R.prototype,"height",null);O([b("number")],R.prototype,"alpha",null);O([b("boolean")],R.prototype,"clipping",null);O([b("number")],R.prototype,"color",null);O([b("number")],R.prototype,"colorTop",null);O([b("number")],R.prototype,"colorBottom",null);O([b("number")],R.prototype,"colorLeft",null);O([b("number")],R.prototype,"colorRight",null);O([b("number")],R.prototype,"colorTl",null);O([b("number")],R.prototype,"colorTr",null);O([b("number")],R.prototype,"colorBl",null);O([b("number")],R.prototype,"colorBr",null);O([b("number")],R.prototype,"scale",null);O([b("number")],R.prototype,"mount",null);O([b("number")],R.prototype,"mountX",null);O([b("number")],R.prototype,"mountY",null);O([b("number")],R.prototype,"pivot",null);O([b("number")],R.prototype,"pivotX",null);O([b("number")],R.prototype,"pivotY",null);O([b("number")],R.prototype,"rotation",null);O([b("number")],R.prototype,"parentId",null);O([b("number")],R.prototype,"zIndex",null);O([b("number")],R.prototype,"zIndexLocked",null);var G=globalThis&&globalThis.__decorate||function(r,t,e,o){var s=arguments.length,i=s<3?t:o===null?o=Object.getOwnPropertyDescriptor(t,e):o,n;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(r,t,e,o);else for(var l=r.length-1;l>=0;l--)(n=r[l])&&(i=(s<3?n(i):s>3?n(t,e,i):n(t,e))||i);return s>3&&i&&Object.defineProperty(t,e,i),i};class H extends R{get text(){return""}set text(t){}get textRendererOverride(){return null}set textRendererOverride(t){}get fontSize(){return 0}set fontSize(t){}get fontFamily(){return""}set fontFamily(t){}get fontStretch(){return"normal"}set fontStretch(t){}get fontStyle(){return"normal"}set fontStyle(t){}get fontWeight(){return"normal"}set fontWeight(t){}get textAlign(){return"left"}set textAlign(t){}get contain(){return"none"}set contain(t){}get scrollable(){return!1}set scrollable(t){}get scrollY(){return 0}set scrollY(t){}get offsetY(){return 0}set offsetY(t){}get letterSpacing(){return 0}set letterSpacing(t){}}a(H,"typeId",Co("TEXT"));G([b("string")],H.prototype,"text",null);G([b("string",{propToBuffer(r){return r??"$$null"},bufferToProp(r){return r==="$$null"?null:r}})],H.prototype,"textRendererOverride",null);G([b("number")],H.prototype,"fontSize",null);G([b("string")],H.prototype,"fontFamily",null);G([b("string")],H.prototype,"fontStretch",null);G([b("string")],H.prototype,"fontStyle",null);G([b("string")],H.prototype,"fontWeight",null);G([b("string")],H.prototype,"textAlign",null);G([b("string")],H.prototype,"contain",null);G([b("boolean")],H.prototype,"scrollable",null);G([b("number")],H.prototype,"scrollY",null);G([b("number")],H.prototype,"offsetY",null);G([b("number")],H.prototype,"letterSpacing",null);const Be=()=>{},Qe=()=>new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit",second:"2-digit"}),ko=r=>{const t=po.get("debugLevel"),e={};return Object.defineProperty(e,"info",{get(){return(t>=1||Array.isArray(t)&&t.indexOf("info")>-1)&&console.info.bind(window.console,`%c ⚡️ ${r} %c ${Qe()}`,"background-color: #0284c7; color: white; padding: 3px 6px 3px 1px; border-radius: 3px","color: ##94a3b8;")||Be}}),Object.defineProperty(e,"warn",{get(){return(t>=1||Array.isArray(t)&&t.indexOf("warn")>-1)&&console.warn.bind(window.console,`%c ⚡️ ${r} %c ${Qe()}`,"background-color: #fbbf24; color: white; padding: 3px 6px 3px 1px; border-radius: 3px","color: ##94a3b8;")||Be}}),Object.defineProperty(e,"error",{get(){return(t>=1||Array.isArray(t)&&t.indexOf("error")>-1)&&console.error.bind(window.console,`%c ⚡️ ${r} %c ${Qe()}`,"background-color: #dc2626; color: white; padding: 3px 6px 3px 1px; border-radius: 3px","color: ##94a3b8;")||Be}}),Object.defineProperty(e,"debug",{get(){return(t>=2||Array.isArray(t)&&t.indexOf("debug")>-1)&&console.debug.bind(window.console,`%c ⚡️ ${r} %c (${new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit",second:"2-digit"})})`,"background-color: #e2e8f0; color: #334155; padding: 3px 6px 3px 1px; border-radius: 3px","color: ##94a3b8;")||Be}}),e};let A;const Pr=()=>{A=ko("Blits")};let te;const Ar=(r,t,e)=>{po.set(e),Pr();const o=new Fr;te=new ir({appWidth:e.w||1920,appHeight:e.h||1080,coreExtensionModule:e.fontLoader},t,o);let s;const i=n=>{n.key==="Escape"&&(document.removeEventListener("keydown",i),s.destroy(),s=null,te=null)};document.addEventListener("keydown",i),te.init().then(()=>s=r())},Mt={aliceblue:4042850303,antiquewhite:4209760255,aqua:4294967040,aquamarine:2147472639,azure:4043309055,beige:4126530815,bisque:4293182719,black:255,blanchedalmond:4293643775,blue:65535,blueviolet:2318131967,brown:2771004159,burlywood:3736635391,cadetblue:1604231423,chartreuse:2147418367,chocolate:3530104575,coral:4286533887,cornflowerblue:1687547391,cornsilk:4294499583,crimson:3692313855,cyan:16777215,darkblue:35839,darkcyan:9145343,darkgoldenrod:3095792639,darkgray:2846468607,darkgreen:6553855,darkgrey:2846468607,darkkhaki:3182914559,darkmagenta:2332068863,darkolivegreen:1433087999,darkorange:4287365375,darkorchid:2570243327,darkred:2332033279,darksalmon:3918953215,darkseagreen:2411499519,darkslateblue:1211993087,darkslategray:793726975,darkslategrey:793726975,darkturquoise:13554175,darkviolet:2483082239,deeppink:4279538687,deepskyblue:12582911,dimgray:1768516095,dimgrey:1768516095,dodgerblue:512819199,firebrick:2988581631,floralwhite:4294635775,forestgreen:579543807,fuchsia:4278255615,gainsboro:3705462015,ghostwhite:4177068031,gold:4292280575,goldenrod:3668254975,gray:2155905279,green:8388863,greenyellow:2919182335,grey:2155905279,honeydew:4043305215,hotpink:4285117695,indianred:3445382399,indigo:1258324735,ivory:4294963455,khaki:4041641215,lavender:3873897215,lavenderblush:4293981695,lawngreen:2096890111,lemonchiffon:4294626815,lightblue:2916673279,lightcoral:4034953471,lightcyan:3774873599,lightgoldenrodyellow:4210742015,lightgray:3553874943,lightgreen:2431553791,lightgrey:3553874943,lightpink:4290167295,lightsalmon:4288707327,lightseagreen:548580095,lightskyblue:2278488831,lightslategray:2005441023,lightslategrey:2005441023,lightsteelblue:2965692159,lightyellow:4294959359,lime:16711935,limegreen:852308735,linen:4210091775,magenta:4278255615,maroon:2147483903,mediumaquamarine:1724754687,mediumblue:52735,mediumorchid:3126187007,mediumpurple:2473647103,mediumseagreen:1018393087,mediumslateblue:2070474495,mediumspringgreen:16423679,mediumturquoise:1221709055,mediumvioletred:3340076543,midnightblue:421097727,mintcream:4127193855,mistyrose:4293190143,moccasin:4293178879,navajowhite:4292783615,navy:33023,oldlace:4260751103,olive:2155872511,olivedrab:1804477439,orange:4289003775,orangered:4282712319,orchid:3664828159,palegoldenrod:4008225535,palegreen:2566625535,paleturquoise:2951671551,palevioletred:3681588223,papayawhip:4293907967,peachpuff:4292524543,peru:3448061951,pink:4290825215,plum:3718307327,powderblue:2967529215,purple:2147516671,rebeccapurple:1714657791,red:4278190335,rosybrown:3163525119,royalblue:1097458175,saddlebrown:2336560127,salmon:4202722047,sandybrown:4104413439,seagreen:780883967,seashell:4294307583,sienna:2689740287,silver:3233857791,skyblue:2278484991,slateblue:1784335871,slategray:1887473919,slategrey:1887473919,snow:4294638335,springgreen:16744447,steelblue:1182971135,tan:3535047935,teal:8421631,thistle:3636451583,tomato:4284696575,transparent:0,turquoise:1088475391,violet:4001558271,wheat:4125012991,white:4294967295,whitesmoke:4126537215,yellow:4294902015,yellowgreen:2597139199},Ze={normalize(r=""){if(r=r.toString(),r.startsWith("0x"))return r;const t=/rgba?\((.+)\)/gi,e=/hsla?\((.+)\)/gi;if(t.test(r)){const o=new RegExp(t).exec(r);if(o[1])return r=o[1].split(",").map((s,i)=>(i==3&&(s=Math.min(Math.max(Math.round(s*255),0),255)),parseInt(s).toString(16).padStart(2,"0"))).join(""),r.padEnd(8,"f").padStart(10,"0x")}else{if(e.test(r))return A.warn("HSL(A) color format is not supported yet"),4294967295;if(r in Mt)return Mt[r];r.startsWith("#")&&(r=r.substring(1))}return r.length===3&&(r=r.split("").map(o=>o+o).join("")),r.padEnd(8,"f").padStart(10,"0x")}},Dr=r=>typeof r=="object"&&"transition"in r,Je=r=>typeof r=="string"&&r.startsWith("{")&&r.endsWith("}"),et=r=>JSON.parse(r.replace(/'/g,'"').replace(/([\w-_]+)\s*:/g,'"$1":')),q={unpackTransition(r){return typeof r=="object"&&r.constructor.name==="Object"?"value"in r?r.value:"transition"in r?this.unpackTransition(r.transition):r:r},remap(r){"w"in r&&(r.width=r.w),delete r.w,"h"in r&&(r.height=r.h),delete r.h,"z"in r&&(r.zIndex=r.z),delete r.z},parentId(r){r.parent=r.parentId==="root"?te.root:te.getNodeById(r.parentId),delete r.parentId},color(r){if(typeof r.color=="object"||Je(r.color)&&(r.color=et(r.color))){const t={top:"colorTop",bottom:"colorBottom",left:"colorLeft",right:"colorRight"};Object.entries(r.color).forEach(e=>{r[t[e[0]]]=Ze.normalize(e[1])}),delete r.mount}else r.color=Ze.normalize(r.color)},mount(r){if(typeof r.mount=="object"||Je(r.mount)&&(r.mount=et(r.mount))){const t={x:"mountX",y:"mountY"};Object.entries(r.mount).forEach(e=>{r[t[e[0]]]=e[1]}),delete r.mount}},pivot(r){if(typeof r.pivot=="object"||Je(r.pivot)&&(r.pivot=et(r.pivot))){const t={x:"pivotX",y:"pivotY"};Object.entries(r.pivot).forEach(e=>{r[t[e[0]]]=e[1]}),delete r.pivot}},show(r){r.alpha=r.show?1:0,delete r.show},rotation(r){r.rotation=r.rotation*(Math.PI/180)},text(r){r.text=r.text.toString()},textureColor(r){"color"in r||(r.color="src"in r||"texture"in r?"0xffffffff":"0x00000000")},effects(r){r.shader=te.createShader("DynamicShader",{effects:r.effects.map(t=>(t.props&&t.props.color&&(t.props.color=Ze.normalize(t.props.color)),t))}),delete r.effects},src(r,t){t.indexOf("color")===-1&&(r.color=4294967295)},texture(r,t){this.src(r,t)}},Br={defaults:{rotation:0},populate(r){const t={...this.defaults,...this.config,...r};if(this.initData=r,q.remap(t),Object.keys(t).forEach(e=>{q[e]&&(t[e]=q.unpackTransition(t[e]),q[e](t,this.setProperties)),this.setProperties.push(e)}),q.textureColor(t,this.setProperties),this.node=t.__textnode?te.createTextNode(t):te.createNode(t),t["@loaded"]){const e=t.__textnode?"textLoaded":"txLoaded";this.node.once(e,(o,{width:s,height:i})=>{t["@loaded"]({w:s,h:i},this)})}if(t["@error"]){const e=t.__textnode?"textFailed":"txFailed";this.node.once(e,(o,s)=>{t["@error"](s,this)})}},set(r,t){if(Dr(t)&&this.setProperties.indexOf(r)>-1)this.animate(r,t.transition);else{const e={};r!=="texture"?e[r]=q.unpackTransition(t):e[r]=t,q.remap(e),q[r]&&q[r](e,this.setProperties),Object.keys(e).forEach(o=>{this.node[o]=e[o]})}this.setProperties.indexOf(r)===-1&&this.setProperties.push(r)},delete(){A.debug("Deleting  Node",this.nodeId,this.node),this.node.parent=null},get nodeId(){return this.node&&this.node.id},get ref(){return this.initData.ref||null},animate(r,t){const e={};if(e[r]=q.unpackTransition(t),q.remap(e),q[r]&&q[r](e),r=Object.keys(e).pop(),this.node[r]!==e[r]){const o=this.node.animate(e,{duration:typeof t=="object"&&"duration"in t?t.duration:300,easing:typeof t=="object"&&"function"in t?t.function:"ease"});t.delay?setTimeout(()=>o.start(),t.delay):o.start()}}},jr=r=>Object.assign(Object.create(Br),{node:null,setProperties:[],initData:{},config:r}),zt={};let Yr=0;const Xr=r=>`BlitsComponent::${r}_${zt[r]=(zt[r]||0)+1}`,Wr=()=>++Yr,Se={},Ot=(r,t,e)=>{Se[t]&&Se[t][r]&&Se[t][r].apply(e)},Hr=(r={},t)=>{Se[t]={},Object.keys(r).forEach(e=>{typeof r[e]=="function"&&(Se[t][e]=r[e])})};let Ce=null;const ut=new WeakMap,Io=(r,t)=>{if(Ce){let e=ut.get(r);e||(e=new Map,ut.set(r,e));let o=e.get(t);o||(o=new Set,e.set(t,o)),o.add(Ce)}},pt=(r,t)=>{const e=ut.get(r);if(!e)return;const o=e.get(t);o&&o.forEach(s=>{s()})},Lt=r=>{Ce=r,Ce(),Ce=null},Ur=["constructor","includes","indexOf","lastIndexOf","push","pop","shift","splice","unshift"],Ft=new WeakMap,mt=r=>{const t=Ft.get(r);if(t)return t;const e={get(s,i,n){return Array.isArray(s)&&Ur.includes(i)?Reflect.get(s,i,n):(Io(s,i),s[i]!==null&&typeof s[i]=="object"?mt(s[i]):Reflect.get(s,i,n))},set(s,i,n,l){const d=s[i],c=Reflect.set(s,i,n,l);return typeof c=="object"&&mt(s[i]),(i==="length"||c&&d!==n)&&pt(s,i),c}},o=new Proxy(r,e);return Ft.set(r,o),o},Ro=r=>(Object.keys(r).forEach(t=>{let e=r[t];if(r[t]!==null&&typeof r[t]=="object"&&Object.getPrototypeOf(r[t])===Object.prototype)return Ro(r[t]);Object.defineProperty(r,t,{enumerable:!0,configurable:!0,get(){return Io(r,t),e},set(o){e!==o&&(e=o,pt(r,t))}})}),r),Nt=(r,t="proxy")=>t==="proxy"?mt(r):Ro(r);let J=null;const xt={get(){return J},set(r,t){r!==J&&(J&&J!==r.parent&&J.unfocus(),J=r,J.lifecycle.state="focus",t instanceof KeyboardEvent&&document.dispatchEvent(new KeyboardEvent("keydown",t)))},input(r,t){const e=Mo([J],r),o=e.shift();o&&(o!==J&&(e.reverse().forEach(s=>s.unfocus()),o.focus()),o.___inputEvents[r]?o.___inputEvents[r].call(o,t):o.___inputEvents.any&&o.___inputEvents.any.call(o,t))}},Mo=(r,t)=>r[0].___inputEvents&&(typeof r[0].___inputEvents[t]=="function"||typeof r[0].___inputEvents.any=="function")?r:r[0].parent?(r.unshift(r[0].parent),Mo(r,t)):[],qr=()=>(document.location.hash||"/").replace(/^#/,""),Gr=(r,t=[])=>t.filter(o=>o.path===r).pop(),Kr=function(){if(this.parent.___routes){const r=qr(),t=Gr(r,this.parent.___routes);if(t){if(this.__currentView){for(let e=0;e<this.__currentView.___children.length-1;e++)this.__currentView.___children[e]&&this.__currentView.___children[e].destroy&&(this.__currentView.___children[e].destroy(),this.__currentView.___children[e]=null);this.__currentView.destroy(),this.__currentView=null}this.___children[1]=this.__currentView=t.component(this.___props,this.___children[0],this),this.__currentView.focus()}else A.error(`Route ${r} not found`)}},zo=r=>{window.location.hash=`#${r}`},Pt={navigate:Kr,to:zo},Vr=()=>le("Image",{template:`
      <Element :imageSource="$imageSource" />`,props:["src"],computed:{imageSource(){return/^(?:https?:)?\/\//i.test(this.src)?this.src:`${window.location.protocol}//${window.location.host}/${this.src}`}}}),Qr=()=>le("Circle",{template:`
      <Element :color="$color" :w="$size" :h="$size" :effects="[$shader('radius', {radius: $radius})]"></Element>
    `,props:[{key:"size",default:40},"color"],computed:{radius(){return this.size/2}}});let tt;const Zr=()=>le("RouterView",{template:`
      <Element></Element>
    `,hooks:{ready(){tt=()=>Pt.navigate.apply(this),Pt.navigate.apply(this),window.addEventListener("hashchange",tt)},destroy(){window.removeEventListener("hashchange",tt,!1)}}}),Jr=()=>le("Sprite",{template:`
      <Element w="$w" h="$h" :texture="$texture" />
    `,props:["image","map","frame","w","h"],state(){return{spriteTexture:!1}},computed:{texture(){const r="frames"in this.map?{...this.map.defaults||{},...this.map.frames[this.frame]}:this.map[this.frame];if(this.spriteTexture&&r)return this.___renderer.createTexture("SubTexture",{texture:this.spriteTexture,x:r.x,y:r.y,width:r.w,height:r.h})}},hooks:{ready(){this.spriteTexture=this.___renderer.createTexture("ImageTexture",{src:`${window.location.protocol}//${window.location.host}/${this.image}`})}}}),es=()=>le("Text",{template:`
      <Element
        __textnode="true"
        :text="$text"
        fontFamily="$font"
        :fontSize="$size"
        :color="$color"
        :style="$style"
        :weight="$weight"
        letterSpacing="$letterspacing"
        stretch="$stretch"
        contain="$_contain"
        :w="$w"
        :h="$h"
        :textAlign="$align"
        @loaded="$@loaded"
        @error="$@error"
      />`,props:["content",{key:"font",default:"lato"},{key:"size",cast:Number,default:32},"style","color","weight","letterspacing","stretch","align","w","h","contain","@loaded","@error"],computed:{text(){return this.slotcontent||this.content||""},_contain(){return this.contain||(this.w&&this.h?"both":this.w?"width":"none")}}}),je=new Map,ot={registerListener(r,t,e){let o=je.get(t);o||(o=new Map,je.set(t,o));let s=o.get(r);s||(s=new Set,o.set(r,s)),s.add(e)},executeListeners(r,t){const e=je.get(r);e&&e.forEach(o=>{o.forEach(s=>{s(t)})})},removeListeners(r){je.forEach(t=>{const e=t.get(r);e&&(e.clear(),t.delete(e))})}},At={radius:"radius",rounded:"radius",border:"border",borderTop:"borderTop",glitch:"glitch"},ts=r=>{Object.defineProperties(r.prototype,{focus:{value:function(t){xt.set(this,t)},writable:!1,enumerable:!0,configurable:!1},unfocus:{value:function(){this.lifecycle.state="unfocus"},writable:!1,enumerable:!0,configurable:!1},destroy:{value:function(){this.lifecycle.state="destroy";for(let t=0;t<this.___timeouts.length;t++)clearTimeout(this.___timeouts[t]);for(let t=0;t<this.___intervals.length;t++)clearInterval(this.___intervals[t]);ot.removeListeners(this),Oo(this.___children),A.debug(`Destroyed component ${this.componentId}`)},writable:!1,enumerable:!0,configurable:!1},select:{value:function(t){let e=null;return this.___children.forEach(o=>{Array.isArray(o)?o.forEach(s=>{s.ref===t&&(e=s)}):Object.getPrototypeOf(o)===Object.prototype?Object.keys(o).forEach(s=>{o[s].ref===t&&(e=o[s])}):o.ref===t&&(e=o)}),e},writable:!1,enumerable:!0,configurable:!1},shader:{value:function(t,e){if(t in At)return{type:At[t],props:e};A.error(`Shader ${t} not found`)},writable:!1,enumerable:!1,configurable:!1},$router:{value:{to:zo},writable:!1,enumerable:!0,configurable:!1},___components:{value:{Image:Vr(),Circle:Qr(),RouterView:Zr(),Sprite:Jr(),Text:es()},writable:!1,enumerable:!1,configurable:!1},___timeouts:{value:[],writable:!1,enumerable:!1,configurable:!1},$setTimeout:{value:function(t,e,...o){const s=setTimeout(()=>{this.____timeouts=this.___timeouts.filter(i=>i!==s),t.apply(null,o)},e,o);return this.___timeouts.push(s),s},writable:!1,enumerable:!0,configurable:!1},___intervals:{value:[],writable:!1,enumerable:!1,configurable:!1},$setInterval:{value:function(t,e,...o){const s=setInterval(()=>{this.____intervals=this.___intervals.filter(i=>i!==s),t.apply(null,o)},e,o);return this.___intervals.push(s),s},writable:!1,enumerable:!0,configurable:!1},$emit:{value:function(t,e){ot.executeListeners(t,e)},writable:!1,enumerable:!0,configurable:!1},$listen:{value:function(t,e){ot.registerListener(this,t,e)},writable:!1,enumerable:!0,configurable:!1},___renderer:{value:te,writable:!1,enumerable:!1,configurable:!1},$log:{value:ko("App"),writable:!1,enumerable:!1,configurable:!1}})},Oo=function(r){for(let t=0;t<r.length;t++){if(!r[t])return;Array.isArray(r[t])?Oo(r[t]):r[t].delete?r[t].delete():r[t].destroy&&(r[t].destroy(),r[t]=null),r[t]=null}r=[]},os={cast:r=>r,required:!1},rs=(r,t=[])=>{t.indexOf("ref")===-1&&t.push("ref"),r.___propKeys=[],t.forEach(e=>{e={...os,...typeof e=="object"?e:{key:e}},r.___propKeys.push(e.key),Object.defineProperty(r.prototype,e.key,{get(){const o=e.cast(this.___props&&e.key in this.___props?this.___props[e.key]:e.default||void 0);return e.required&&o===void 0&&A.warn(`${e.key} is required`),o},set(o){A.warn(`Warning! Avoid mutating props directly (${e.key})`),this.___props[e.key]=o}})})},ss=(r,t)=>{r.___methodsKeys=[];for(let e in t)r.___propKeys&&r.___propKeys.indexOf(e)>-1?A.error(`${e} already exists as a prop`):(typeof t[e]!="function"&&A.warn(`${e} is not a function`),r.___methodsKeys.push(e),r.prototype[e]=t[e])},is=(r,t)=>{r.___stateKeys=[],t=t.apply(r),Object.keys(t).forEach(e=>{r.___propKeys&&r.___propKeys.indexOf(e)>-1&&A.error(`State ${e} already exists as a prop`),r.___methodKeys&&r.___methodKeys.indexOf(e)>-1&&A.error(`State ${e} already exists as a method`),r.___stateKeys.push(e);try{Object.defineProperty(r.prototype,e,{get(){return this.___state&&e in this.___state&&this.___state[e]},set(o){this.___state&&(this.___state[e]=o)}})}catch(o){A.error(o)}})},ns=(r,t)=>{r.___computedKeys=[];for(let e in t)r.___stateKeys&&r.___stateKeys.indexOf(e)>-1?A.error(`${e} already exists as a prop`):r.___propKeys&&r.___propKeys.indexOf(e)>-1?A.error(`${e} already exists as a prop`):r.___methodKeys&&r.___methodKeys.indexOf(e)>-1?A.error(`${e} already exists as a method`):(typeof t[e]!="function"&&A.warn(`${e} is not a function`),r.___computedKeys.push(e),Object.defineProperty(r.prototype,e,{get(){return t[e].apply(this)}}))},as=(r,t)=>{r.prototype.___inputEvents=[],Object.keys(t).forEach(e=>{typeof t[e]!="function"&&A.warn(`${t[e]} is not a function`),r.prototype.___inputEvents[e]=t[e]})},ls=(r,t)=>{r.prototype.___routes=[],Object.keys(t).forEach(e=>{r.prototype.___routes[e]=t[e]})},cs=(r,t)=>{r.prototype.___watchKeys=[],r.prototype.___watchers={};for(let e in t)typeof t[e]!="function"&&console.warn(`${e} is not a function`),r.prototype.___watchKeys.push(e),r.prototype.___watchers[e]=function(o,s){t[e].call(this,o,s)}},Dt={element:jr},Bt=r=>{throw new Error(`Parameter ${r} is required`)},le=(r=Bt("name"),t=Bt("config"))=>{let e=null;const o=l=>{e||(A.debug(`Generating code for ${r} component`),e=tr.call(t,er(t.template))),ts(i),Hr(t.hooks,r),l.state="beforeSetup",rs(i,t.props),t.methods&&ss(i,t.methods),t.state&&is(i,t.state),t.computed&&ns(i,t.computed),t.watch&&cs(i,t.watch),t.routes&&ls(i,t.routes),t.input&&as(i,t.input),i.setup=!0,l.state="setup"},s=l=>{const d=["init","beforeSetup","setup","ready","focus","unfocus","destroy"];return{previous:null,current:null,get state(){return this.current},set state(c){d.indexOf(c)>-1&&c!==this.current&&(A.debug(`Setting lifecycle state from ${this.previous} to ${c} for ${l.componentId}`),this.previous=this.current,Ot(`___${c}`,r,l),Ot(c,r,l),this.current=c)}}},i=function(l,d,c){this.lifecycle=s(this),i.setup||o(this.lifecycle),this.parent=c,Object.defineProperties(this,{componentId:{value:Xr(r),writable:!1,enumerable:!0,configurable:!1},___id:{value:Wr(),writable:!1,enumerable:!1,configurable:!1},___props:{value:Nt(l.props||{}),writable:!1,enumerable:!1,configurable:!1}}),Object.defineProperty(this,"___state",{value:Nt(t.state&&typeof t.state=="function"&&t.state.apply(this)||{}),writable:!1,enumerable:!1,configurable:!1}),this.lifecycle.state="init",Object.defineProperty(this,"___children",{value:e.render.apply(Dt,[d,this,e.context]),writable:!1,enumerable:!1,configurable:!1}),e.effects.forEach(h=>{Lt(()=>{h.apply(Dt,[this,this.___children,e.context])})}),this.___watchers&&Object.keys(this.___watchers).forEach(h=>{let p=this[h];Lt(()=>{p!==this[h]&&(this.___watchers[h].apply(this,[this[h],p]),p=this[h])})}),setTimeout(()=>this.lifecycle.state="ready")},n=(l={},d,c)=>new i(l,d,c);return n.config=t,n},hs=r=>{const t={ArrowLeft:"left",ArrowRight:"right",ArrowUp:"up",ArrowDown:"down",Enter:"enter"," ":"space",Backspace:"back"},e=s=>{const i=t[s.key]||s.key;xt.input(i,s)};return document.addEventListener("keydown",e),r.hooks=r.hooks||{},r.hooks.___init=function(){xt.set(this)},r.hooks.___destroy=function(){document.removeEventListener("keydown",e)},le("App",r)},E={Component:le,Application:hs,Launch:Ar},fs=new URL("fontLoader-11a5e7d7.js",import.meta.url).href,ye=E.Component("Square",{template:`
    <Element w="$size" h="$size" color="#86198f" />
  `,props:[{key:"size",default:80}]}),jt=E.Component("Loading",{components:{Square:ye},template:`
    <Element>
      <Text content="BLITS EXAMPLE APP" x="100" y="100" size="30" />
      <Text content="use the left / right arrow keys to cycle through the examples" color="#6d7e9c" x="100" y="140" size="20" />
      <Element x="880" y="500">
        <Circle size="40" color="#94a3b8" :alpha.transition="{value: $alpha, delay: 200}" />
        <Circle size="40" color="#94a3b8" x="60" :alpha.transition="{value: $alpha, delay: 300}" />
        <Circle size="40" color="#94a3b8" x="120" :alpha.transition="{value: $alpha, delay: 400}" />
      </Element>
    </Element>
  `,state(){return{alpha:0}},hooks:{ready(){let r=0;this.$setInterval(()=>{this.alpha=r%2?0:1,r++},800)}}}),Yt=E.Component("Positioning",{template:`
    <Element>
      <!-- regular positioning -->
      <Element w="100" h="100" x="20" y="20" color="#ecfeff" />
      <Element w="100" h="100" x="140" y="20" color="#a5f3fc" />
      <Element w="100" h="100" x="260" y="20" color="#22d3ee" />
      <Element w="100" h="100" x="380" y="20" color="#0891b2" />

      <!-- positioning with dynamic values -->
      <Element w="100" h="100" x="$x1" y="$y" color="#fdf4ff" />
      <Element w="100" h="100" x="$x2" y="$y" color="#f5d0fe" />
      <Element w="100" h="100" x="$x3" y="$y" color="#e879f9" />
      <Element w="100" h="100" x="$x4" y="$y" color="#c026d3" />

      <!-- positioning with reactive values -->
      <Element w="100" h="100" :x="$xA" y="260" color="#fff7ed" />
      <Element w="100" h="100" :x="$xB" y="260" color="#fed7aa" />
      <Element w="100" h="100" :x="$xC" y="260" color="#fb923c" />
      <Element w="100" h="100" :x="$xD" y="260" color="#ea580c" />

      <!--- positioning of nested elements -->
      <Element w="800" h="800" y="20" x="800" color="#ecfdf5">
        <Element w="600" h="600" y="20" x="20" color="#a7f3d0">
          <Element w="400" h="400" y="100" x="20" color="#34d399">
            <Element w="200" h="100" :y="(400-100)/2" :x="(400-200)/2" color="#059669">
              <Element w="50" h="50" :y.transition="$yNested" :x.transition="$xNested" color="#065f46" />
            </Element>
          </Element>
        </Element>
      </Element>

      <!-- positioning after a set of nested elements -->
      <Element w="100" h="100" y="500" x="20" color="#e11d48" />

      <!-- zIndex not inherited by children - currently broken and being investigated :) -->
      <Element w="200" h="200" x="300" y="600" color="#94a3b8" z="100">
        <Text content="Lightning!" x="100" y="140" />
        <Element w="300" h="100" color="#475569" />
        <Circle x="150" y="150" size="100"/>
      </Element>
      <Element w="300" h="300" x="300" y="600" color="#ef444480" />

      <Element w="400" h="100" x="800" y="900" color="#0284c7">
        <Element w="42%" h="30%" y="5%" x="1%" color="#075985" />
        <Element :w="$bar2.v" h="30%" y="35%" x="1%" color="#6b21a8" />
        <Element :w.transition="$bar3" h="30%" y="65%" x="1%" color="#9f1239" />
      </Element>

    </Element>`,state(){return{x1:20,x2:140,x3:20+140+100,x4:380,y:140,xA:20,xB:140,xC:260,xD:380,yNested:0,xNested:0,bar2:{direction:"up",v:"10%"},bar3:"10%"}},hooks:{ready(){this.$setTimeout(()=>{this.xD=this.xD+200,this.xC=this.xC+100,this.xB=this.xB+50,this.xA=this.xA+25},4e3),this.$setInterval(()=>{this.yNested=this.yNested===0?50:0},2e3),this.$setInterval(()=>{this.xNested=this.xNested===0?150:0},1e3),this.$setInterval(()=>{const r=parseFloat(this.bar2.v),t=this.bar2.direction==="up"?r+10:r-10;this.bar2.v=t+"%",t>=90&&(this.bar2.direction="down"),t<=10&&(this.bar2.direction="up")},400),this.$setInterval(()=>{this.bar3=Math.ceil(Math.random()*96)+"%"},2e3)}}}),Xt=E.Component("Transitions",{template:`
    <Element>
      <!-- simple, default transition -->
      <Element w="200" h="200" x="50" :y.transition="$y" color="#c4b5fd" />
      <!-- simple, default transition with object syntax -->
      <Element w="200" h="200" x="300" :y.transition="{value: $y}" color="#a78bfa" />
      <!-- transition with custom duration -->
      <Element w="200" h="200" x="550" :y.transition="{value: $y, duration: 1000}" color="#8b5cf6" />
      <!-- transition with custom duration and wait -->
      <Element w="200" h="200" x="800" :y.transition="{value: $y, duration: 500, delay: 1000}" color="#7c3aed" />
      <!-- transition with built-in easing function -->
      <Element w="200" h="200" x="1050" :y.transition="{value: $y, function: 'ease-in-out'}" color="#6d28d9" />
      <!-- transition with custom duration and a built-in easing function -->
      <Element w="200" h="200" x="1300" :y.transition="{value: $y, duration: 2000, function: 'ease-in-out-back'}" color="#5b21b6" />
      <!-- transition with custom duration and a custum bezier function -->
      <Element w="200" h="200" x="1550" :y.transition="{value: $y, duration: 800, function: 'cubic-bezier(1,-0.64,.39,1.44)'}" color="#4c1d95" />
    </Element>`,state(){return{y:50}},hooks:{ready(){this.$setTimeout(()=>{this.y=1080-50-200},2e3)}}}),Wt=E.Component("Colors",{template:`
    <Element w="1920" h="1080" :color.transition="$bg">
      <!-- hex colors -->
      <Element x="20" y="20">
        <Element w="100" h="100" x="0" color="#ecfeff" />
        <Element w="100" h="100" x="120" color="#a5f3fc" />
        <Element w="100" h="100" x="240" color="#22d3ee" />
        <Element w="100" h="100" x="360" color="#0891b2" />
      </Element>

      <!-- hex colors without #-->
      <Element x="20" y="140">
        <Element w="100" h="100" x="0" color="ecfeff" />
        <Element w="100" h="100" x="120" color="a5f3fc" />
        <Element w="100" h="100" x="240" color="22d3ee" />
        <Element w="100" h="100" x="360" color="0891b2" />
      </Element>

      <!-- hex colors with alpha-->
      <Element x="20" y="260">
        <Element w="100" h="100" x="0" color="#ecfeffaa" />
        <Element w="100" h="100" x="120" color="#a5f3fc33" />
        <Element w="100" h="100" x="240" color="#22d3ee20" />
        <Element w="100" h="100" x="360" color="#0891b2ff" />
      </Element>

      <!-- rgb() colors-->
      <Element x="20" y="380">
        <Element w="100" h="100" x="0" color="rgb(236,254,255)" />
        <Element w="100" h="100" x="120" color="rgb(165,243,252)" />
        <Element w="100" h="100" x="240" color="rgb(34,211,238)" />
        <Element w="100" h="100" x="360" color="rgb(8,145,178)" />
      </Element>

      <!-- rgba() colors-->
      <Element x="20" y="500">
        <Element w="100" h="100" x="0" color="rgba(236,254,255,0.67)" />
        <Element w="100" h="100" x="120" color="rgba(165,243,252,0.2)" />
        <Element w="100" h="100" x="240" color="rgba(34,211,238, 0.13)" />
        <Element w="100" h="100" x="360" color="rgba(8,145,178,1)" />
      </Element>

      <!-- 3 char hex colors -->
      <Element x="20" y="620">
        <Element w="100" h="100" x="0" color="#000" />
        <Element w="100" h="100" x="120" color="#ccc" />
        <Element w="100" h="100" x="240" color="#890" />
        <Element w="100" h="100" x="360" color="#0f0" />
      </Element>

      <!-- 3 char hex colors without #-->
      <Element x="20" y="740">
        <Element w="100" h="100" x="0" color="000" />
        <Element w="100" h="100" x="120" color="ccc" />
        <Element w="100" h="100" x="240" color="890" />
        <Element w="100" h="100" x="360" color="0f0" />
      </Element>

      <Element x="620" y="20">
        <Element w="300" h="200" x="0" :color.transition="$color1" />
        <Element w="300" h="200" x="0" y="250" :color.transition="$color2" />
        <Element w="300" h="200" x="100" y="400" :color.transition="$color3"/>
        <Element w="300" h="200" x="0" y="650" :color.transition="{value: $color4, d: 1000, f: 'ease-in-out'}" />
      </Element>
    </Element>`,state(){return{bg:"#fff",color1:"#22d3ee",color2:"#dc2626",color3:"rgba(251, 191, 36)",color4:"#bfdbfe"}},input:{enter(){this.color1=this.color1==="#0891b2"?"#22d3ee":"#0891b2",this.color2=this.color2==="#dc2626"?"#0f0":"#dc2626",this.color3=this.color3==="rgba(251, 191, 36)"?"rgba(30, 64, 175, 0.5)":"rgba(251, 191, 36)",this.color4=this.color4==="#1e3a8a"?"#bfdbfe":"#1e3a8a"}},hooks:{ready(){let r=0;const t=["#fff","#333","#c0ff33","#546aaa","#000","tomato"];this.$setInterval(()=>{r=r+1,r===t.length-1&&(r=0),this.bg=t[r]},2e3)}}}),W=["#bbf7d0","#86efac","#4ade80","#22c55e","#16a34a","#15803d"],Ht=E.Component("ForLoop",{components:{Square:ye},template:`
    <Element>
      <Element y="20">
        <Element :for="item in $collection1" w="80" h="80" x="$item" color="#4d7c0f" />
      </Element>

      <Element y="120">
        <!-- looping over an array with objects -->
        <Element :for="item in $collection2" w="80" h="80" :x="$item.x * $index" color="$item.color" key="$item.id" />
      </Element>

      <Element y="220">
        <!-- looping over an array empty array, adding items over time -->
        <Element :for="item in $collection3" w="80" h="80" :x="$item.x" color="$item.color" />
      </Element>

      <Element y="320">
        <Square :for="(item, index) in $collection2" :x="$item.x * $index" :ref="'square'+$index" :alpha="$alpha" />
      </Element>

      <Element y="420">
        <!-- looping over an array of components, adding items over time -->
        <Square :for="item in $collection3" :x="$item.x" key="$item.color" :alpha="$alpha" />

      </Element>

      <Element y="520">
        <!-- looping over an array and using a component state variable -->
        <Element :for="item in $collection1" w="80" h="80" :x="$item" color="#eab308" :alpha="$alpha" />
      </Element>

      <Element y="620">
        <!-- looping over an array and using a component state variable and passing a key -->
        <Element :for="item in $collection2" w="80" h="80" :x="$item.x" color="$item.color" :alpha="$alpha" key="$item.id" />
      </Element>


    </Element>
  `,state(){return{collection1:[0,100,200,300,400,500],collection2:[{id:"block1",x:0,color:W[0]},{id:"block2",x:100,color:W[1]},{id:"block3",x:200,color:W[2]},{id:"block4",x:300,color:W[3]},{id:"block5",x:400,color:W[4]},{id:"block6",x:500,color:W[5]}],collection3:[],alpha:.5}},hooks:{ready(){this.$setTimeout(()=>{this.collection2[0].color=W[5],this.collection2[1].color=W[4],this.collection2[2].color=W[3],this.collection2[3].color=W[2],this.collection2[4].color=W[1],this.collection2[5].color=W[0]},4e3);let r=0;const t=this.$setInterval(()=>{this.collection3.push({x:r*100,color:W[r]}),r++,r===W.length&&clearInterval(t)},1e3);this.$setTimeout(()=>{this.alpha=this.alpha===.5?1:.5},800)}}}),Lo=E.Component("Card",{components:{Square:ye},template:`
    <Element w="$w" h="$h" color="#0891b2">
      <Square x="80" y="80" />
      <Square x="20" y="20" size="40" />
    </Element>`,props:["size"],computed:{w(){return this.size==="large"?400:200},h(){return this.size==="large"?500:300}}}),Ut=E.Component("Components",{components:{Square:ye,Card:Lo},template:`
    <Element>
      <!-- simple square component that takes a size (number) argument and maps it to w and h -->
      <Square x="100" y="100" size="50" />
      <Square x="100" y="200" size="100" />
      <Square x="100" y="350" size="200" />
      <!-- reactive (animated) x position for component -->
      <Square :x.transition="$x" y="600" size="50" />
      <!-- card component that takes a string size argument and also has a nested square component -->
      <Card x="500" y="100" />
      <Card x="500" y="500" size="large" />
    </Element>`,state(){return{x:100}},hooks:{ready(){this.$setInterval(()=>{this.x=this.x===100?250:100},2e3)}}}),qt=E.Component("Gradients",{template:`
    <Element>
      <Element :w="1920/4" h="1080" color="{top: '#0891b2', bottom: '#a5f3fc'}" />
      <Element :w="1920/4" h="1080" :x="1920/4" color="{left: '#dc2626',  right: '#f87171'}" />
      <Element :w="1920/4" h="1080" :x="1920/4 * 2" color="{top: '#0891b2', right: '#f87171'}" />
      <Element :w="1920/4" h="1080" :x="1920/4 * 3" color="{right: 'green', bottom: 'gold'}" />
    </Element>`}),Gt=E.Component("KeyInput",{template:`
    <Element x="525" y="130">

      <Element w="200" h="200" :color="$focusColor" :x="$focusedX * 220" :y="$focusedY * 210" />

      <Element w="180" h="180" x="10" y="10" :color="$blockColor" />
      <Element w="180" h="180" x="230" y="10" :color="$blockColor" />
      <Element w="180" h="180" x="450" y="10" :color="$blockColor" />
      <Element w="180" h="180" x="670" y="10" :color="$blockColor" />

      <Element w="180" h="180" x="10" y="220" :color="$blockColor" />
      <Element w="180" h="180" x="230" y="220" :color="$blockColor" />
      <Element w="180" h="180" x="450" y="220" :color="$blockColor" />
      <Element w="180" h="180" x="670" y="220" :color="$blockColor" />

      <Element w="180" h="180" x="10" y="430" :color="$blockColor" />
      <Element w="180" h="180" x="230" y="430" :color="$blockColor" />
      <Element w="180" h="180" x="450" y="430" :color="$blockColor" />
      <Element w="180" h="180" x="670" y="430" :color="$blockColor" />

      <Element w="180" h="180" x="10" y="640" :color="$blockColor" />
      <Element w="180" h="180" x="230" y="640" :color="$blockColor" />
      <Element w="180" h="180" x="450" y="640" :color="$blockColor" />
      <Element w="180" h="180" x="670" y="640" :color="$blockColor" />

    </Element>`,state(){return{focusedX:0,focusedY:0,colorscheme:"yellow"}},computed:{blockColor(){return this.colorscheme==="yellow"?"#fef08a":"#bae6fd"},focusColor(){return this.colorscheme==="yellow"?"#facc15":"#38bdf8"}},input:{left(r){const t=this.focusedX-1;t===-1?this.parent.focus(r):this.focusedX=Math.max(t,0)},right(r){const t=this.focusedX+1;t===4?this.parent.focus(r):this.focusedX=Math.min(t,3)},up(){this.focusedY=Math.max(this.focusedY-1,0)},down(){this.focusedY=Math.min(this.focusedY+1,3)},enter(){this.colorscheme=this.colorscheme==="yellow"?"blue":"yellow"},any(r){const t=parseInt(r.key);isNaN(t)||(this.focusedX=Math.max(0,(t-1)%4),this.focusedY=Math.max(0,Math.ceil(t/4)-1))}}}),Kt=E.Component("Scaling",{template:`
    <Element>
      <!-- non scaled element of 150 -->
      <Element x="100" y="100" w="150" h="150" color="#64748b" />
      <!-- element of 100 scaled with 1.5 to 150 -->
      <Element x="300" y="100" w="100" h="100" color="#64748b" scale="1.5" />

      <!-- scaling with a dynamic value -->
      <Element x="100" y="400" w="100" h="100" color="#b45309" scale="$scale" />

      <!-- reactive scaling (with transition) -->
      <Element x="900" y="400" w="100" h="100" :src="$balloon" :scale.transition="{value: $scale, function: 'ease-in-out'}" />

      <!-- scaling with a nested element -->
      <Element x="300" y="600" w="100" h="100" color="#059669" :scale="$scale2">
        <Element x="10" y="10" h="60" w="80" color="#0369a1" />
      </Element>

      <!-- scaling with a nested element that also uses scaling -->
      <Element x="1500" y="600" w="100" h="100" color="#059669" :scale="$scale2">
        <Element x="10" y="10" h="60" w="80" color="#0369a1" :scale="$scale2 / 2" />
      </Element>

    </Element>`,state(){return{scale:2,direction:"up",balloon:"/assets/balloon.png",scale2:1}},hooks:{ready(){this.$setInterval(()=>{const r=this.direction==="up"?this.scale+.5:0;this.scale=Math.max(Math.min(r,8),0),this.scale===8&&(this.direction="down"),this.scale===0&&(this.direction="up")},500),this.$setInterval(()=>{this.scale2=this.scale2===1?3:1},2e3)}}}),Vt=E.Component("Effects",{template:`
    <Element>
      <!-- rounded corner effect -->
      <Element
        w="160" h="160" x="40" y="40" color="#fb923c"
        :effects="[$shader('radius', {radius: 44})]"
      />

      <Element
        w="160" h="160" x="240" y="40" color="#d97706"
        :effects="[$shader('radius', {radius: 25})]"
      />

      <Element
        w="160" h="160" x="440" y="40" color="#b45309"
        :effects="[$shader('radius', {radius: 80})]"
      />

      <Element
        w="160" h="160" x="640" y="40" color="#78350f"
        :effects="[$shader('radius', {radius: 10})]"
      />

      <!-- reactive rounded corner effect -->
      <Element
        w="160" h="160" x="40" y="240" color="#65a30d"
        :effects="[$shader('radius', {radius: $radius})]"
      />

      <!-- nested rounded corner effects -->
      <Element
        w="300" h="300" x="40" y="440" color="#0c4a6e"
        :effects="[$shader('radius', {radius: 30})]"
      >
        <Element
          w="200" h="200" x="50" y="50" color="#0284c7"
          :effects="[$shader('radius', {radius: 40})]"
        >
          <Element
            w="100" h="100" x="50" y="50" color="#38bdf8"
            :effects="[$shader('radius', {radius: 50})]"
          >
            <Element
              w="40" h="40" x="30" y="30" color="#bae6fd"
              :effects="[$shader('radius', {radius: 20})]"
            >
            </Element>
          </Element>
        </Element>
      </Element>

      <Element
        w="160" h="160" x="840" y="40" color="#3b82f6"
        :effects="[$shader('radius', {radius: 10}), $shader('border', {width: 20, color: '#60a5fa'})]"
      />

      <Element
        w="160" h="160" x="1040" y="40" color="#500724"
        :effects="$effects"
      />
    </Element>`,state(){return{direction:"up",radius:0,effects:[this.shader("borderTop",{width:20,color:"#be123c"}),this.shader("borderBottom",{width:20,color:"#f43f5e"})]}},hooks:{ready(){this.$setInterval(()=>{const t=this.direction==="up"?this.radius+10:this.radius-10;this.radius=Math.max(Math.min(t,80),0),this.radius===80&&(this.direction="down"),this.radius===0&&(this.direction="up")},500);let r=0;this.$setInterval(()=>{r++,r%2?this.effects=[this.shader("borderLeft",{width:20,color:"#be123c"}),this.shader("borderRight",{width:20,color:"#f43f5e"})]:this.effects=[this.shader("borderTop",{width:20,color:"#be123c"}),this.shader("borderBottom",{width:20,color:"#f43f5e"})]},2e3)}}}),Qt=E.Component("Alpha",{template:`
    <Element>
      <Element y="100">
        <!-- hardcoded alpha values -->
        <Element w="200" h="200" x="100" color="#fff" alpha="0.2" />
        <Element w="200" h="200" x="320" color="#fff" alpha="0.4" />
        <Element w="200" h="200" x="540" color="#fff" alpha="0.6" />
        <Element w="200" h="200" x="760" color="#fff" alpha="0.8" />
        <Element w="200" h="200" x="980" color="#fff" alpha="1" />
      </Element>

      <!-- dynamic (but not reactive) alpha value -->
      <Element w="200" h="200" x="100" y="320" color="#fff" alpha="$alpha" />

      <!-- reactive alpha value -->
      <Element w="200" h="200" x="100" y="540" color="#fff" :alpha="$alpha" />

      <!-- reactive alpha value (with transition) -->
      <Element w="200" h="200" x="100" y="760" color="#fff" :alpha.transition="{value: $alpha, duration: 1000, function: 'ease-in-out-circ'}" />

      <Element w="428" h="234" x="1200" y="100" :src="$image" alpha="1" />
      <Element w="428" h="234" x="1300" :y="100 + 234 - 40" :src="$image" alpha=".4" />
      <Element w="428" h="234" x="1200" :y="100 + (234 * 2) - (40 * 2)" :src="$image" alpha=".1" />

    </Element>`,state(){return{alpha:.5,direction:"up",image:"assets/lightningbolt.png"}},hooks:{ready(){this.$setInterval(()=>{const r=this.direction==="up"?this.alpha+.2:this.alpha-.2;this.alpha=Math.max(Math.min(r,1),.1),this.alpha===1&&(this.direction="down"),this.alpha===.1&&(this.direction="up")},1400)}}}),ds=E.Component("Letter",{template:`
    <Element>
      <Element w="$w" :h.transition="{value: 410+$offset, duration: $duration, delay: $wait, function: $timingFunction}" color="#E6E6E6" />
      <Element w="$w" h="280" :src="$image" :y.transition="{value: 400+$offset, duration: $duration, delay: $wait, function: $timingFunction}" />
      <Element w="$w" color="#E6E6E6"
        :h.transition="{value: 500-$offset, duration: $duration, delay: $wait, function: $timingFunction}"
        :y.transition="{value: 660+$offset, duration: $duration, delay: $wait, function: $timingFunction}"
      />
    </Element>`,props:["w","letter","direction","delay"],computed:{image(){return`${window.location.protocol}//${window.location.host}/assets/${this.letter}.png`}},state(){return{offset:this.direction==="up"?-680:680,duration:1e3,wait:0,timingFunction:"cubic-bezier(1,-0.64,.39,1.44)"}},hooks:{ready(){this.animate()}},methods:{animate(){this.$setTimeout(()=>{this.offset=0},1e3),this.$setTimeout(()=>{this.wait=this.delay+150,this.duration=1e3,this.offset=1080},2800),this.$setTimeout(()=>{this.wait=this.delay/3,this.timingFunction="ease-in-out",this.duration=1500,this.offset=0},5e3)}}}),Zt=E.Component("Intro",{components:{Letter:ds},template:`
    <Element w="1920" h="1080" :src="$background">
      <Letter letter="l" w="294" />
      <Letter letter="i-1" w="128" x="294" direction="up" delay="50" />
      <Letter letter="g-1" w="205" x="422" delay="100" />
      <Letter letter="h" w="224" x="627" direction="up" delay="150" />
      <Letter letter="t" w="190" x="851" delay="200" />
      <Letter letter="n-1" w="221" x="1041" direction="up" delay="250" />
      <Letter letter="i-2" w="115" x="1262" delay="300" />
      <Letter letter="n-2" w="219" x="1377" direction="up" delay="350" />
      <Letter letter="g-2" w="324" x="1596" direction="up" delay="400" />
    </Element>`,state(){return{background:`${window.location.protocol}//${window.location.host}/assets/background.png`}}}),Jt=E.Component("ShowIf",{components:{Square:ye},template:`
    <Element>

      <!-- hardcoded show values -->
      <Element y="40">

        <!-- should show -->
        <Element x="50" w="200" h="300" color="#bef264" show="true" />
        <!-- should not show -->
        <Element x="350" w="200" h="300" color="#bef264" show="false" />

        <!-- should show -->
        <Element x="650" w="200" h="300" color="#84cc16" show="1" />
        <!-- should not show -->
        <Element x="950" w="200" h="300" color="#84cc16" show="0" />

      </Element>

      <!-- dynamic show values -->
      <Element y="380">

        <!-- should show -->
        <Element x="50" w="200" h="300" color="#fde047" show="$showNr" />
        <!-- should not show -->
        <Element x="350" w="200" h="300" color="#fde047" show="$hideNr" />

        <!-- should show -->
        <Element x="650" w="200" h="300" color="#84cc16" show="$showBool" />
        <!-- should not show -->
        <Element x="950" w="200" h="300" color="#84cc16" show="$hideBool" />

      </Element>

      <!-- dynamic show value -->
      <Element y="720">

        <!-- should show / hide every 2 seconds -->
        <Element x="50" w="200" h="300" color="#5eead4" :show="$showHideToggle" />

      </Element>

      <!-- show on components! -->
      <Element y="40" x="1000">
        <!-- should show -->
        <Square show="true" />
        <!-- should not show -->
        <Square y="100" show="false" />
        <!-- should show / hide every 2 seconds -->
        <Square y="200" :show="$showHideToggle" />
      </Element>

    </Element>`,state(){return{showNr:1,hidNr:0,showBool:!0,hideBool:!1,showHideToggle:!0}},hooks:{ready(){this.$setInterval(()=>{this.showHideToggle=!this.showHideToggle},2e3),this.$setTimeout(()=>{this.showNr=0,this.hideNr=1,this.showBool=!1,this.hideBool=!0},4e3)}}}),Ye=["https://images.unsplash.com/photo-1690360994204-3d10cc73a08d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=428&q=80","https://images.unsplash.com/photo-1582971103098-bfc707d2ad92?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=428&q=80"],eo=E.Component("Images",{template:`
    <Element>
      <!-- local image -->
      <Element src="assets/lightningbolt.png" w="428" h="234" x="100" y="100" />

      <!-- remote image -->
      <Element
        src="https://images.unsplash.com/photo-1611148799269-63df34f63f6c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=428&q=80"
        w="428" h="234" x="100" y="400"
      />

      <Element
        :src="$image"
        w="428" h="234" x="100" y="700"
      />

      <!-- local image with color -->
      <Element  color="gold" src="assets/lightningbolt.png" w="428" h="234" x="600" y="100" />

      <!-- applying clipping -->
      <Element x="600" y="400" w="428" h="234" :clipping="$clipping">
        <Element src="assets/lightningbolt.png" w="856" h="468" />
      </Element>

    </Element>`,state(){return{image:Ye[0],clipping:!0}},hooks:{ready(){this.$setInterval(()=>{this.image=this.image===Ye[0]?Ye[1]:Ye[0],this.clipping=!this.clipping},2e3)}}}),to=E.Component("Rotation",{template:`
    <Element>

      <!-- hardcoded rotation value -->
      <Element y="70">
        <Element x="100" y="0" w="200" h="100" color="#fee2e2" rotation="0"/>
        <Element x="100" y="150" w="200" h="100" color="#fecaca" rotation="10"/>
        <Element x="100" y="300" w="200" h="100" color="#fca5a5" rotation="20"/>
        <Element x="100" y="450" w="200" h="100" color="#f87171" rotation="30"/>
        <Element x="100" y="610" w="200" h="100" color="#ef4444" rotation="40"/>
        <Element x="100" y="800" w="200" h="100" color="#dc2626" rotation="50"/>
      </Element>

      <Element y="70" x="300">
        <Element x="100" y="0" w="200" h="100" color="#fee2e2" rotation="60"/>
        <Element x="100" y="150" w="200" h="100" color="#fecaca" rotation="70"/>
        <Element x="100" y="300" w="200" h="100" color="#fca5a5" rotation="80"/>
        <Element x="100" y="450" w="200" h="100" color="#f87171" rotation="90"/>
        <Element x="100" y="610" w="200" h="100" color="#ef4444" rotation="100"/>
        <Element x="100" y="800" w="200" h="100" color="#dc2626" rotation="100"/>
      </Element>

      <Element y="70" x="600">
        <Element x="100" y="0" w="200" h="100" color="#fee2e2" rotation="110"/>
        <Element x="100" y="150" w="200" h="100" color="#fecaca" rotation="120"/>
        <Element x="100" y="300" w="200" h="100" color="#fca5a5" rotation="130"/>
        <Element x="100" y="450" w="200" h="100" color="#f87171" rotation="140"/>
        <Element x="100" y="610" w="200" h="100" color="#ef4444" rotation="150"/>
        <Element x="100" y="800" w="200" h="100" color="#dc2626" rotation="160"/>
      </Element>

      <Element y="70" x="900">
        <Element x="100" y="0" w="200" h="100" color="#fee2e2" rotation="170"/>
        <Element x="100" y="150" w="200" h="100" color="#fecaca" rotation="180"/>
        <Element x="100" y="300" w="200" h="100" color="#fca5a5" rotation="190"/>
        <Element x="100" y="450" w="200" h="100" color="#f87171" rotation="200"/>
        <Element x="100" y="610" w="200" h="100" color="#ef4444" rotation="210"/>
        <Element x="100" y="800" w="200" h="100" color="#dc2626" rotation="220"/>
      </Element>

      <Element y="70" x="1200">
        <Element x="100" y="0" w="200" h="100" color="#fee2e2" rotation="230"/>
        <Element x="100" y="150" w="200" h="100" color="#fecaca" rotation="240"/>
        <Element x="100" y="300" w="200" h="100" color="#fca5a5" rotation="250"/>
        <Element x="100" y="450" w="200" h="100" color="#f87171" rotation="260"/>
        <Element x="100" y="610" w="200" h="100" color="#ef4444" rotation="270"/>
        <Element x="100" y="800" w="200" h="100" color="#dc2626" rotation="280"/>
      </Element>

      <Element y="70" x="1500">
        <Element x="100" y="0" w="200" h="100" color="#fee2e2" rotation="290"/>
        <Element x="100" y="150" w="200" h="100" color="#fecaca" rotation="300"/>
        <Element x="100" y="300" w="200" h="100" color="#fca5a5" rotation="310"/>
        <Element x="100" y="450" w="200" h="100" color="#f87171" rotation="320"/>
        <Element x="100" y="610" w="200" h="100" color="#ef4444" rotation="330"/>
        <Element x="100" y="800" w="200" h="100" color="#dc2626" rotation="340"/>
      </Element>

      <!-- dynamic rotation value -->
      <Element x="200" y="200" w="400" h="400" color="#0891b2" rotation="$rotation1" />

      <!-- reactive rotation value -->
      <Element x="800" y="200" w="400" h="400" color="#0891b2" :rotation="$rotation2" />

      <!-- reactive rotation value animated -->
      <Element x="1400" y="200" w="400" h="400" color="#0891b2" :rotation.transition="$rotation3" />

    </Element>`,state(){return{rotation1:38,rotation2:0,rotation3:0}},hooks:{ready(){this.$setInterval(()=>{const r=this.rotation2+10;this.rotation2=r<=360?r:0},800),this.$setInterval(()=>{this.rotation3=Math.max(10,Math.min(720,this.rotation3*2)),this.rotation3===720&&(this.rotation3=0)},2e3)}}}),oo=E.Component("Events",{template:`
    <Element x="400" y="360">

      <Element w="280" h="280" color="#e5e7eb" :x="$x" y="-5" />

      <Element w="250" h="250" x="10" y="10" color="$colors[0]" />
      <Element w="250" h="250" x="290" y="10" color="$colors[1]" />
      <Element w="250" h="250" x="570" y="10" color="$colors[2]" />
      <Element w="250" h="250" x="850" y="10" color="$colors[3]" />
    </Element>`,state(){return{count:0,colors:["#fbbf24","#a3e635","#22d3ee","#f472b6"]}},computed:{x(){return this.count*280-5}},hooks:{unfocus(){this.$emit("changeBackground")}},input:{left(r){const t=this.count-1;t===-1?this.parent.focus(r):this.count=Math.max(t,0)},right(r){const t=this.count+1;t===4?this.parent.focus(r):this.count=Math.min(t,3)},enter(){this.$emit("changeBackground",this.colors[this.count])}}}),Fo=E.Component("Button",{template:`
    <Element w="300" h="80" color="$color"
      :effects="[$shader('rounded', {radius: 20})]"
      :alpha.transition="$alpha"
      :scale.transition="$scale"
      :z="$zIndex"
      :rotation="$rotate">
    </Element>`,props:["color"],state(){return{alpha:.4,scale:1,zIndex:1,rotate:0}},hooks:{focus(){this.$log.info(`Button with color ${this.color} received focus`),this.alpha=1,this.scale=this.scale===1?1.2:1,this.zIndex=100},unfocus(){this.$log.info(`Button with color ${this.color} lost focus`),this.alpha=.4,this.scale=1,this.zIndex=1,this.rotate=0}},input:{enter(){this.rotate=this.rotate===0?-4:0,this.scale=this.scale===1.2?1.3:1.2}}}),us=E.Component("Menu",{components:{Button:Fo},template:`
    <Element :x.transition="$x" w="400" h="1080" color="{right: '#64748baa', left: '#475569aa'}">
      <Element x="50" y="40">
        <Button color="#e4e4e7" ref="menu1" />
        <Button color="#e4e4e7" y="100" ref="menu2" />
        <Button color="#e4e4e7" y="200" ref="menu3" />
        <Button color="#e4e4e7" y="300" ref="menu4" />
      </Element>
    </Element>`,state(){return{x:-360,focused:1}},hooks:{focus(){this.select(`menu${this.focused}`).focus(),this.x=0},unfocus(){this.x=-360}},input:{right(){this.parent.focus()},left(r){this.parent.parent.focus(r)},down(){this.focused=Math.min(this.focused+1,4),this.select(`menu${this.focused}`).focus()},up(){this.focused=Math.max(this.focused-1,1),this.select(`menu${this.focused}`).focus()}}}),ro=E.Component("FocusHandling",{components:{Menu:us,Button:Fo},template:`
    <Element>
      <Element x="300" y="150">
        <Button color="#ef4444" x="0" ref="button1" />
        <Button color="#f97316" x="320" ref="button2" />
        <Button color="#84cc16" x="640" ref="button3" />
        <Button color="#10b981" x="0" y="100" ref="button4" />
        <Button color="#06b6d4" y="100" x="320" ref="button5" />
        <Button color="#3b82f6" y="100" x="640" ref="button6" />
        <Button color="#8b5cf6" y="200" x="0" ref="button7" />
        <Button color="#d946ef" y="200" x="320" ref="button8" />
        <Button color="#f43f5e" y="200" x="640" ref="button9" />
      </Element>
      <Menu ref="menu" />
    </Element>`,state(){return{focused:1}},hooks:{focus(){const r=this.select(`button${this.focused}`);r&&r.focus&&r.focus()}},watch:{focused(r){const t=this.select(`button${r}`);t&&t.focus&&t.focus()}},input:{right(r){this.focused+1===10?this.parent.focus(r):this.focused=Math.min(this.focused+1,9)},left(){const r=this.focused-1;if(r===0){const t=this.select("menu");t&&t.focus&&t.focus()}else this.focused=Math.max(r,1)},a(){const r=this.select("menu");r&&r.focus&&r.focus()}}}),ps={}.VITE_TMDB_KEY,ms="https://api.themoviedb.org/3";let No,Po;const xs="w185",gs={headers:{"Content-Type":"application/json",Authorization:"Bearer "+ps}};function so(r,t=xs){return Po+t+r}function ys(...r){return No?gt(...r):Ao().then(()=>gt(...r))}function gt(r,t={}){return fetch(ms+r,{...gs,...t}).then(e=>e.json())}function Ao(){return gt("/configuration").then(r=>(No=r,Po=r.images.base_url,r))}const ws={get:ys,loadConfig:Ao};function bs(r){return ws.get(`/${r}/popular`).then(t=>t.results.filter(o=>!o.adult).map(o=>({poster:so(o.poster_path||o.profile_path),background:so(o.backdrop_path,"w1280"),identifier:o.id})))}const _s=E.Component("Poster",{template:`
    <Element w="185" h="278" x="$x"
      :src="$src"
      :color="{top: '#fff', bottom: $colorBottom}"
      :scale.transition="{value: $scale, duration: 200, function: 'cubic-bezier(0.20, 1.00, 0.80, 1.00)'}"
      :effects="[$shader('radius', {radius: 8})]"
    />`,props:["src","index"],state(){return{scale:1,colorBottom:"#000"}},computed:{x(){return this.index*215}},hooks:{focus(){this.colorBottom="#fff",this.scale=1.1,this.$emit("posterSelect",this.index)},unfocus(){this.colorBottom="#000",this.scale=1}}}),vs=E.Component("Background",{template:`
    <Element>
      <Element
        :src="$bg1" w="1920" h="1080" color="{top: '#fff', bottom: '#000'}" :alpha.transition="{value: $alpha1, duration: 400, function: 'ease-in'}"
      />
      <Element
        :src="$bg2" w="1920" h="1080" color="{top: '#fff', bottom: '#000'}" :alpha.transition="{value: $alpha2, duration: 400, function: 'ease-in'}"
      />
    </Element>`,props:["src"],state(){return{counter:0,alpha1:0,alpha2:0,bg1:!1,bg2:!1}},watch:{src(r){this.counter=(this.counter+1)%2,this.counter===0?(this.bg1=r,this.alpha1=.8,this.alpha2=0):(this.bg2=r,this.alpha1=0,this.alpha2=.8)}}}),io=E.Component("Home",{components:{Poster:_s,Background:vs},template:`
    <Element w="1920" h="1080" color="black">
      <Background :src="$src" />
      <Element :alpha.transition="{value: $alphaIn, duration: 300, function: 'cubic-bezier(0.20, 1.00, 0.80, 1.00)'}">
        <Element src="assets/logo.png" x="130" :y.transition="{value: $logoY, duration: 300, function: 'cubic-bezier(0.20, 1.00, 0.80, 1.00)'}" w="243" h="52" />
        <Element :x.transition="{value: $x, duration: 300, function: 'ease-in-out'}"  :y.transition="{value: $listY, duration: 300, function: 'cubic-bezier(0.20, 1.00, 0.80, 1.00)'}">
          <Poster :for="(item, index) in $items" index="$index" src="$item.poster" ref="$item.identifier"/>
        </Element>
      </Element>
    </Element>`,state(){return{items:[],src:"",focused:null,alphaIn:.001,logoY:30,listY:750}},computed:{x(){return this.focused<=1?150:150-Math.min(this.focused-1,this.items.length-8)*215}},watch:{focused(r){const t=this.select(this.items[r].identifier);t&&t.focus&&t.focus()}},hooks:{ready(){this.alphaIn=1,this.listY=700,this.logoY=80,bs("movie").then(r=>{this.items=r,this.focused=0,this.background=r[this.focused].background}),this.$listen("posterSelect",r=>{this.src=this.items[r].background})}},input:{left(){this.focused=Math.max(this.focused-1,0)},right(){this.focused=Math.min(this.focused+1,this.items.length-1)}}}),Es=E.Component("MenuSprite",{template:`
    <Element>
      <Element>
        <Element src="assets/menusprite.png" x="748" y="120" w="425" h="340" />
        <Element y="680" x="560">
          <Sprite image="assets/menusprite.png" x="0" w="140" h="140" map="$map" :frame="$icon1" />
          <Sprite image="assets/menusprite.png" x="220" w="140" h="140" map="$map" frame="icon2" />
          <Sprite image="assets/menusprite.png" x="440" w="140" h="140" map="$map" frame="icon3" />
          <Sprite image="assets/menusprite.png" x="660" w="140" h="140" map="$map" frame="icon4_unfocus" />
        <Element>
      </Element>
    </Element>
    `,state(){return{icon1:"icon1_unfocus",map:{defaults:{w:160,h:160},frames:{icon1_focus:{x:0,y:0},icon1_unfocus:{x:170,y:340},icon2:{x:170,y:0},icon3:{x:350,y:0},icon4_unfocus:{x:680,y:170}}}}},hooks:{ready(){this.$setInterval(()=>{this.icon1=this.icon1==="icon1_unfocus"?"icon1_focus":"icon1_unfocus"},2e3)}}}),Xe=["menu"],no=E.Component("Sprites",{components:{MenuSprite:Es},template:`
    <Element>
      <MenuSprite :show="$currentSprite === 'menu'"/>
    </Element>
    `,state(){return{currentSprite:"menu"}},input:{down(){const r=Xe.indexOf(this.currentSprite);r<Xe.length-1?this.currentSprite=Xe[r+1]:this.currentSprite=Xe[0]}}}),rt=["#64748b","#ef4444","#f97316","#84cc16","#14b8a6","#3b82f6"],st=["Iron Man","Captain America","Thor","Hulk","Black Widow","Hawkeye","Scarlet Witch","Vision","Black Panther","Doctor Strange","Spider-Man","Ant-Man","Wasp","Captain Marvel","Falcon","Winter Soldier","War Machine","Quicksilver","Star-Lord","Gamora"],ao=E.Component("Texts",{template:`
    <Element x="100" y="100">

      <Text content="Default text" />
      <Text content="123456" x="400" />

      <Text content="Text with a different fontsize" :size="$size" y="120" font="raleway" />
      <Text content="Text with a different color" size="50" :color="$color" y="250" />

      <!-- does the font have a bold and italic? -->
      <!--Text content="Bold and Italic text" size="50" color="#0369a1" y="350" style="italic" weight="bold" /-->

      <Text content="Letterspacing" size="50" color="#38bdf8" y="450" letterspacing="40" />

      <Element w="800" h="100" y="550" color="#94a3b8">
        <Text content="Text align center" size="50" y="15" color="#bae6fd" align="center" w="800" />
      </Element>

      <Element w="800" h="200" x="900" y="550" color="#94a3b8">
        <Text content="$longText" size="40" color="#bae6fd" w="800" h="200" />
      </Element>

      <Text :content="$character" size="50" :color="$color" y="750" font="opensans" />
    </Element>`,state(){return{color:rt[0],size:10,character:st[0],myText:"This is my test yeah",longText:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent at ante non mauris commodo tristique. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut quis mattis mi. Aliquam ultricies mi vel lobortis luctus. Ut non feugiat urna. Duis sed blandit dui. Donec venenatis, mauris at blandit malesuada, elit nibh scelerisque lacus, non tempus arcu mi at justo."}},hooks:{ready(){let r=0;this.$setInterval(()=>{r++,r>rt.length-1&&(r=0),this.color=rt[r],this.size=10*(r*2+1)},1e3);let t=0;this.$setInterval(()=>{t++,t>st.length-1&&(t=0),this.character=st[t]},1400)}}}),$s=E.Component("Toggle",{template:`
    <Element w="100" h="50" y="5" :color="$bgColor" :effects="[$shader('radius', {radius:25})]">
      <Circle :x.transition="$on ? 0 : 50" size="50" :color="$primaryColor" />
    </Element>
  `,props:["bgColor","primaryColor","on"]}),Ts=E.Component("Bar",{template:`
    <Element :w="{value: $w, duration: $duration}" :h="{value: $h, duration: $duration}" :color="$bgColor" :x="$index * ($w + ($w / 4))" :effects="[$shader('radius', {radius:10})]">
      <Element :w="$w" :y.transition="{value: $h-$innerH, duration: $duration}" :h.transition="{value: $innerH, duration: $duration}" :color="$primaryColor" :effects="[$shader('radius', {radius:10})]" />
    </Element>
  `,props:["bgColor","primaryColor","height","index","size"],state(){return{h:200,innerH:0,duration:400}},hooks:{ready(){this.innerH=this.height}},computed:{w(){return this.size==="large"?110:72}},watch:{bgColor(){this.duration=1e-6,this.innerH=0,this.$setTimeout(()=>{this.duration=400,this.innerH=this.height},200)},size(){this.duration=1e-6,this.innerH=0,this.$setTimeout(()=>{this.duration=400,this.innerH=this.height},100)}}}),Ss={color1:"#475569",color2:"#64748b",color3:"#cbd5e1",color4:"#38bdf8",bg:"#1e293b80"},Cs={color1:"#f8fafc",color2:"#e2e8f0",color3:"#1e293b",color4:"#0369a1",bg:"#f1f5f9"},ks=E.Component("Theming",{components:{Bar:Ts,Toggle:$s},template:`
    <Element w="1920" h="1080" :color.transition="$colors.bg">
      <Element :x.transition="(1920 - $width) / 2" :y.transition="(1080 - $height) / 2">
        <Element x="-250" y="-100" src="assets/shadow.png" w="1000" h="900" alpha="0.5" />

        <!-- Header -->
        <Element :w.transition="$width" :h.transition="$height" :color="$colors.color1" :effects="[$shader('radius', {radius: $radius})]">
          <Element :w.transition="$width" h="100" :color="$colors.color2" :effects="[$shader('radius', {radius: $radius})]" />
          <Element :w.transition="$width" h="80" y="20" :color="$colors.color2">

          <Text :content="$text" :color="$colors.color3" size="28" x="20" y="14" />
          <Toggle :x.transition="$width - 120" :on="$mode === 'dark'" :bgColor="$colors.color1" primaryColor="#22c55e" />

        </Element>

        <!-- Blocks -->
        <Element w="200" :h.transition="$block1.height" x="25" y="140" :color="$colors.color2" :effects="[$shader('radius', {radius: $radius / 2})]" />
        <Element :w.transition="$block2.w" :h="$block2.h" x="270" :y.transition="$block2.y" :color="$colors.color2" :effects="[$shader('radius', {radius: $radius / 2})]" />

        <!-- Graph -->
        <Element :x.transition="$graph.x" :y.transition="$graph.y" :w="$graph.w" :h="$graph.h" color="transparent">
          <Element :x.transition="$graph.offset" :y.transition="$graph.offset">
            <Bar :bgColor="$colors.color2" :primaryColor="$colors.color4" :size="$graph.size" height="100" index="0" />
            <Bar :bgColor="$colors.color2" :primaryColor="$colors.color4" :size="$graph.size" height="140" index="1" />
            <Bar :bgColor="$colors.color2" :primaryColor="$colors.color4" :size="$graph.size" height="170" index="2" />
            <Bar :bgColor="$colors.color2" :primaryColor="$colors.color4" :size="$graph.size" height="150" index="3" />
            <Bar :bgColor="$colors.color2" :primaryColor="$colors.color4" :size="$graph.size" height="90" index="4" />
          <Element>
        </Element>

      </Element>
    </Element>
  `,state(){return{mode:"dark",radius:20,width:500,height:600}},computed:{colors(){return this.mode==="dark"?Ss:Cs},text(){return this.mode==="dark"?"Dark mode":"Light mode"},block1(){return{height:this.height===600?180:720}},block2(){return{y:this.height===600?140:560,h:this.height===600?180:300,w:this.height===600?200:890}},graph(){return{x:this.height===600?32:270,y:this.height===600?370:140,w:this.height===600?0:890,h:this.height===600?0:400,offset:this.height===600?0:110,size:this.height===600?"small":"large"}}},input:{space(){this.toggleX=this.toggleX===0?48:0,this.$setTimeout(()=>{this.mode=this.mode==="dark"?"light":"dark"},150)},a(){this.radius=this.radius===20?8:20},b(){this.width=this.width===500?1200:500,this.height=this.height===600?900:600}}}),Is=E.Component("SlotCard",{template:`
    <Element
      w="300" h="500"
      :effects="[$shader('radius', {radius: 20}), $shader('border', {width: 6, color: '#e2e8f0'})]" color="{top: '#94a3b8', bottom: '#475569'}"
    >
      <Slot x="20" y="20" />
      <Text content="$label" w="260" x="20" y="400" align="center" />
    </Element>
  `,props:[{key:"label"}]}),Rs=E.Component("NamedSlotCard",{template:`
    <Element
      w="700" h="300"
      :effects="[$shader('radius', {radius: 20}), $shader('border', {width: 6, color: '#e2e8f0'})]" color="{top: '#94a3b8', bottom: '#475569'}"
    >
      <Element x="20" y="20">
        <Text content="First slot" />
        <Slot y="40" ref="first" />
      </Element>

      <Element x="200" y="20">
        <Text content="Second slot"/>
        <Slot y="40" ref="second" />
      </Element>


      <Element x="480" y="20">
        <Text content="Third slot"/>
        <Slot y="40" ref="third"/>
      </Element>

    </Element>
  `}),Ee=["#fff7ed","#fdba74","#f97316","#ea580c","#9a3412","#431407"],lo=E.Component("Components",{components:{SlotCard:Is,NamedSlotCard:Rs,Card:Lo,Square:ye},template:`
    <Element>
      <SlotCard x="400" y="100" label="Element">
        <Element :color="$color" w="100" h="100"/>
      </SlotCard>

      <SlotCard x="800" y="100" label="Component">
        <Square size="200" y="50"  />
      </SlotCard>

      <SlotCard x="1200" y="100" label="Element & Component">
        <Element :color="$color" w="100" h="100" />
        <Square size="200" y="150" />
      </SlotCard>

      <Card x="400" y="700" size="small">
        <Element :color="$color" w="100" h="100" />
      </Card>

      <NamedSlotCard x="800" y="700">
        <Element color="#0891b2" x="10" y="140" w="80" h="60" slot="second" />
        <Element :color="$color" w="100" h="100" slot="third" />
        <Square size="100" slot="first" />
        <Element color="#4d7c0f" x="40" y="40" w="40" h="60" slot="second" />
      </NamedSlotCard>

    </Element>`,state(){return{color:Ee[0]}},hooks:{ready(){this.$setInterval(()=>{const r=Ee.indexOf(this.color)+1;this.color=r<=Ee.length?Ee[r]:Ee[0]},600)}}}),Ms=E.Application({components:{Loading:jt,Positioning:Yt,Transitions:Xt,Colors:Wt,ForLoop:Ht,Components:Ut,Gradients:qt,KeyInput:Gt,Scaling:Kt,Effects:Vt,Alpha:Qt,Intro:Zt,ShowIf:Jt,Images:eo,Rotation:to,Events:oo,FocusHandling:ro,Tmdb:io,Sprites:no,Texts:ao,Slots:lo},template:`
    <Element w="1920" h="1080" :color="$backgroundColor">
      <RouterView />
    </Element>`,state(){return{currentPage:0,backgroundColor:"#1e293b"}},routes:[{path:"/",component:jt},{path:"/intro",component:Zt},{path:"/positioning",component:Yt},{path:"/transitions",component:Xt},{path:"/gradients",component:qt},{path:"/components",component:Ut},{path:"/keyinput",component:Gt},{path:"/colors",component:Wt},{path:"/forloop",component:Ht},{path:"/scaling",component:Kt},{path:"/effects",component:Vt},{path:"/alpha",component:Qt},{path:"/showif",component:Jt},{path:"/images",component:eo},{path:"/rotation",component:to},{path:"/events",component:oo},{path:"/focushandling",component:ro},{path:"/sprites",component:no},{path:"/texts",component:ao},{path:"/theming",component:ks},{path:"/slots",component:lo},{path:"/tmdb",component:io}],hooks:{init(){this.$listen("changeBackground",t=>{this.backgroundColor=t?t+80:"#1e293b"});const r=(document.location.hash||"/").replace(/^#/,"");this.___routes.forEach((t,e)=>{t.path===r&&(this.currentPage=e)})}},input:{escape(){this.quit()},a(){this.$router.to("/")},b(){this.$router.to("/transitions")},c(){this.$router.to("/positioning")},left(){this.currentPage=Math.max(this.currentPage-1,0),this.$router.to(this.___routes[this.currentPage].path)},right(){this.currentPage=Math.min(this.currentPage+1,this.___routes.length-1),this.$router.to(this.___routes[this.currentPage].path)}}});E.Launch(Ms,"app",{w:1920,h:1080,multithreaded:!1,debugLevel:1,fontLoader:fs,fonts:[{family:"lato",type:"msdf",png:"/fonts/Lato-Regular.msdf.png",json:"/fonts/Lato-Regular.msdf.json"},{family:"raleway",type:"msdf",png:"/fonts/Raleway-ExtraBold.msdf.png",json:"/fonts/Raleway-ExtraBold.msdf.json"},{family:"opensans",type:"web",file:"/fonts/OpenSans-Medium.ttf"}]});
