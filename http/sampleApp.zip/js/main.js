function changeBackgroundColor() {
  // Array of colors which will have a good contrast with white text
  const colors = [
    '#3498db', // blue
    '#e74c3c', // red
    '#2ecc71', // green
    '#f1c40f', // yellow
    '#9b59b6', // purple
    '#1abc9c', // turquoise
    '#34495e', // wet asphalt
  ]

  // Select a random color from the array
  const randomColor = colors[Math.floor(Math.random() * colors.length)]

  // Set the background color to the randomly selected color
  document.body.style.backgroundColor = randomColor
}
