let angle = 0

function updateGradient() {
  angle = (angle + 1) % 360
  const gradient = `linear-gradient(${angle}deg, red, yellow, green, blue, indigo, violet)`
  document.body.style.background = gradient
  requestAnimationFrame(updateGradient)
}

window.onload = function () {
  updateGradient()
}
